from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.views import generic
from django.views.generic.base import View
from django.contrib import messages
from django.http import JsonResponse
from django.forms.models import model_to_dict
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.db import connection, reset_queries
from django.db.models import Sum, Max, Value
from django_tables2 import RequestConfig
from django import forms
from miBuilds.models import (AppProbuild,
                            AppProbuildNote,
                            RptProbuild,
                            AppBuilding,
                            AppBusiness,
                            AppSfDealinhand,
                            AppMdu,
                            AppDatacenter,
                            AppDatacenterCircuitEoy,
                            AppFile,
                            AppUserProfile,
                            AssumpRegion,
                            AssumpMduBuildRegion,
                            AssumpMduBuild,
                            AssumpSegment,
                            AssumpDataCenterType,
                            AssumpDataCenterEquipType,
                            AssumpDataCenterCircuitEoy,
                            LkState,
                            LkDataCenterEquipType,
                            LkSegmentType,
                            LkBuildingType,
                            LkDwellingType,
                            )
#from miBuilds.forms import BuildingUploadForm
from miBuilds.utils import *
from miBuilds.decorators import (user_is_authorized)
from miBuilds.filters import (BusinessCaseFilter)
from datetime import datetime
import pandas as pd
import sqlalchemy, csv, codecs, urllib
from io import TextIOWrapper
from decimal import Decimal

def building_add_upload_csv(request, probuild_id, addedby):
    data = csv.DictReader(codecs.iterdecode(request.FILES['path'],'utf-8'))
    csv_headers = data.fieldnames
    poss_headers = ['building_id','BUILDING_ID','MIP_BUILDING_ID',
                    'Building_Id','MIP_Building_Id','mip_building_id']
    buildings_list = []
    for header in poss_headers:
        if header in csv_headers:
            for row in data:
                buildings_list.append(row[header])
    buildings_list = list(set(filter(None, buildings_list)))
    buildings = ",".join(buildings_list)
    ### If one of the possible headers isn't in file show error message. ###
    if len(buildings_list) == 0:
        failed_message = ('''The correct possible headers aren't in the file.
                    Please make sure the file contains one of the following:''')
        failed_items = (''' <ul>
                                <li>building_id</li>
                                <li>BUILDING_ID</li>
                                <li>MIP_BUILDING_ID</li>
                            </ul>''')
        request.session['successful_message'] = ''
        request.session['successful_items'] = ''
        request.session['upload_failed_message'] = ''
        request.session['upload_failed_items'] = ''
        request.session['failed_message'] = failed_message
        request.session['failed_items'] = failed_items
        return redirect('building_add_upload_failure', probuild_id)
    ### Match the buildings to the MIP table and write information to the Application table ###
    upload_sql = (''' EXEC BI_MIP.miBuilds.views_building_add_upload_df
                        @probuild_id = '{}',
                        @addedby = '{}',
                        @nax_building_id_list = '{}'
                ''')
    upload_sql = upload_sql.format(probuild_id, addedby, buildings)
    upload_df = pd.read_sql(upload_sql, connection)
    ### Write to the buildings to the DB ###
    engine = settings.DB_ENGINE
    upload_df.to_sql(name='app_Building', con=engine,
        schema='Dev', if_exists='append', index=False)
    ### Succesfully uploaded buildings ###
    upload_list = list(set(
                        upload_df['building_id'].astype('int').tolist()
                        ))
    upload_list = [str(x) for x in upload_list]
    upload_fail_list = [x for x in buildings_list
                        if x not in upload_list]
    upload_pass_list = [x for x in upload_list
                        if x not in upload_fail_list]
    upload_fail = ", ".join(list(set(upload_fail_list)))
    upload_pass = ", ".join(list(set(upload_pass_list)))

    ### If there are buildings in another build, redirect to page showing the matching values ###
    if len(upload_fail) > 0:
        successful_message = '''These buildings were uploaded:'''
        successful_items = ifnull(upload_pass, 'No buildings were uploaded.') #pd.concat([upload_df['building_id']], axis=1, keys=['Building']).to_html(index=False)
        upload_failed_message = '''These buildings were not uploaded.
            Please double check to ensure these are correct:'''
        upload_failed_items = ifnull(upload_fail, '')
        #failed_items = upload_df.to_html(index=False)
        #failed_message = '''These buildings are tied to a different build:'''
        request.session['successful_message'] = successful_message
        request.session['successful_items'] = successful_items
        request.session['upload_failed_message'] = upload_failed_message
        request.session['upload_failed_items'] = upload_failed_items
        request.session['failed_message'] = ''
        request.session['failed_items'] = ''
        return redirect('building_add_upload_failure', probuild_id)
    return redirect('building_add', probuild_id=probuild_id)

def building_add_upload_xlsx(request, probuild_id):
    try:
        data = request.FILES['path'].get_dict(sheet_name='Buildings')
    except:
        request.session['successful_message'] = ''
        request.session['successful_items'] = ''
        request.session['upload_failed_message'] = ''
        request.session['upload_failed_items'] = ''
        request.session['failed_message'] = '''
                        Please double check the file has the proper tab
                        names and the headers are correct.
                        '''
        request.session['failed_items'] = ''
        return redirect('building_add_upload_failure', probuild_id)

    if len(data['State']) > 0:
        try:
            upload_df = pd.DataFrame.from_dict(data, orient='columns')

            state_list = LkState.objects.values('abbrev','state_id').filter(
                    isactive=1)
            state_dict = {}
            for i in range(len(state_list)):
                abbrev = state_list[i]['abbrev']
                id = state_list[i]['state_id']
                state_dict[abbrev] = id
            building_type_list = LkBuildingType.objects.values('name',
                    'building_type_id').filter(isactive=1)
            building_type_dict = {}
            for i in range(len(building_type_list)):
                name = building_type_list[i]['name']
                id = building_type_list[i]['building_type_id']
                building_type_dict[name] = id
            dwelling_type_list = LkDwellingType.objects.values('name',
                    'dwelling_type_id').filter(isactive=1)
            dwelling_type_dict = {}
            for i in range(len(dwelling_type_list)):
                name = dwelling_type_list[i]['name']
                id = dwelling_type_list[i]['dwelling_type_id']
                dwelling_type_dict[name] = id

            probuild_id_list = [probuild_id for i in range(upload_df['State'].count())]
            addedby_list = [addedby for i in range(upload_df['State'].count())]
            addedon_list = [addedon for i in range(upload_df['State'].count())]

            upload_df['Probuild_Id'] = probuild_id_list
            upload_df['AddedBy'] = addedby_list
            upload_df['AddedOn'] = addedon_list
            upload_df['State'] = upload_df['State'].map(state_dict)
            upload_df['Building_Type'] = upload_df['Building_Type'].map(building_type_dict)
            upload_df['Dwelling_Type'] = upload_df['Dwelling_Type'].map(dwelling_type_dict)
            upload_df.rename(columns={
                    'State': 'State_Id',
                    'Zip_Code': 'Zip',
                    'Building_Type': 'Building_Type_Id',
                    'Dwelling_Type': 'Dwelling_Type_Id',
                    'ROE_Id': 'ROE_Id'}, inplace=True)

            engine = settings.DB_ENGINE
            upload_df.to_sql(name='app_Building', con=engine,
                schema='Dev', if_exists='append', index=False)

            sql = (''' EXEC BI_MIP.miBuilds.views_greenfield_building_add_upload
                                    @probuild_id = '{}'
                            ''').format(probuild_id)
            connection.cursor().execute(sql)

        except:
            request.session['successful_message'] = ''
            request.session['successful_items'] = ''
            request.session['upload_failed_message'] = ''
            request.session['upload_failed_items'] = ''
            request.session['failed_message'] = '''
                            Please double check the file for errors.
                            '''
            request.session['failed_items'] = ''
            return redirect('building_add_upload_failure', probuild_id)
        return redirect('building_add', probuild_id=probuild_id)
    else:
        request.session['successful_message'] = ''
        request.session['successful_items'] = ''
        request.session['upload_failed_message'] = ''
        request.session['upload_failed_items'] = ''
        request.session['failed_message'] = 'There were was no data in the file.'
        request.session['failed_items'] = ''
        return redirect('building_add_upload_failure', probuild_id)
    return redirect('building_add', probuild_id=probuild_id)
