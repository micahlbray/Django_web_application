from django.db.models import Sum, Max
from django.db import connection
from miBuilds.utils import(ifnull, strDollarToDecimal, strPercentToDecimal)
from miBuilds.calculations import   (
                                    child_smb_ent,
                                    child_data_center,
                                    parent_smb_ent,
                                    parent_data_center,
                                    )
import numpy as np
import pandas as pd

######################################################################
# Build SMB and ENT Dicts
######################################################################
def build_child_smb_ent_dicts(request):
    ### Call function to build the smb_ent_curves ###
    smb_ent_curves = child_smb_ent.build_child_smb_ent_curves(request)

    ### Build initial dicts before customizing with data ###
    smb_pen, smb_rev, ent_pen, ent_rev, smb_ent_cost, smb_ent_cashflow  = (
                    {} for i in range(6))

    for i in range(181):
        month = i
        smb_rev[month] = round(smb_ent_curves['smb_rev'][i], 2)
        ent_rev[month] = round(smb_ent_curves['ent_rev'][i], 2)
        smb_ent_cost[month] = round(smb_ent_curves['smb_ent_cost'][i], 2)
        smb_ent_cashflow[month] = round(smb_ent_curves['smb_ent_cashflow'][i], 2)

    for i in range(37):
        month = i
        smb_pen[month] = round(smb_ent_curves['smb_pen'][i], 3)
        ent_pen[month] = round(smb_ent_curves['ent_pen'][i], 3)

    return smb_pen, smb_rev, ent_pen, ent_rev, smb_ent_cost, smb_ent_cashflow

######################################################################
# Store Calc Data in tables
######################################################################
def build_smb_ent_df(request):
    ### Get data from request based on request method ###
    (smb_pen, smb_rev,
    ent_pen, ent_rev,
    smb_ent_cost, smb_ent_cashflow) = build_child_smb_ent_dicts(request)

    smb_pen.update({'Category': 'Estimated SMB Penetration'})
    ent_pen.update({'Category': 'Estimated ENT Penetration'})
    smb_rev.update({'Category': 'Estimated SMB MRC'})
    ent_rev.update({'Category': 'Estimated ENT MRC'})
    smb_ent_cost.update({'Category': 'Estimated Costs'})
    smb_ent_cashflow.update({'Category': 'Estimated Cash Flow'})

    smb_pen_df = pd.DataFrame(smb_pen, index=[0])
    ent_pen_df = pd.DataFrame(ent_pen, index=[0])
    smb_rev_df = pd.DataFrame(smb_rev, index=[0])
    ent_rev_df = pd.DataFrame(ent_rev, index=[0])
    smb_ent_cost_df = pd.DataFrame(smb_ent_cost, index=[0])
    smb_ent_cashflow_df = pd.DataFrame(smb_ent_cashflow, index=[0])

    dfs = [smb_pen_df, ent_pen_df, smb_rev_df, ent_rev_df, smb_ent_cost_df,
            smb_ent_cashflow_df]
    smb_ent_df = pd.concat(dfs, ignore_index=True)
    cols = ['Category'] + list(range(0,181))
    smb_ent_df = smb_ent_df[cols]

    return smb_ent_df

######################################################################
# Build DataCenter Dicts
######################################################################
def build_child_data_center_dicts(request):
    ### Call function to build the smb_ent_curves ###
    (data_center_rev,
    data_center_opex,
    data_center_cashflow,
    data_center_circuits) = child_data_center.build_child_data_center_consol_curves(request)

    ### Build initial dicts before customizing with data ###
    dc_circuits, dc_rev, dc_opex, dc_cashflow  = ({} for i in range(4))

    for i in range(181):
        month = i
        dc_circuits[month] = round(data_center_circuits[i], 2)
        dc_rev[month] = round(data_center_rev[i], 2)
        dc_opex[month] = round(data_center_opex[i], 2)
        dc_cashflow[month] = round(data_center_cashflow[i], 2)

    return dc_circuits, dc_rev, dc_opex, dc_cashflow

def build_data_center_df(request):
    ### Get data from request based on request method ###
    probuild_id = request.GET.get('probuild_id', None)
    probuild_name = request.GET.get('name', None)

    (dc_circuits, dc_rev,
    dc_opex, dc_cashflow) = build_child_data_center_dicts(request)

    dc_circuits.update({'Category': 'Circuits'})
    dc_rev.update({'Category': 'Estimated Revenue'})
    dc_opex.update({'Category': 'Estimated Opex'})
    dc_cashflow.update({'Category': 'Estimated Cashflow'})

    dc_circuits_df = pd.DataFrame(dc_circuits, index=[0])
    dc_rev_df = pd.DataFrame(dc_rev, index=[0])
    dc_opex_df = pd.DataFrame(dc_opex, index=[0])
    dc_cashflow_df = pd.DataFrame(dc_cashflow, index=[0])

    dfs = [dc_circuits_df, dc_rev_df, dc_opex_df, dc_cashflow_df]
    dc_df = pd.concat(dfs, ignore_index=True)
    cols = ['Category'] + list(range(0,181))
    dc_df = dc_df[cols]

    return dc_df
