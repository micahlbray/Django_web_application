from django.contrib import admin

# Register your models here.
from miBuilds.models import LkRegion, AppProbuild

class LkRegionAdmin(admin.ModelAdmin):
	list_display = ('name', 'lead_email', 'lead_backup_email', 'invest_committ_email_distro',
					'review_email', 'construction_email', 'other_email')

	def get_actions(self, request):
		actions = super(LkRegionAdmin, self).get_actions(request)
		if 'delete_selected' in actions:
			del actions['delete_selected']
		return actions

	def has_add_permission(self, request, obj=None):
		return False

	def has_delete_permission(self, request, obj=None):
		return False

class AppProbuildAdmin(admin.ModelAdmin):
	list_display = ('probuild_id','name', 'jt_id')
	search_fields = ('probuild_id','name', 'jt_id')

	def get_actions(self, request):
		actions = super(AppProbuildAdmin, self).get_actions(request)
		if 'delete_selected' in actions:
			del actions['delete_selected']
		return actions

	def has_add_permission(self, request, obj=None):
		return False

	def has_delete_permission(self, request, obj=None):
		return False


admin.site.register(LkRegion, LkRegionAdmin)
admin.site.register(AppProbuild, AppProbuildAdmin)