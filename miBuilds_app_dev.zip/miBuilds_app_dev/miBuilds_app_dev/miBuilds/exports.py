from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, StreamingHttpResponse
from django.views import generic
from django.db import connection
from datetime import datetime
import pandas as pd
import csv
from io import TextIOWrapper, StringIO, BytesIO

# Create your views here.
######################################################################
######################################################################
def render_to_csv_other(request):
    filename = 'building_upload_template.csv'

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename=%s' % filename

    data = [['building_id']] #double list due to iteration

    writer = csv.writer(response)
    for row in data:
        writer.writerow(row)
    return response

def render_to_csv_template(filename, data):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename=%s' % filename

    writer = csv.writer(response)
    writer.writerow(data)
    return response

def export_building_upload_template(request):
    filename = 'building_upload_template.csv'
    data = ['building_id']
    response = render_to_csv_template(filename, data)
    return response

def export_building_greenfield_upload_template(request):
    filename = 'building_greenfield_upload_template.csv'
    data = ['address', 'city', 'state', 'zip_code',
            'building_type', 'dwelling_type', 'roe_id']
    response = render_to_csv_template(filename, data)
    return response

def export_business_upload_template(request):
    filename = 'business_upload_template.csv'
    data = ['business_id']
    response = render_to_csv_template(filename, data)
    return response

def export_business_greenfield_upload_template(request):
    filename = 'business_greenfield_upload_template.csv'
    data = ['building_id', 'business_name', 'address_1',
            'address_2', 'segment_type', 'revised_segment_type',
            'revised_segment_notes']
    response = render_to_csv_template(filename, data)
    return response

def render_df_to_csv(sql_df, filename):
    sql_df = sql_df
    filename = filename + '.csv'

    sio = StringIO()
    sql_df.to_csv(sio, sep=',', index=False)
    sio.seek(0)

    response = StreamingHttpResponse(sio, content_type='text/plain')
    response['Content-Disposition'] = 'attachment; filename=%s' % filename
    return response

def render_df_to_excel(sql_df, filename, sheetname):
    bio = BytesIO()
    pd_writer = pd.ExcelWriter(bio, engine='xlsxwriter')
    sql_df.to_excel(pd_writer, sheet_name=sheetname, index=False)
    pd_writer.save()

    bio.seek(0)
    workbook = bio.getvalue()

    response = HttpResponse(workbook, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=%s' % filename
    return response

def render_df_to_excel_header_format(sql_df, filename, sheetname):
    bio = BytesIO()
    pd_writer = pd.ExcelWriter(bio, engine='xlsxwriter')
    sql_df.to_excel(pd_writer, sheet_name=sheetname, index=False, header=False)
    pd_workbook = pd_writer.book
    workbook_format = pd_workbook.add_format({
        'font_name': 'Century Gothic',
        'font_size': 10})
    worksheet = pd_writer.sheets[sheetname]
    worksheet.set_column('A:B', 12, workbook_format)
    header_format = pd_workbook.add_format({
        'font_name': 'Century Gothic',
        'font_size': 10,
        'font_color': '#FFFFFF',
        'bold': True,
        'text_wrap': False,
        'align': 'center',
        'valign': 'vcenter',
        'fg_color': '#0050b9'})

    for col, value in enumerate(sql_df.columns.values):
        worksheet.write(0, col, value, header_format)

    pd_writer.save()

    bio.seek(0)
    workbook = bio.getvalue()

    response = HttpResponse(workbook, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=%s' % filename
    return response

def export_business_case_business(request, probuild_id):
    probuild_id = probuild_id
    sql = (''' SELECT  b.nax_building_id as Building_id
                        ,b.nax_building_address as Address
                        ,a.business_id as Business_Id
                        ,a.business_name as Business_Name
                        ,c.name as Segment_Type
                        ,d.name as Revised_Segment_Type
                FROM    BI_MIP.miBuilds.app_Business as a
                    JOIN ExternalUser.MIP.MIP2_BUILDING_PROFILE as b
                    ON a.Building_Id = b.NAX_BUILDING_ID
                    LEFT JOIN BI_MIP.miBuilds.lk_Segment_Type as c
                    ON a.Segment_Type_Id = c.Segment_Type_Id
                    LEFT JOIN BI_MIP.miBuilds.lk_Segment_Type as d
                    ON a.Revised_Segment_Type_Id = d.Segment_Type_Id
                WHERE a.ProBuild_Id = {}
                        and ISNULL(a.Deleted, 0) = 0
            ''').format(probuild_id)
    sql_df1 = pd.read_sql(sql, connection)

    sql = (''' SELECT	c.BUSN_ID
                		,c.NAX_BUILDING_ID
                		,c.BUSN_NAME
                		,b.NAX_BUILDING_ADDRESS
                		,c.BUSN_SUITE
                		,b.NAX_BUILDING_CITY
                		,b.NAX_BUILDING_ZIP
                		,c.COMCAST_CUSTOMER
                		,c.COMCAST_CUSTOMER_FIBER
                		,c.IS_SFDC_LEAD
                		,c.IS_SFDC_OPPTY
                		,c.MIP_SEGMENT
                		,c.COMCAST_REV_NDW
                		,c.COMCAST_REV_SV
                		,c.COMCAST_REV_SV_FIBER
                		,c.MIP_IN_OR_OUT
                		,b.MIP_SELLABILITY_COLOR_COAX
                		,b.MIP_SELLABILITY_COLOR_FIBER
                FROM	BI_MIP.miBuilds.app_Building as a
                	LEFT JOIN ExternalUser.MIP.MIP2_BUILDING_PROFILE as b
                	ON a.Building_Id = b.NAX_BUILDING_ID
                	LEFT JOIN ExternalUser.MIP.MIP2_BUSINESS_PROFILE as c
                	ON a.Building_Id = c.NAX_BUILDING_ID
                WHERE a.ProBuild_Id = {}
                            and ISNULL(a.Deleted, 0) = 0
            ''').format(probuild_id)
    sql_df2 = pd.read_sql(sql, connection)

    filename = 'business_review' + '.xlsx'
    sheetname = 'business_match_data'

    bio = BytesIO()
    pd_writer = pd.ExcelWriter(bio, engine='xlsxwriter')
    sql_df1.to_excel(pd_writer, sheet_name=sheetname, index=False)
    sql_df2.to_excel(pd_writer, sheet_name=sheetname, startcol=8, index=False)
    pd_writer.save()

    bio.seek(0)
    workbook = bio.getvalue()

    response = HttpResponse(workbook, content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=%s' % filename
    return response
