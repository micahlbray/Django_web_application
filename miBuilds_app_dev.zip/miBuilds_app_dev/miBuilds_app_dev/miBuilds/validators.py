from django.core.exceptions import ValidationError
from datetime import date
from datetime import datetime
from dateutil.relativedelta import relativedelta
import re, os

def validate_date_past(value):
    if value <= date.today():
        raise ValidationError("Please enter a date in the future.")

def validate_date_future(value):
    if value >= date.today() + relativedelta(years=10):
        raise ValidationError("Please enter a date less than 10 years ahead.")

def validate_id_not_zero(value):
    if value == 0:
        raise ValidationError("Please leave blank instead of entering 0.")

def validate_number_greather_than_zero(value):
    if value < 0:
        raise ValidationError("Please enter a number greater than or equal to 0.")

def validate_sf_opp_id_start_with(value):
    if not (value.startswith("O") or value.startswith("o")):
        raise ValidationError('''
            Please use the opportunity ID that starts with the letter "O-".
            ''')

def validate_alphanumeric(value):
    reg = re.compile("^[\w\-\(\)\s]+$")
    if not reg.match(value):
        raise ValidationError("Please use the proper characters only.")

def validate_file_extension(value):
    ext = os.path.splitext(value.name)[1]  # [0] returns path+filename
    valid_extensions = ['.pdf', '.doc', '.docx', '.jpg', '.png', '.xlsx', '.xls']
    if not ext.lower() in valid_extensions:
        raise ValidationError(u'Unsupported file extension.')

def validate_csv(value):
    if not value.name.endswith('.csv'):
        raise ValidationError('Please use a CSV file.')

    #with open(value.file, 'r') as csvfile:
        #try:
            #csvreader = csv.reader(csvfile)
            # Do whatever checks you want here
            # Raise ValidationError if checks fail
        #except csv.Error:
            #raise ValidationError('Failed to parse the CSV file')
