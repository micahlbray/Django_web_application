from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.views import generic
from django.contrib import messages
from django.http import JsonResponse
from django.forms.models import model_to_dict
from django.conf import settings
from django.db import connection
from miBuilds.utils import(ifnull, strDollarToDecimal, strPercentToDecimal)
from datetime import datetime
import pandas as pd
import sqlalchemy, pickle, json, csv, codecs, urllib, os, requests
from io import TextIOWrapper

######################################################################
# Functions to handle Ajax calls for Jquery
######################################################################
def spectrum_job_add_failure(request):
    print(request)
    failed_message = request.session.get('failed_message', None)
    failed_items = request.session.get('failed_items', None)
    return render(request, 'spectrum_job_add_failure.html', {
        'failed_message': failed_message, 'failed_items': failed_items})

def spectrum_build_business_case(request, job_id):
    #set up service url and initialize data-json
    spectrum_url = ""
    #spectrum_url = ""
    job_id = job_id
    addedby = request.user.username
    data = {
        "f":"json",
        "text": "",
        "objectIds": "",
        "time": "",
        "geometry": "",
        "geometryType": "esriGeometryEnvelope",
        "inSR": "",
        "spatialRel": "esriSpatialRelIntersects",
        "relationParam": "",
        "where": "JOB_ID = '" + job_id + "'",
        "outFields": "*",
        "returnGeometry": "FALSE",
        "returnTrueCurves": "FALSE",
        "maxAllowableOffset": "",
        "geometryPrecision": "",
        "outSR": "",
        "returnIdsOnly": "FALSE",
        "returnCountOnly": "FALSE",
        "orderByFields": "",
        "groupByFieldsForStatistics": "",
        "outStatistics": "",
        "returnZ": "FALSE",
        "returnM": "FALSE",
        "gdbVersion": "",
        "returnDistinctValues": "FALSE",
        "resultOffset": "",
        "resultRecordCount": "",
        "queryByDistance": "",
        "returnExtentsOnly": "FALSE",
        "datumTransformation": "",
        "parameterValues": "",
        "rangeValues": "",
        }
    encoded_data            = urllib.parse.urlencode(data).encode('utf-8')
    spectrum_request        = urllib.request.Request(spectrum_url)
    spectrum_request.data   = encoded_data
    response                = urllib.request.urlopen(spectrum_request).read()
    summary                 = json.loads(response.decode('utf-8'))

    if len(summary['features']) > 0:
        job_name = summary['features'][0]['attributes']['JOB_NAME']
        total_cost = ifnull(summary['features'][0]['attributes']['TOTAL_COST'], 0)
        creator_email = summary['features'][0]['attributes']['CREATOR_EMAIL']
        build_type = summary['features'][0]['attributes']['BUILD_TYPE']
        region_code = summary['features'][0]['attributes']['REGION_CODE']
    else:
        failed_items = job_id
        failed_message = 'This JOB_ID has no data. Please edit and try again.'
        request.session['failed_message'] = failed_message
        request.session['failed_items'] = failed_items
        return redirect('spectrum_job_add_failure')

    ### Check to see if this JOB has a logged in user ###
    if not addedby:
        failed_items = ''
        failed_message = '''Please login to the miBuilds Web Application before
            trying to complete a Spectrum build.'''
        request.session['failed_message'] = failed_message
        request.session['failed_items'] = failed_items
        return redirect('spectrum_job_add_failure')

    ### Check to see if this JOB_ID has been used to create a different build ###
    sql = (''' EXEC BI_MIP.miBuilds.services_spectrum_job_id_unique_df
                            @job_id = '{}'
                    ''').format(job_id)
    sql_df = pd.read_sql(sql, connection)
    if len(sql_df.index) > 0:
        failed_items = job_id
        failed_message = '''This JOB_ID has previously been used to create
            a Business Case. Please edit and try again.'''
        request.session['failed_message'] = failed_message
        request.session['failed_items'] = failed_items
        return redirect('spectrum_job_add_failure')

    ### Check to see if this JOB_NAME has been used to create a different build ###
    sql = (''' EXEC BI_MIP.miBuilds.services_probuild_name_unique_df
                            @job_name = '{}'
            ''').format(job_name)
    sql_df = pd.read_sql(sql, connection)
    if len(sql_df.index) > 0:
        failed_items = sql_df.to_html(index=False)
        failed_message = '''This Probuild Name has previously been used
            to create a Business Case. Please edit and try again.'''
        request.session['failed_message'] = failed_message
        request.session['failed_items'] = failed_items
        return redirect('spectrum_job_add_failure')

    create_sql = (''' EXEC BI_MIP.miBuilds.services_probuild_create
                        	@job_id = '{}'
                        	,@job_name = '{}'
                        	,@build_type = '{}'
                        	,@region_code = '{}'
                            ,@addedby = '{}'
                    ''')
    create_sql = create_sql.format(job_id, job_name, build_type,
                    region_code, addedby)
    connection.cursor().execute(create_sql)

    #### Get the Probuild ID of the business case just created ####
    sql = (''' EXEC BI_MIP.miBuilds.services_probuild_id_where_spectrum_job_id_df
                        @job_id = '{}'
                ''').format(job_id)
    df = pd.read_sql(sql, connection)
    probuild_id = df['probuild_id'].values[0]

    #### Update business case with assumptions ####
    sql = (''' EXEC BI_MIP.miBuilds.services_probuild_assumptions_update
                        @probuild_id = {}
                ''').format(probuild_id)
    connection.cursor().execute(sql)

    ### Insert buildings and businesses for the business case ####
    spectrum_building_business_get_insert(request, job_id, job_name, probuild_id, addedby)
    ### Update the row cost for the business case ####
    row_cost = spectrum_row_cost_get_update(request, job_id, probuild_id)
    ### Update the lateral cost for the business case ####
    lateral_cost = spectrum_lateral_cost_get(request, job_id)
    ### Update the private_property_cost for the business case ####
    spectrum_private_property_cost_update(probuild_id, lateral_cost)

    return redirect('business_case_edit', probuild_id)

def spectrum_building_business_get_insert(request, job_id, job_name, probuild_id, addedby):
    spectrum_url = ""
    #spectrum_url = ""
    data = {
        "f":"json",
        "text": "",
        "objectIds": "",
        "time": "",
        "geometry": "",
        "geometryType": "esriGeometryEnvelope",
        "inSR": "",
        "spatialRel": "esriSpatialRelIntersects",
        "relationParam": "",
        "where": "JOB_ID = '" + job_id + "'",
        "outFields": "*",
        "returnGeometry": "FALSE",
        "returnTrueCurves": "FALSE",
        "maxAllowableOffset": "",
        "geometryPrecision": "",
        "outSR": "",
        "returnIdsOnly": "FALSE",
        "returnCountOnly": "FALSE",
        "orderByFields": "",
        "groupByFieldsForStatistics": "",
        "outStatistics": "",
        "returnZ": "FALSE",
        "returnM": "FALSE",
        "gdbVersion": "",
        "returnDistinctValues": "FALSE",
        "resultOffset": "",
        "resultRecordCount": "",
        "queryByDistance": "",
        "returnExtentsOnly": "FALSE",
        "datumTransformation": "",
        "parameterValues": "",
        "rangeValues": "",
        }
    encoded_data            = urllib.parse.urlencode(data).encode('utf-8')
    spectrum_request        = urllib.request.Request(spectrum_url)
    spectrum_request.data   = encoded_data
    response                = urllib.request.urlopen(spectrum_request).read()
    buildings               = json.loads(response.decode('utf-8'))

    ### Get a list of buildings from the Spectrum call ###
    buildings_list = []
    for i in buildings['features']:
        buildings_list.append(str(i['attributes']['MIP_BUILDING_ID']))

    buildings_list = list(set(filter(None, buildings_list)))
    buildings = ",".join(buildings_list)

    ### Check to make sure there are businesses
    if len(buildings_list) == 0:
        request.session['successful_message'] = ''
        request.session['successful_items'] = ''
        request.session['upload_failed_message'] = ''
        request.session['upload_failed_items'] = ''
        request.session['failed_message'] = 'There were no buildings to load.'
        request.session['failed_items'] = ''
        return redirect('building_add_upload_failure', probuild_id)
    else:
        ### Match the buildings to the MIP table and write
        ### information to the Application table ###
        upload_sql = (''' EXEC BI_MIP.miBuilds.views_building_add_upload_df
                            @probuild_id = '{}',
                            @addedby = '{}',
                            @nax_building_id_list = '{}'
                    ''')
        upload_sql = upload_sql.format(probuild_id, addedby, buildings)
        upload_df = pd.read_sql(upload_sql, connection)
        ### Write to the buildings to the DB ###
        engine = settings.DB_ENGINE
        upload_df.to_sql(name='app_Building', con=engine,
            schema='miBuilds', if_exists='append', index=False)

    #### Insert business into table based on building ids ####
    sql = (''' EXEC BI_MIP.miBuilds.services_business_insert
                        @probuild_id = {},
                        @addedby = '{}'
                ''').format(probuild_id, addedby)
    connection.cursor().execute(sql)

def spectrum_row_cost_get_update(request, job_id, probuild_id):
    spectrum_url = ""
    #spectrum_url = ""
    data = {
        "f":"json",
        "text": "",
        "objectIds": "",
        "time": "",
        "geometry": "",
        "geometryType": "esriGeometryEnvelope",
        "inSR": "",
        "spatialRel": "esriSpatialRelIntersects",
        "relationParam": "",
        "where": "JOB_ID = '" + job_id + "'",
        "outFields": "*",
        "returnGeometry": "FALSE",
        "returnTrueCurves": "FALSE",
        "maxAllowableOffset": "",
        "geometryPrecision": "",
        "outSR": "",
        "returnIdsOnly": "FALSE",
        "returnCountOnly": "FALSE",
        "orderByFields": "",
        "groupByFieldsForStatistics": "",
        "outStatistics": "",
        "returnZ": "FALSE",
        "returnM": "FALSE",
        "gdbVersion": "",
        "returnDistinctValues": "FALSE",
        "resultOffset": "",
        "resultRecordCount": "",
        "queryByDistance": "",
        "returnExtentsOnly": "FALSE",
        "datumTransformation": "",
        "parameterValues": "",
        "rangeValues": "",
        }
    encoded_data            = urllib.parse.urlencode(data).encode('utf-8')
    spectrum_request        = urllib.request.Request(spectrum_url)
    spectrum_request.data   = encoded_data
    response                = urllib.request.urlopen(spectrum_request).read()
    summary                 = json.loads(response.decode('utf-8'))

    i = 0
    row_cost = 0
    if len(summary['features']) > 0:
        while i < len(summary['features']):
            row_cost += summary['features'][i]['attributes']['TOTAL_COST']
            i = i + 1
    else:
        row_cost = 0

    #### Update business case with row cost ####
    sql = (''' EXEC BI_MIP.miBuilds.services_probuild_row_cost_update
                        @probuild_id = {}
                        ,@row_cost = {}
                ''').format(probuild_id, row_cost)
    connection.cursor().execute(sql)

    return row_cost

def spectrum_lateral_cost_get(request, job_id):
    spectrum_url = ""
    #spectrum_url = ""
    data = {
        "f":"json",
        "text": "",
        "objectIds": "",
        "time": "",
        "geometry": "",
        "geometryType": "esriGeometryEnvelope",
        "inSR": "",
        "spatialRel": "esriSpatialRelIntersects",
        "relationParam": "",
        "where": "JOB_ID = '" + job_id + "'",
        "outFields": "*",
        "returnGeometry": "FALSE",
        "returnTrueCurves": "FALSE",
        "maxAllowableOffset": "",
        "geometryPrecision": "",
        "outSR": "",
        "returnIdsOnly": "FALSE",
        "returnCountOnly": "FALSE",
        "orderByFields": "",
        "groupByFieldsForStatistics": "",
        "outStatistics": "",
        "returnZ": "FALSE",
        "returnM": "FALSE",
        "gdbVersion": "",
        "returnDistinctValues": "FALSE",
        "resultOffset": "",
        "resultRecordCount": "",
        "queryByDistance": "",
        "returnExtentsOnly": "FALSE",
        "datumTransformation": "",
        "parameterValues": "",
        "rangeValues": "",
        }
    encoded_data            = urllib.parse.urlencode(data).encode('utf-8')
    spectrum_request        = urllib.request.Request(spectrum_url)
    spectrum_request.data   = encoded_data
    response                = urllib.request.urlopen(spectrum_request).read()
    summary                 = json.loads(response.decode('utf-8'))

    i = 0
    lateral_cost = 0
    if len(summary['features']) > 0:
        while i < len(summary['features']):
            lateral_cost += summary['features'][i]['attributes']['TOTAL_COST']
            i = i + 1
    else:
        lateral_cost = 0

    return lateral_cost


def spectrum_private_property_cost_update(probuild_id, lateral_cost):
    private_property_cost = lateral_cost

    sql = (''' EXEC BI_MIP.miBuilds.services_probuild_private_property_cost_update
                        @probuild_id = {}
                        ,@private_property_cost = {}
                ''').format(probuild_id, private_property_cost)
    connection.cursor().execute(sql)
