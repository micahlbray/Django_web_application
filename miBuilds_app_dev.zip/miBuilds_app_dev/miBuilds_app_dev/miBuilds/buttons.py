from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.db import connection
from miBuilds.utils import( ifnull,
                            strDollarToDecimal,
                            strPercentToDecimal,
                            cashflowTableHTMLstyle,
                            )
import pandas as pd

def business_case_check_available(probuild_id):
    sql = (''' EXEC BI_MIP.miBuilds.buttons_check_available_df
                            @probuild_id = '{}'
                    ''').format(probuild_id)
    df = pd.read_sql(sql, connection)
    df = df.fillna(0)
    return df
