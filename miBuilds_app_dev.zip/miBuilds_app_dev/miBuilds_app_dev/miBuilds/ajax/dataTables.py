from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.forms.models import model_to_dict
from django.db import connection
import pandas as pd
from io import TextIOWrapper

######################################################################
# Functions to handle Business Case Select screen
######################################################################
### Search ###
def get_search_results_business_case_detail(request):
    region_id = request.GET.get('region_id', None)
    search_type_id = request.GET.get('search_type_id', None)
    search_value = request.GET.get('search_value', None)
    sql = (''' EXEC BI_MIP.miBuilds.search_master_controller_df
                @region_id = '{}'
                ,@search_type_id = '{}'
                ,@search_value = '{}'
            ''').format(region_id, search_type_id, search_value)
    df = pd.read_sql(sql, connection)
    df.fillna('', inplace=True)
    data = df.to_dict('records')
    return JsonResponse(data, safe=False)

### Varying Status ###
def get_pending_business_case_detail(request):
    region_id = request.GET.get('region_id', None)
    sql = (''' EXEC BI_MIP.miBuilds.ajax_pending_business_case_detail_df_DEV
                @region_id = {}
            ''').format(region_id)
    df = pd.read_sql(sql, connection)
    df.fillna('', inplace=True)
    data = df.to_dict('records')
    return JsonResponse(data, safe=False)

def get_submitted_business_case_detail(request):
    region_id = request.GET.get('region_id', None)
    sql = (''' EXEC BI_MIP.miBuilds.ajax_submitted_business_case_detail_df_DEV
                @region_id = {}
            ''').format(region_id)
    df = pd.read_sql(sql, connection)
    df.fillna('', inplace=True)
    data = df.to_dict('records')
    return JsonResponse(data, safe=False)

def get_approved_business_case_detail(request):
    region_id = request.GET.get('region_id', None)
    sql = (''' EXEC BI_MIP.miBuilds.ajax_approved_business_case_detail_df_DEV
                @region_id = {}
            ''').format(region_id)
    df = pd.read_sql(sql, connection)
    df.fillna('', inplace=True)
    data = df.to_dict('records')
    return JsonResponse(data, safe=False)

######################################################################
# Functions to handle Business Case Edit screen
######################################################################
def get_related_business_case_detail(request):
    probuild_id = request.GET.get('probuild_id', None)
    sql = (''' EXEC BI_MIP.miBuilds.ajax_related_business_case_detail_df
                @probuild_id = {}
            ''').format(probuild_id)
    df = pd.read_sql(sql, connection)
    data = df.to_dict('records')
    return JsonResponse(data, safe=False)

######################################################################
# Functions to handle Building screens
######################################################################
def get_building_add_detail(request):
    probuild_id = request.GET.get('probuild_id', None)
    sql = (''' EXEC BI_MIP.miBuilds.ajax_building_add_detail_df
                @probuild_id = {}
            ''').format(probuild_id)
    df = pd.read_sql(sql, connection)
    df.fillna('', inplace=True)
    data = df.to_dict('records')
    return JsonResponse(data, safe=False)

######################################################################
# Functions to handle Business screens
######################################################################
def get_business_add_detail(request):
    probuild_id = request.GET.get('probuild_id', None)
    sql = (''' EXEC BI_MIP.miBuilds.ajax_business_add_detail_df
                @probuild_id = {}
            ''').format(probuild_id)
    df = pd.read_sql(sql, connection)
    df.fillna('', inplace=True)
    data = df.to_dict('records')
    return JsonResponse(data, safe=False)