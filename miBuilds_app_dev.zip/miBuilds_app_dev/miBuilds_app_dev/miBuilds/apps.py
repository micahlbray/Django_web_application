from django.apps import AppConfig


class MibuildsConfig(AppConfig):
    name = 'miBuilds'
