from django import forms #ModelForm, BaseModelFormSet
from django.conf import settings
from django.utils import timezone
from django.utils.safestring import mark_safe
from django.core.exceptions import ValidationError, NON_FIELD_ERRORS
from django.utils.translation import ugettext_lazy as _
from miBuilds.models import (AppProbuild,
                            AppProbuildNote,
                            RptProbuild,
                            AppBuilding,
                            AppBuildingUpload,
                            AppBusiness,
                            AppBusinessUpload,
                            AppSfDealinhand,
                            AppMdu,
                            AppDatacenter,
                            AppDatacenterCircuitEoy,
                            AppFile,
                            AppUserFeedback,
                            RptCalculator,
                            )
from miBuilds.validators import *
import re
from decimal import Decimal
from datetime import date
from datetime import datetime

######################################################################
# Forms
######################################################################
class BusinessCaseAddSuccessForm(forms.Form):
    probuild_id = forms.IntegerField()

class BusinessCaseSelectForm(forms.ModelForm):
    class Meta:
        model = AppProbuild
        fields = ('probuild_id','name','region',
                    'addedon','addedby','submittedon','submittedby',
                    'approvedon','approvedby')

class BusinessCaseAddForm(forms.ModelForm):
    class Meta:
        model = AppProbuild
        fields = '__all__'
        widgets = {'cross_functional_review_on': forms.DateInput(
                            attrs={'type': 'date'}),
                    'est_compl_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'roe_gate_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'permitting_gate_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'access_fees_one_time': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'access_fees_monthly': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'customer_contribution': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'row_est_build_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'headend_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'transport_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'private_property_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'lateral_construct_upfront_pct': forms.TextInput(
                        attrs={'placeholder': '###.##%'}),
                    'smb_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'ent_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'smb_12mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.##%'}),
                    'smb_36mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.##%'}),
                    'ent_12mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.##%'}),
                    'ent_36mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.##%'}),
                    'roe_gate': forms.NumberInput(),
                    #'spectrum_job_id': forms.HiddenInput(),
                    'region_assump': forms.HiddenInput(),
                    'mdu_build_region_assump': forms.HiddenInput(),
                    'added': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'edited': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'submitted': forms.HiddenInput(),
                    'submittedon': forms.HiddenInput(),
                    'submittedby': forms.HiddenInput(),
                    'approved': forms.HiddenInput(),
                    'approvedon': forms.HiddenInput(),
                    'approvedby': forms.HiddenInput(),
                    'todelete': forms.HiddenInput(),
                    'todeleteon': forms.HiddenInput(),
                    'todeleteby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                    'parent_probuild_id': forms.HiddenInput(),
                    'cloned': forms.HiddenInput(),
                    'clonedon': forms.HiddenInput(),
                    'clonedby': forms.HiddenInput(),
                    'child': forms.HiddenInput(),
                    'childon': forms.HiddenInput(),
                    'childby': forms.HiddenInput(),
                    'legacy': forms.HiddenInput(),
        }
        help_texts = {
            'name': _('Please pick a unique name.'),
        }

    #def clean_ent_arpu(self):
    #      value = strDollarToDecimal(self.cleaned_data['ent_arpu'])
    #      return value

class BusinessCaseRptForm(forms.ModelForm):
    class Meta:
        model = RptProbuild
        fields = '__all__'
        widgets = {'probuild': forms.HiddenInput(),
                    'roe_target': forms.NumberInput(),
                    'roe_needed': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'roe_acquired': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'lateral_construct_upfront_pct': forms.TextInput(
                        attrs={ 'placeholder': '###.#%'}),
                    'fund_bucket': forms.TextInput(
                        attrs={'readonly':'readonly'}),
                    'business_capital_pct': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'resi_capital_pct': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'business_max_actual_capital': forms.HiddenInput(),
                    'resi_max_actual_capital': forms.HiddenInput(),
                    'smb_qb_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'ent_qb_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'building_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'multi_tenant_building_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'dealinhand_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'mdu_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'datacenter_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'car_value': forms.HiddenInput(),
                    'irr_pct': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'irr_pct_less_he_trnsprt': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'npv': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'npv_less_he_trnsprt': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'payback_mo': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'passing_cost_per': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'additional_osp_lateral_cost_per_connect': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'row_car_value': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'lat_car_value': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'total_car_value': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                }

class BusinessCaseEditForm(forms.ModelForm):
    class Meta:
        model = AppProbuild
        fields = '__all__'
        widgets = { 'cross_functional_review_on': forms.DateInput(
                            attrs={'type': 'date'}),
                    'est_compl_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'roe_gate_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'permitting_gate_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'access_fees_one_time': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'access_fees_monthly': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'customer_contribution': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'row_est_build_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'headend_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'transport_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'private_property_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'lateral_construct_upfront_pct': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'smb_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'ent_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'smb_12mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'smb_36mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'ent_12mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'ent_36mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'roe_gate': forms.NumberInput(),
                    'probuild_id': forms.HiddenInput(),
                    'spectrum_job_id': forms.HiddenInput(),
                    'region_assump': forms.HiddenInput(),
                    'mdu_build_region_assump': forms.HiddenInput(),
                    'added': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'edited': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'submitted': forms.HiddenInput(),
                    'submittedon': forms.HiddenInput(),
                    'submittedby': forms.HiddenInput(),
                    'approved': forms.HiddenInput(),
                    'approvedon': forms.HiddenInput(),
                    'approvedby': forms.HiddenInput(),
                    'todelete': forms.HiddenInput(),
                    'todeleteon': forms.HiddenInput(),
                    'todeleteby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                    'parent_probuild_id': forms.HiddenInput(),
                    'cloned': forms.HiddenInput(),
                    'clonedon': forms.HiddenInput(),
                    'clonedby': forms.HiddenInput(),
                    'child': forms.HiddenInput(),
                    'childon': forms.HiddenInput(),
                    'childby': forms.HiddenInput(),
                    'legacy': forms.HiddenInput(),
        }
        help_texts = {
            'jt_id': _('Required to submit'),
            'est_compl_dt': _('Required to submit'),
            'roe_gate_dt': _('Required to submit'),
            'permitting_gate_dt': _('Required to submit'),
        }
        error_messages = {
            'jt_id': {
                'required': _('Please enter a value to complete submission')
            },
            'est_compl_dt':{
                'required': _('Please enter a value to complete submission')
            },
            'roe_gate_dt': {
                'required': _('Please enter a value to complete submission')
            },
            'permitting_gate_dt': {
                'required': _('Please enter a value to complete submission')
            },
        }

class BusinessCaseEditApprovedForm(forms.ModelForm):
    class Meta:
        model = AppProbuild
        fields = '__all__'
        widgets = { 'cross_functional_review_on': forms.DateInput(
                            attrs={'type': 'date'}),
                    'est_compl_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'roe_gate_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'permitting_gate_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'customer_contribution': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00'}),
                    'access_fees_one_time': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00'}),
                    'access_fees_monthly': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00'}),
                    'row_est_build_cost': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00'}),
                    'headend_cost': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00'}),
                    'transport_cost': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00'}),
                    'private_property_cost': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00'}),
                    'lateral_construct_upfront_pct': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'smb_arpu': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00'}),
                    'ent_arpu': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00'}),
                    'smb_12mo_pen': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'smb_36mo_pen': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'ent_12mo_pen': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'ent_36mo_pen': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'roe_gate': forms.NumberInput(),
                    'probuild_id': forms.HiddenInput(),
                    'spectrum_job_id': forms.HiddenInput(),
                    'region_assump': forms.HiddenInput(),
                    'mdu_build_region_assump': forms.HiddenInput(),
                    'added': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'edited': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'submitted': forms.HiddenInput(),
                    'submittedon': forms.HiddenInput(),
                    'submittedby': forms.HiddenInput(),
                    'approved': forms.HiddenInput(),
                    'approvedon': forms.HiddenInput(),
                    'approvedby': forms.HiddenInput(),
                    'todelete': forms.HiddenInput(),
                    'todeleteon': forms.HiddenInput(),
                    'todeleteby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                    'parent_probuild_id': forms.HiddenInput(),
                    'cloned': forms.HiddenInput(),
                    'clonedon': forms.HiddenInput(),
                    'clonedby': forms.HiddenInput(),
                    'child': forms.HiddenInput(),
                    'childon': forms.HiddenInput(),
                    'childby': forms.HiddenInput(),
                    'legacy': forms.HiddenInput(),
        }
        help_texts = {
            'jt_id': _('Required to submit'),
            'est_compl_dt': _('Required to submit'),
            'roe_gate_dt': _('Required to submit'),
            'permitting_gate_dt': _('Required to submit'),
        }
        error_messages = {
            'jt_id': {
                'required': _('Please enter a value to complete submission')
            },
            'est_compl_dt':{
                'required': _('Please enter a value to complete submission')
            },
            'roe_gate_dt': {
                'required': _('Please enter a value to complete submission')
            },
            'permitting_gate_dt': {
                'required': _('Please enter a value to complete submission')
            },
        }

class BusinessCaseRptApprovedForm(forms.ModelForm):
    class Meta:
        model = RptProbuild
        fields = '__all__'
        widgets = {'probuild': forms.HiddenInput(),
                    'roe_target': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'roe_needed': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'roe_acquired': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'lateral_construct_upfront_pct': forms.TextInput(
                        attrs={ 'placeholder': '###.#%'}),
                    'fund_bucket': forms.TextInput(
                        attrs={'readonly':'readonly'}),
                    'business_capital_pct': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'resi_capital_pct': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'business_max_actual_capital': forms.HiddenInput(),
                    'resi_max_actual_capital': forms.HiddenInput(),
                    'smb_qb_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'ent_qb_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'building_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'multi_tenant_building_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'dealinhand_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'mdu_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'datacenter_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'car_value': forms.HiddenInput(),
                    'irr_pct': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'irr_pct_less_he_trnsprt': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'npv': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'npv_less_he_trnsprt': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'payback_mo': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'passing_cost_per': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'additional_osp_lateral_cost_per_connect': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'row_car_value': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'lat_car_value': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'total_car_value': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                }

class BusinessCaseNoteAddForm(forms.ModelForm):
    class Meta:
        model = AppProbuildNote
        fields = '__all__'
        widgets = {'probuild': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }
        help_texts = {
            'building_id': _('Please leave blank if there is no ID.'),
        }
