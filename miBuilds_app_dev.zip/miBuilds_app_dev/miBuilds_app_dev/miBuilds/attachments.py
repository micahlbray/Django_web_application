from django.shortcuts import render, redirect, get_object_or_404
from django.db import connection
from miBuilds.models import AppProbuild
from miBuilds.utils import set_col_widths
import pandas as pd
import sqlalchemy, csv, codecs, urllib
from io import TextIOWrapper, StringIO, BytesIO

def construction_business_case_summary(probuild_id):
    probuild_id = probuild_id
    probuild_name = AppProbuild.objects.values_list('name',
        flat=True).filter(probuild_id=probuild_id)[0]
    sql = (''' EXEC BI_MIP.miBuilds.construction_business_case_financial_summary_df
                    @probuild_id = '{}'
            ''').format(probuild_id)
    financial_df = pd.read_sql(sql, connection)

    sql = (''' EXEC BI_MIP.miBuilds.construction_business_case_building_summary_df
                    @probuild_id = '{}'
            ''').format(probuild_id)
    building_df = pd.read_sql(sql, connection)

    sql = (''' EXEC BI_MIP.miBuilds.construction_business_case_business_summary_df
                    @probuild_id = '{}'
            ''').format(probuild_id)
    business_df = pd.read_sql(sql, connection)

    ################### Write Dataframes to sheets ######################
    #####################################################################
    filename = probuild_name + '_construction_business_case_summary' + '.xlsx'
    financial_sheetname = 'financial_summary'
    building_sheetname = 'building_summary'
    business_sheetname = 'business_summary'

    bio = BytesIO()
    writer = pd.ExcelWriter(bio,
                            engine='xlsxwriter',
                            datetime_format='mm/dd/yyyy',
                            date_format='mm/dd/yyyy')
    financial_df.to_excel(writer, sheet_name=financial_sheetname, index=False)
    building_df.to_excel(writer, sheet_name=building_sheetname, index=False)
    business_df.to_excel(writer, sheet_name=business_sheetname, index=False)

    ################### FORMATTING ######################
    ####################################################
    workbook = writer.book
    workbook_format = workbook.add_format({
        'font_name': 'Century Gothic',
        'font_size': 10,
        'align': 'center',
        'valign': 'vcenter'})
    header_format = workbook.add_format({
        'font_name': 'Century Gothic',
        'font_size': 10,
        'font_color': '#FFFFFF',
        'bold': True,
        'text_wrap': False,
        'align': 'center',
        'valign': 'vcenter',
        'fg_color': '#0050b9'})


    #worksheet = workbook.add_worksheet()
    #worksheet.insert_image('A1','C:/Users/mbray201/Desktop/market_intelligence/miBuilds/DataCenter Issue.PNG')

    df_dict = {financial_sheetname: financial_df,
                building_sheetname: building_df,
                business_sheetname: business_df}
    for sheetname, df in df_dict.items():
        worksheet = writer.sheets[sheetname]
    ### use function to "autofit" column width
        set_col_widths(df, worksheet, workbook_format)
    ### loop through dataframe to format headers
        for col, value in enumerate(df.columns.values):
            worksheet.write(0, col, value, header_format)

    writer.save()

    bio.seek(0)
    workbook = bio.getvalue()
    content_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'

    return filename, workbook, content_type
