from django.core.mail import (send_mail,
                             BadHeaderError,
                             EmailMessage,
                             EmailMultiAlternatives,
                             )
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.utils.translation import ugettext_lazy as _
from django.db import connection
from smtplib import SMTPException
#from miBuilds.views import (email_send_failure)
from miBuilds.models import (LkRegion)
from miBuilds.attachments import (construction_business_case_summary)
import pandas as pd

def email_probuild(request):
    probuild_name = request.POST.get('name', None)
    probuild_id = request.POST.get('probuild_id', None)
    submittedby = request.POST.get('submittedby', None)
    submittedon = request.POST.get('submittedon', None)
    fund_bucket = request.POST.get('fund_bucket', None)
    region_id = request.POST.get('region', None)
    jt_id = request.POST.get('jt_id', None)
    ic_takeaway = request.POST.get('investment_committee_takeaway', None)
    probuild_url = (
                    "http://codccmiplatform:8080/miBuilds/business_case/"
                    + str(probuild_id)
                    + "/edit/"
                    )

    return (probuild_name, probuild_id, submittedby, submittedon,
            fund_bucket, region_id, jt_id, ic_takeaway, probuild_url)

def email_request(request):
    request_user_id = request.user.id
    request_username = request.user.username
    request_user_email = request.user.email
    request_submitted = str(timezone.localtime(timezone.now()))

    return request_user_id, request_username, request_user_email, request_submitted

def email_distro(region_id):
    distro_sql = (''' EXEC BI_MIP.miBuilds.emails_distribution_df
                            @region_id = {}
                ''').format(region_id)
    distro_df = pd.read_sql(distro_sql, connection)

    lead_email = distro_df['lead_email'].values[0]
    lead_backup_email = distro_df['lead_backup_email'].values[0]
    invest_committ_email_distro = distro_df['invest_committ_email_distro'].values[0]
    construction_email = distro_df['construction_email'].values[0]
    review_email = distro_df['review_email'].values[0]

    return (lead_email, lead_backup_email, invest_committ_email_distro,
            construction_email, review_email)

def email_files(probuild_id):
    files_sql = ('''    select root + path as file_path
                        from app_File
                        where probuild_id = {}
                            and isnull(Deleted,0) = 0
                ''').format(probuild_id)
    files_df = pd.read_sql(files_sql, connection)

    return files_df

def send_approval_email(request):
    (probuild_name, probuild_id, submittedby, submittedon,
    fund_bucket, region_id, jt_id, ic_takeaway, probuild_url) = email_probuild(request)

    (request_user_id, request_username,
    request_user_email, request_submitted) = email_request(request)

    if fund_bucket == 'Division':
        region_id = 7
        (lead_email, lead_backup_email, invest_committ_email_distro,
        construction_email, review_email) = email_distro(region_id)
        region_email = LkRegion.objects.values_list(
            'invest_committ_email_distro', flat=True).filter(
            region_id = request.POST.get('region', None))[0]
    else:
        region_id = region_id
        (lead_email, lead_backup_email, invest_committ_email_distro,
        construction_email, review_email) = email_distro(region_id)
        region_email = 'micah_bray@comcast.com;'

    #email_subject = probuild_name + " Approved"
    email_subject = "Important Message From miBuilds Web App Regarding: " + probuild_name
    email_body = ("User " + request_username + " Just Approved A Business Case"
                    + "\n\n\tBusiness Case Name: " + probuild_name
                    + "\n\tBusiness Case Link: " + probuild_url
                    + "\n\tApproved By: " + request_username
                    + "\n\tApproved On: " + request_submitted[:10]
                    + "\n\tSubmitted By: " + submittedby
                    + "\n\tSubmitted On: " + submittedon
                    + "\n\tJT Id: " + jt_id
                    + "\n\tIC Takeaway: " + ic_takeaway
                    )
    email_from = request_user_email
    email_to = [lead_email, lead_backup_email, invest_committ_email_distro,
                region_email]
    email_to = set([x for x in email_to if x is not None])
    email_cc = [request_user_email]
    email_construction = [construction_email]

    email = EmailMessage(
        email_subject,
        email_body,
        from_email=email_from,
        to=email_to,
        #cc=email_cc,
        )

    #### Attach the excel summary
    (filename, workbook,
    content_type) = construction_business_case_summary(probuild_id)
    email.attach(filename, workbook, content_type)

    sent = email.send(fail_silently=False)
    while sent < 1:
        sent = email.send(fail_silently=False)

    email = EmailMessage(
        email_subject,
        email_body,
        from_email=email_from,
        to=email_construction,
        #cc=email_cc,
        )

    #### Attach the excel summary
    (filename, workbook,
    content_type) = construction_business_case_summary(probuild_id)
    email.attach(filename, workbook, content_type)

    #### Attach all known files to email
    files_df = email_files(probuild_id)
    for i in range(len(files_df.index)):
        email.attach_file(files_df['file_path'].values[i])

    sent = email.send(fail_silently=False)
    while sent < 1:
        sent = email.send(fail_silently=False)

def send_submit_email(request):
    (probuild_name, probuild_id, submittedby, submittedon,
    fund_bucket, region_id, jt_id, ic_takeaway, probuild_url) = email_probuild(request)

    (request_user_id, request_username,
    request_user_email, request_submitted) = email_request(request)

    region_id = region_id
    (lead_email, lead_backup_email, invest_committ_email_distro,
    construction_email, review_email) = email_distro(region_id)

    email_subject = "Important Message From miBuilds Web App Regarding: " + probuild_name
    email_body = (  "User " + request_username + " Just Submitted A Business Case For Review"
                    + "\n\n\tBusiness Case Name: " + probuild_name
                    + "\n\tBusiness Case Link: " + probuild_url
                    + "\n\tSubmitted By: " + request_username
                    + "\n\tSubmitted On: " + request_submitted[:10]
                    + "\n\tJT Id: " + jt_id
                    )
    email_from = request_user_email
    email_to = [review_email]
    email_to = set([x for x in email_to if x is not None])
    email_cc = [request_user_email]

    email = EmailMessage(
            email_subject,
            email_body,
            from_email=email_from,
            to=email_to,
            cc=email_cc,
            )

    try:
        sent = email.send(fail_silently=False)
        while sent < 1:
            sent = email.send(fail_silently=False)
    except SMTPException as e:
        request.session['failed_message'] = email_subject
        request.session['failed_items'] = email_body
        return redirect('email_send_failure', probuild_id=probuild_id)

def send_note_email(request):
    (request_user_id, request_username,
    request_user_email, request_submitted) = email_request(request)

    probuild_note_id = request.GET.get('probuild_note_id')
    addedby = request.GET.get('addedby')
    note = request.GET.get('note')
    note_type = request.GET.get('note_type')

    addedby_info_sql = (''' SELECT a.email as addedby_email
                        FROM    BI_MIP.miBuilds.auth_user as a
                        WHERE   username = '{}'
                        '''
                        ).format(addedby)
    addedby_info_df = pd.read_sql(addedby_info_sql, connection)
    addedby_email = addedby_info_df['addedby_email'].values[0]

    probuild_info_sql = (''' SELECT a.probuild_id
                                    ,a.name as probuild_name
                            FROM    BI_MIP.miBuilds.app_Probuild as a
                                JOIN BI_MIP.miBuilds.app_Probuild_Note as b
                                ON a.Probuild_Id = b.Probuild_Id
                            WHERE   b.Probuild_Note_Id = {}'''
                        )
    probuild_info_sql = probuild_info_sql.format(probuild_note_id)
    probuild_info_df = pd.read_sql(probuild_info_sql, connection)
    probuild_id = probuild_info_df['probuild_id'].values[0]
    probuild_name = probuild_info_df['probuild_name'].values[0]

    email_subject = "Important Message From miBuilds Web Regarding: " + probuild_name
    email_body = ("User " + request_username + " Is Sending You A miBuilds Note"
                + "\n\n\tProbuild Name: " + probuild_name
                + "\n\tNote Type: " + note_type
                + "\n\tNote: " + note
            )
    email_from = request_user_email
    email_to = [addedby_email]
    email_cc = [request_user_email]

    email = EmailMessage(
        email_subject,
        email_body,
        from_email=email_from,
        to=email_to,
        cc=email_cc,
    )

    sent = email.send(fail_silently=False)
    while sent < 1:
        sent = email.send(fail_silently=False)
