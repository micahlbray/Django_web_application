from django.db.models import Sum, Max, Count
from django.db import connection
from miBuilds.models import (AppProbuild,
                            AppBuilding,
                            AppBusiness,
                            AppSfDealinhand,
                            AppMdu,
                            AppDatacenter,
                            AppFile,
                            AssumpRegion,
                            AssumpMduBuildRegion,
                            AssumpMduBuild,
                            AssumpSegment,
                            AssumpDataCenterType,
                            AssumpDataCenterEquipType,
                            AssumpDataCenterCircuitEoy,
                            LkRegion,
                            LkState,
                            LkDataCenterEquipType,
                            LkSegmentType,
                            LkBuildingType,
                            LkDwellingType,
                            )
from miBuilds.utils import(ifnull, strDollarToDecimal, strPercentToDecimal)
import numpy as np
import pandas as pd
import codecs, json, sqlalchemy, urllib, math

######################################################################
# Build Cashflows for Data Center
######################################################################
def build_child_data_center_consol_curves(request):
    data_center_inputs = prep_child_data_center_inputs(request)
    data_center_circuits = build_child_data_center_circuits(data_center_inputs)
    data_center_curves = build_child_data_center_curves(data_center_inputs, data_center_circuits)
    data_center_consol_circuits = build_child_data_center_consol_circuits(data_center_circuits)
    data_center_consol_rev = build_child_data_center_consol_rev(data_center_curves)
    data_center_consol_opex = build_child_data_center_consol_opex(data_center_curves)
    data_center_consol_cashflow = build_child_data_center_consol_cashflow(data_center_curves)

    return data_center_consol_rev, data_center_consol_opex, data_center_consol_cashflow, data_center_consol_circuits

######################################################################
# Prep Data Center data inputs for future use
######################################################################
def prep_child_data_center_inputs(request):
    try:
        if request.method == 'GET':
            probuild_id = request.GET.get('probuild_id', None)
        elif request.method == 'POST':
            probuild_id = request.POST.get('probuild_id', None)
    except:
        print("\nREQUEST:\n", request.GET)
        probuild_id = request['probuild_id']

    datacenter_id_list = AppDatacenter.objects.values_list('datacenter_id',
            flat=True).exclude(deleted=1).filter(probuild_id=probuild_id)
    inputs = {}
    data_center_inputs = {}

    i = 0
    while i < len(datacenter_id_list):
        datacenter_id = datacenter_id_list[i]

        # Create data frame
        inputs_sql = (''' SELECT data_center_type_id as data_center_type
                                ,rack as rack
                                ,equip_opex as equip_opex
                                ,colo_fee as colo
                                ,connect_cost as connect
                                ,mrr_per_circ_avg as mrr
                                ,equip_capex as equip_capex
                                ,opex_pct as opex_pct
                                ,yr1_circuit_ct
                                ,yr2_circuit_ct
                                ,yr3_circuit_ct
                                ,yr4_circuit_ct
                                ,yr5_circuit_ct
                        FROM BI_MIP.miBuilds.app_DataCenter as a
                        WHERE datacenter_id = {}
                                and ISNULL(Deleted, 0) = 0'''
                    )
        inputs_sql = inputs_sql.format(datacenter_id)
        inputs_df = pd.read_sql(inputs_sql, connection)

        # Create variables from data frame
        type = inputs_df['data_center_type'].values[0]
        yr1_ct = ifnull(inputs_df['yr1_circuit_ct'].values[0],0)
        yr2_ct = ifnull(inputs_df['yr2_circuit_ct'].values[0],0)
        yr3_ct = ifnull(inputs_df['yr3_circuit_ct'].values[0],0)
        yr4_ct = ifnull(inputs_df['yr4_circuit_ct'].values[0],0)
        yr5_ct = ifnull(inputs_df['yr5_circuit_ct'].values[0],0)
        eoy_circuit_ct = {'circuit_ct': [yr1_ct, yr2_ct,
                                yr3_ct, yr4_ct, yr5_ct]}

        ## get circuit assumptions
        circuits_sql = (''' SELECT  circuit_ct as circuit_ct
                            FROM    BI_MIP.miBuilds.assump_Data_Center_Circuit_EOY as a
                            WHERE   data_center_type_id = {}
                                    and IsActive = 1'''
                        ).format(type)
        circuits_df = pd.read_sql(circuits_sql, connection)

        inputs['rack'] = ifnull(inputs_df['rack'].values[0],0)
        inputs['power'] = ifnull(inputs_df['equip_opex'].values[0],0)
        inputs['colo'] = ifnull(inputs_df['colo'].values[0],0)
        inputs['connect'] = ifnull(inputs_df['connect'].values[0],0)
        inputs['mrr'] = ifnull(inputs_df['mrr'].values[0],0)
        inputs['opex_pct'] = ifnull(inputs_df['opex_pct'].values[0],0)
        inputs['capex'] = ifnull(inputs_df['equip_capex'].values[0],0)
        if min(eoy_circuit_ct['circuit_ct']) == 0:
            inputs['eoy_circuit_ct'] = circuits_df.to_dict('list')
        else:
            inputs['eoy_circuit_ct'] = eoy_circuit_ct

        name = 'data_center' + str(i)
        data_center_inputs[name] = {}
        data_center_inputs[name].update(inputs)

        i += 1

    return data_center_inputs

########################################################################################################
# Build Circuit curves for each Data Center and combine one Dict (data_center_circuits)
########################################################################################################
def build_child_data_center_circuits(data_center_inputs):
    data_center_circuits = {}
    data_center_calc_circuit = np.zeros(181)

    x = 0
    while x < len(data_center_inputs): # the number of data centers
        name = 'data_center' + str(x)
        data = data_center_inputs[name]

        i = 0
        for i in range(181):
            if i<=2:
                data_center_calc_circuit[i] = 0
            elif i>=3 and i<=12:
                if i % 3 == 0:
                    data_center_calc_circuit[i] = (
                                                    (data['eoy_circuit_ct']['circuit_ct'][0] / 4)
                                                    + data_center_calc_circuit[i - 1]
                                                    )
                else:
                    data_center_calc_circuit[i] = data_center_calc_circuit[i - 1]
            elif i>=13 and i<=24:
                diff = (data['eoy_circuit_ct']['circuit_ct'][1]
                            - data['eoy_circuit_ct']['circuit_ct'][0]
                            )
                if i % 3 == 0:
                    data_center_calc_circuit[i] = (diff / 4) + data_center_calc_circuit[i - 1]
                else:
                    data_center_calc_circuit[i] = data_center_calc_circuit[i - 1]
            elif i>=25 and i<=36:
                diff = (data['eoy_circuit_ct']['circuit_ct'][2]
                            - data['eoy_circuit_ct']['circuit_ct'][1]
                            )
                if i % 3 == 0:
                    data_center_calc_circuit[i] = (diff / 4) + data_center_calc_circuit[i - 1]
                else:
                    data_center_calc_circuit[i] = data_center_calc_circuit[i - 1]
            elif i>=37 and i<=48:
                diff = (data['eoy_circuit_ct']['circuit_ct'][3]
                            - data['eoy_circuit_ct']['circuit_ct'][2]
                            )
                if i % 3 == 0:
                    data_center_calc_circuit[i] = (diff / 4) + data_center_calc_circuit[i - 1]
                else:
                    data_center_calc_circuit[i] = data_center_calc_circuit[i - 1]
            elif i>=49 and i<=60:
                diff = (data['eoy_circuit_ct']['circuit_ct'][4]
                            - data['eoy_circuit_ct']['circuit_ct'][3]
                            )
                if i % 3 == 0:
                    data_center_calc_circuit[i] = (diff / 4) + data_center_calc_circuit[i - 1]
                else:
                    data_center_calc_circuit[i] = data_center_calc_circuit[i - 1]

            elif i>=61:
                data_center_calc_circuit[i] = data_center_calc_circuit[i - 1]

        data_center_circuits[name] = data_center_calc_circuit.copy()


        x += 1

    return data_center_circuits

# if i % 12 == 3: gives you the point after 12 where diff changes

########################################################################################################
# Build Rev, Opex, and Cashflow curves for each Data Center and combine into one Dict (data_center_curves)
########################################################################################################
def build_child_data_center_curves(data_center_inputs, data_center_circuits):
    data_center_curves = {}
    data_center_curves['rev'] = {}
    data_center_curves['opex'] = {}
    data_center_curves['cashflow'] = {}

    data_center_calc_rev = np.zeros(181)
    data_center_calc_opex = np.zeros(181)
    data_center_calc_cashflow = np.zeros(181)

    x = 0
    while x < len(data_center_inputs): # the number of data centers
        name = 'data_center' + str(x)
        inputs = data_center_inputs[name]
        circuits = data_center_circuits[name]

        i = 0
        for i in range(181):
            data_center_calc_rev[i] = inputs['mrr'] * circuits[i]
            i += 1

        data_center_curves['rev'][name] = data_center_calc_rev.copy()

        i = 0
        for i in range(181):
            if i < 1:
                data_center_calc_opex[i] = 0
            else:
                data_center_calc_opex[i] = ( -1 *
                                        (inputs['rack']
                                        + inputs['power']
                                        + inputs['colo']
                                        + (inputs['connect'] * (circuits[i] - circuits[i - 1]))
                                        + (data_center_calc_rev[i] * inputs['opex_pct'])
                                        )
                                        )

        data_center_curves['opex'][name] = data_center_calc_opex.copy()

        i = 0
        for i in range(181):
            if i < 1:
                data_center_calc_cashflow[i] = (
                                        ( -1 * inputs['capex'] )
                                        + data_center_calc_opex[i]
                                        + data_center_calc_rev[i]
                                        )
            else:
                data_center_calc_cashflow[i] = (data_center_calc_opex[i]
                                          + data_center_calc_rev[i])

        data_center_curves['cashflow'][name] = data_center_calc_cashflow.copy()

        x += 1

    return data_center_curves

########################################################################################################
# Build Data Center consolidated (possible n number of Data Centers) Cashflow from data_center_curves
########################################################################################################
def build_child_data_center_consol_circuits(data_center_circuits):
    data_center_consol_circuits = np.zeros(181)

    x = 0
    while x < len(data_center_circuits):
        name = 'data_center' + str(x)

        i = 0
        for i in range(181):
            data_center_consol_circuits[i] = (data_center_consol_circuits[i]
                                      + data_center_circuits[name][i])

            i += 1

        x += 1

    return data_center_consol_circuits

########################################################################################################
# Build Data Center consolidated (possible n number of Data Centers) Cashflow from data_center_curves
########################################################################################################
def build_child_data_center_consol_rev(data_center_curves):
    data_center_consol_rev = np.zeros(181)

    x = 0
    while x < len(data_center_curves['rev']):
        name = 'data_center' + str(x)

        i = 0
        for i in range(181):
            data_center_consol_rev[i] = (data_center_consol_rev[i]
                                      + data_center_curves['rev'][name][i])

            i += 1

        x += 1

    return data_center_consol_rev

########################################################################################################
# Build Data Center consolidated (possible n number of Data Centers) Cashflow from data_center_curves
########################################################################################################
def build_child_data_center_consol_opex(data_center_curves):
    data_center_consol_opex = np.zeros(181)

    x = 0
    while x < len(data_center_curves['opex']):
        name = 'data_center' + str(x)

        i = 0
        for i in range(181):
            data_center_consol_opex[i] = (data_center_consol_opex[i]
                                      + data_center_curves['opex'][name][i])

            i += 1

        x += 1

    return data_center_consol_opex

########################################################################################################
# Build Data Center consolidated (possible n number of Data Centers) Cashflow from data_center_curves
########################################################################################################
def build_child_data_center_consol_cashflow(data_center_curves):
    data_center_consol_cashflow = np.zeros(181)

    x = 0
    while x < len(data_center_curves['cashflow']):
        name = 'data_center' + str(x)

        i = 0
        for i in range(181):
            data_center_consol_cashflow[i] = (data_center_consol_cashflow[i]
                                      + data_center_curves['cashflow'][name][i])

            i += 1

        x += 1

    return data_center_consol_cashflow
