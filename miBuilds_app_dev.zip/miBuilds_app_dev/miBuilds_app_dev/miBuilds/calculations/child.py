from django.db.models import Sum, Max, Count
from django.db import connection
from miBuilds.models import (AppProbuild,
                            AppBuilding,
                            AppBusiness,
                            AppSfDealinhand,
                            AppMdu,
                            AppDatacenter,
                            AppFile,
                            AssumpRegion,
                            AssumpMduBuildRegion,
                            AssumpMduBuild,
                            AssumpSegment,
                            AssumpDataCenterType,
                            AssumpDataCenterEquipType,
                            AssumpDataCenterCircuitEoy,
                            LkRegion,
                            LkState,
                            LkDataCenterEquipType,
                            LkSegmentType,
                            LkBuildingType,
                            LkDwellingType,
                            )
from miBuilds.utils import(ifnull, strDollarToDecimal, strPercentToDecimal)
from miBuilds.calculations import child_smb_ent
from miBuilds.calculations import child_data_center
from miBuilds.calculations import child_mdu
import numpy as np
import pandas as pd
import codecs, json, sqlalchemy, urllib, math

######################################################################
# Define Arrays
######################################################################
def prep_child_consol_curves():

    consol_curves = {}

    consol_curves['rev'] = np.zeros(181)
    consol_curves['opex'] = np.zeros(181)
    consol_curves['cost'] = np.zeros(181)
    consol_curves['cashflow'] = np.zeros(181)
    consol_curves['cashflow_less_he_trnsprt'] = np.zeros(181)

    return consol_curves

######################################################################
# Build consolidated Cashflow for SMB, ENT, Data Centers, and MDUs
######################################################################
def build_child_consol_curves(request):
    smb_ent_curves = child_smb_ent.build_child_smb_ent_curves(request)

    data_center_inputs = child_data_center.prep_child_data_center_inputs(request)
    data_center_circuits = child_data_center.build_child_data_center_circuits(data_center_inputs)
    data_center_curves = child_data_center.build_child_data_center_curves(data_center_inputs, data_center_circuits)
    data_center_consol_cashflow = child_data_center.build_child_data_center_consol_cashflow(data_center_curves)

    mdu_inputs = child_mdu.prep_child_mdu_inputs(request)
    mdu_curves = child_mdu.build_child_mdu_curves(mdu_inputs)
    mdu_consol_cashflow = child_mdu.build_child_mdu_consol_cashflow(mdu_curves)

    consol_curves = prep_child_consol_curves()
    calc_cashflow = consol_curves['cashflow']
    calc_cashflow_less_he_trnsprt = consol_curves['cashflow_less_he_trnsprt']

    for i in range(181):
        calc_cashflow[i] = (smb_ent_curves['smb_ent_cashflow'][i]
                            #+ data_center_consol_cashflow[i]
                            + mdu_consol_cashflow[i]
                            )
        calc_cashflow_less_he_trnsprt[i] = (
                            smb_ent_curves['smb_ent_cashflow_less_he_trnsprt'][i]
                            #+ data_center_consol_cashflow[i]
                            + mdu_consol_cashflow[i]
                            )


    consol_curves['cashflow'] = calc_cashflow
    consol_curves['cashflow_less_he_trnsprt'] = calc_cashflow_less_he_trnsprt
    return consol_curves

######################################################################
# Calc NPV and IRR
######################################################################
def calc_child_NPV_IRR(consol_curves):
    cost_cap_pct = 0.1
    cost_cap_time = IRR_time = 12
    WACC = cost_cap_pct / cost_cap_time
    NaN_Value_NPV = -99999999.99
    NaN_Value_IRR = -99.999
    NaN_Value_IRR_HE_Trnsprt = -99.999

    NPV = np.npv(WACC, consol_curves['cashflow'])
    NPV_Less_HE_Trnsprt = np.npv(WACC, consol_curves['cashflow_less_he_trnsprt'])
    IRR = ((1 + np.irr(consol_curves['cashflow']))
                ** IRR_time
                - 1
                )
    IRR_Less_HE_Trnsprt = ((1 + np.irr(consol_curves['cashflow_less_he_trnsprt']))
                            ** IRR_time
                            - 1
                            )

    if np.isnan(NPV):
        NPV = NaN_Value_NPV
    if np.isnan(NPV_Less_HE_Trnsprt):
        NPV_Less_HE_Trnsprt = NaN_Value_NPV
    if np.isnan(IRR):
        IRR = NaN_Value_IRR
    if np.isnan(IRR_Less_HE_Trnsprt):
        IRR_Less_HE_Trnsprt = NaN_Value_IRR_HE_Trnsprt

    return NPV, NPV_Less_HE_Trnsprt, IRR, IRR_Less_HE_Trnsprt

######################################################################
# Calc CAR Value
######################################################################
def calc_child_CAR(request):
    smb_ent_inputs = child_smb_ent.prep_child_smb_ent_inputs(request)
    data_center_inputs = child_data_center.prep_child_data_center_inputs(request)

    data_center_capex = 0
    i = 0
    while i < len(data_center_inputs):
        name = 'data_center' + str(i)
        data_center_capex = (data_center_capex
                            + data_center_inputs[name]['capex']
                            )
        i += 1

    ROW_CAR = (smb_ent_inputs['row_est_build_cost']
                  + smb_ent_inputs['headend_cost']
                  + smb_ent_inputs['transport_cost']
                  + data_center_capex
                  ##### per Chris' email from 2/16/2018
                  ##### change made 5/2/2018
                  #+ (smb_ent_inputs['building_ct']
                  #* smb_ent_inputs['lat_construct_upfront_pct']
                  #* smb_ent_inputs['lat_cost_per_building'])
                  #+ smb_ent_inputs['access_fees_one_time']
                  )
    Lat_CAR = (smb_ent_inputs['building_ct']
                * smb_ent_inputs['lat_construct_upfront_pct']
                * smb_ent_inputs['lat_cost_per_building']
                )
    Total_CAR = ifnull(ROW_CAR,0) + ifnull(Lat_CAR,0)

    return ROW_CAR, Lat_CAR, Total_CAR

######################################################################
# Calc Payback Month
######################################################################
def calc_child_payback_mo(consol_curves):
    cashflow = consol_curves['cashflow']
    cum_cashflow = 0
    payback_mo = 0

    for i in range(181):
        cum_cashflow = cum_cashflow + cashflow[i]
        if cum_cashflow >= 0:
            payback_mo = i
            break
        else:
            payback_mo = ''

    return payback_mo

######################################################################
# Calc ROE Gate
######################################################################
def calc_child_roe_gate(request):
    probuild_id = request.GET.get('probuild_id', None)
    sql = (''' EXEC BI_MIP.miBuilds.calculations_child_roe_gate_df
                            @probuild_id = {}
                    ''').format(probuild_id)
    df = pd.read_sql(sql, connection)

    business_ct = float(ifnull(df['business_ct'].values[0], 0))
    roe_acquired = float(ifnull(df['roe_acquired'].values[0], 0))

    if business_ct == 0:
        roe_target = 1
    else:
        roe_target = round(business_ct * 0.3, 0)
    roe_needed = roe_target - roe_acquired

    ### Account for oddities
    if roe_needed < 0:
        roe_needed = 0
    else:
        roe_needed = roe_needed

    return roe_target, roe_acquired, roe_needed

######################################################################
# Calc Max Capital
######################################################################
def calc_child_business_resi_capital_pct(request):
    smb_ent_curves = child_smb_ent.build_child_smb_ent_curves(request)

    mdu_inputs = child_mdu.prep_child_mdu_inputs(request)
    mdu_curves = child_mdu.build_child_mdu_curves(mdu_inputs)
    mdu_consol_cashflow = child_mdu.build_child_mdu_consol_cashflow(mdu_curves)

    WACC = 1 ** (1/12) - 1
    NaN_Value_NPV = 0

    Business_NPV = np.npv(WACC, smb_ent_curves['smb_ent_cashflow_max_cap'])
    Resi_NPV = np.npv(WACC, mdu_consol_cashflow)

    if np.isnan(Business_NPV):
        Business_NPV = NaN_Value_NPV
    if np.isnan(Resi_NPV):
        Resi_NPV = NaN_Value_NPV

    Total_NPV = Business_NPV + Resi_NPV

    if Total_NPV == 0:
        Business_Pct = 0
        Resi_Pct = 0
    else:
        Business_Pct = Business_NPV / Total_NPV
        Resi_Pct = Resi_NPV / Total_NPV

    return Business_NPV, Resi_NPV, Business_Pct, Resi_Pct
