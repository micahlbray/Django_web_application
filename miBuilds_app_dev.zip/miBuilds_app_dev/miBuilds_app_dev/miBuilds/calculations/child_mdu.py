from django.db.models import Sum, Max, Count
from django.db import connection
from miBuilds.models import (AppProbuild,
                            AppBuilding,
                            AppBusiness,
                            AppSfDealinhand,
                            AppMdu,
                            AppDatacenter,
                            AppFile,
                            AssumpRegion,
                            AssumpMduBuildRegion,
                            AssumpMduBuild,
                            AssumpSegment,
                            AssumpDataCenterType,
                            AssumpDataCenterEquipType,
                            AssumpDataCenterCircuitEoy,
                            LkRegion,
                            LkState,
                            LkDataCenterEquipType,
                            LkSegmentType,
                            LkBuildingType,
                            LkDwellingType,
                            )
from miBuilds.utils import(ifnull, strDollarToDecimal, strPercentToDecimal)
from miBuilds.calculations import child_smb_ent
import numpy as np
import pandas as pd
import codecs, json, sqlalchemy, urllib, math

######################################################################
# Prep MDU data inputs for future use
######################################################################
def prep_child_mdu_inputs(request):
    if request.method == 'GET':
        probuild_id = request.GET.get('probuild_id', None)
    elif request.method == 'POST':
        probuild_id = request.POST.get('probuild_id', None)

    mdu_id_list = AppMdu.objects.values_list('mdu_id', flat=True).exclude(
        deleted=1).filter(probuild_id=probuild_id)
    inputs = {}
    mdu_inputs = {}

    i = 0
    while i < len(mdu_id_list):
        mdu_id = mdu_id_list[i]

        # Create data frame
        mdu_sql = ('''  SELECT  Term as term
                                ,Building_Ct as building_ct
                                ,Unit_Ct as unit_ct
                                ,Video_Penetration as video_penetration
                                ,Data_Penetration as data_penetration
                                ,Voice_Penetration as voice_penetration
                                ,Video_ARPU as video_arpu
                                ,Data_ARPU as data_arpu
                                ,Voice_ARPU as voice_arpu
                                ,Video_Rev_Share as video_rev_share
                                ,Data_Rev_Share as data_rev_share
                                ,Voice_Rev_Share as voice_rev_share
                                ,Opex_Load as opex_load
                                ,Door_Fees as door_fees
                                ,ISP_Per_Unit as isp_per_unit
                                ,Converter as converter
                                ,Modem as modem
                                ,eMTA as emta
                                ,Commission as commission
                                ,Penetration_Ramp as penetration_ramp
                        FROM    BI_MIP.miBuilds.app_MDU as a
                            JOIN BI_MIP.miBuilds.lk_Term_Length as b
                            ON a.Term_Length_Id = b.Term_Length_Id
                        WHERE   mdu_id = {}
                                and ISNULL(Deleted, 0) = 0'''
                    )
        mdu_sql = mdu_sql.format(mdu_id)
        mdu_df = pd.read_sql(mdu_sql, connection)

        smb_ent_inputs = child_smb_ent.prep_child_smb_ent_inputs(request)

        # Needed lateral cost for costing calcs
        building_ct = AppBuilding.objects.filter(probuild=probuild_id).count()
        private_property_cost = AppProbuild.objects.values_list('private_property_cost', flat=True).exclude(deleted='0').filter(probuild_id=probuild_id)[0]
        #if building_ct == 0:
            #inputs['lat_cost_per_building'] = 0
        #else:
            #inputs['lat_cost_per_building'] = private_property_cost / building_ct

        inputs['lat_cost_per_building'] = smb_ent_inputs['lat_cost_per_building']

        # Create inputs dictionary from data frame
        inputs['term'] = mdu_df['term'].values[0]
        inputs['building_ct'] = mdu_df['building_ct'].values[0]
        inputs['unit_ct'] = mdu_df['unit_ct'].values[0]
        inputs['video_pen'] = mdu_df['video_penetration'].values[0]
        inputs['data_pen'] = mdu_df['data_penetration'].values[0]
        inputs['voice_pen'] = mdu_df['voice_penetration'].values[0]
        inputs['video_arpu'] = mdu_df['video_arpu'].values[0]
        inputs['data_arpu'] = mdu_df['data_arpu'].values[0]
        inputs['voice_arpu'] = mdu_df['voice_arpu'].values[0]
        inputs['video_rev_share'] = mdu_df['video_rev_share'].values[0]
        inputs['data_rev_share'] = mdu_df['data_rev_share'].values[0]
        inputs['voice_rev_share'] = mdu_df['voice_rev_share'].values[0]
        inputs['opex_load'] = mdu_df['opex_load'].values[0]
        inputs['door_fees'] = mdu_df['door_fees'].values[0]
        inputs['isp_per_unit'] = mdu_df['isp_per_unit'].values[0]
        inputs['converter'] = mdu_df['converter'].values[0]
        inputs['modem'] = mdu_df['modem'].values[0]
        inputs['emta'] = mdu_df['emta'].values[0]
        inputs['commission'] = mdu_df['commission'].values[0]
        inputs['pen_ramp'] = mdu_df['penetration_ramp'].values[0]

        name = 'mdu' + str(i)
        mdu_inputs[name] = {}
        mdu_inputs[name].update(inputs)

        i += 1

    return mdu_inputs

########################################################################################################
# Build Rev, Cost, and Cashflow curves for each MDU and combine into one Dict (mdu_curves)
########################################################################################################
def build_child_mdu_curves(mdu_inputs):
    mdu_curves = {}
    mdu_curves['rev'] = {}
    mdu_curves['cost'] = {}
    mdu_curves['cashflow'] = {}

    mdu_calc_rev = np.zeros(181)
    mdu_calc_cost = np.zeros(181)
    mdu_calc_cashflow = np.zeros(181)

    x = 0
    while x < len(mdu_inputs): # the number of data centers
        name = 'mdu' + str(x)
        inputs = mdu_inputs[name]

        lat_cost_per_building = float(inputs['lat_cost_per_building'])
        ramp = ifnull(inputs['pen_ramp'],6)
        term = int(inputs['term'])
        units = ifnull(inputs['unit_ct'], 0)
        buildings = ifnull(inputs['building_ct'], 0)
        video_pen = ifnull(inputs['video_pen'], 0)
        data_pen = ifnull(inputs['data_pen'], 0)
        voice_pen = ifnull(inputs['voice_pen'], 0)
        video_arpu = ifnull(inputs['video_arpu'], 0)
        data_arpu = ifnull(inputs['data_arpu'], 0)
        voice_arpu = ifnull(inputs['voice_arpu'], 0)
        video_rev_share = ifnull(inputs['video_rev_share'], 0)
        data_rev_share = ifnull(inputs['data_rev_share'], 0)
        voice_rev_share = ifnull(inputs['voice_rev_share'], 0)
        opex_load = ifnull(inputs['opex_load'], 0)
        door_fees = ifnull(inputs['door_fees'], 0)
        isp_per_unit = ifnull(inputs['isp_per_unit'], 0)
        converter = ifnull(inputs['converter'], 0)
        modem = ifnull(inputs['modem'], 0)
        emta = ifnull(inputs['emta'], 0)
        commission = ifnull(inputs['commission'], 0)
        max_pen = max(video_pen, data_pen, voice_pen)

        ######### Revenue calculation loop #########
        i = 0
        for i in range(181):
            if i == 0:
                mdu_calc_rev[i] = 0
            elif i > term:
                mdu_calc_rev[i] = 0
            elif i > ramp:
                mdu_calc_rev[i] = mdu_calc_rev[i - 1]
            else:
                mdu_calc_rev[i] = (video_pen * (i / ramp)
                                  * video_arpu * units
                                  + data_pen * (i / ramp)
                                  * data_arpu * units
                                  + voice_pen * (i / ramp)
                                  * voice_arpu * units
                                  )
        ### Add to dict ###
        mdu_curves['rev'][name] = mdu_calc_rev.copy()

        ######### Cost calcuation loop #########
        i = 0
        for i in range(181):
            if i == 0:
                mdu_calc_cost[i] = ( -1
                                  * (units * door_fees
                                  + commission + lat_cost_per_building
                                  * buildings)
                                  )
            elif i > term:
                mdu_calc_cost[i] = 0
            elif i == (ramp + 1):
                mdu_calc_cost[i] = (mdu_calc_cost[i - 1]
                                   + max_pen * units / ramp * isp_per_unit
                                   + video_pen * units / ramp * converter
                                   + (data_pen - voice_pen) * units / ramp
                                   * modem + voice_pen * units / ramp * emta
                                   )
            elif i > ramp:
                mdu_calc_cost[i] = mdu_calc_cost[i - 1]
            else:
                mdu_calc_cost[i] = ( -1
                                   * (max_pen * units / ramp * isp_per_unit
                                   + video_pen * i / ramp * video_arpu * units * video_rev_share
                                   + data_pen * i / ramp * data_arpu * units * data_rev_share
                                   + voice_pen * i / ramp * voice_arpu * units * voice_rev_share
                                   + video_pen * units / ramp
                                   * converter + (data_pen - voice_pen) * units / ramp
                                   * modem + voice_pen * units / ramp
                                   * emta + mdu_calc_rev[i] * opex_load)
                                   )
        ### Add to dict ###
        mdu_curves['cost'][name] = mdu_calc_cost.copy()

        ######### Cashflow calcuation loop #########
        i = 0
        for i in range(181):
            mdu_calc_cashflow[i] = mdu_calc_rev[i] + mdu_calc_cost[i]
        ### Add to dict ###
        mdu_curves['cashflow'][name] = mdu_calc_cashflow.copy()

        x += 1

    return mdu_curves

########################################################################################################
# Build MDU consolidated (possible n number of MDUs) Cashflow from mdu_curves
########################################################################################################
def build_child_mdu_consol_cashflow(mdu_curves):
    mdu_consol_cashflow = np.zeros(181)

    x = 0
    while x < len(mdu_curves['cashflow']):
        name = 'mdu' + str(x)

        i = 0
        for i in range(181):
            mdu_consol_cashflow[i] = (mdu_consol_cashflow[i]
                                      + mdu_curves['cashflow'][name][i])

        x += 1

    return mdu_consol_cashflow
