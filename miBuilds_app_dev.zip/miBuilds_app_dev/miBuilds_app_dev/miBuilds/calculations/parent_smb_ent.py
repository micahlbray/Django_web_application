from django.db.models import Sum, Max, Count
from django.db import connection
from miBuilds.utils import(ifnull, strDollarToDecimal, strPercentToDecimal)
from miBuilds.models import (AppProbuild,
                            RptProbuild,
                            AppSfDealinhand,
                            AppMdu,
                            AppDatacenter,
                            AssumpRegion,
                            )
from miBuilds.calculations import parent_data_center
import numpy as np
import pandas as pd
import codecs, json, sqlalchemy, urllib, math

######################################################################
# Prep SMB and ENT data consol curves for future use
######################################################################
def prep_parent_smb_ent_consol_curves():
    smb_ent_consol_curves = {}

    smb_ent_consol_curves['smb_rev'] = np.zeros(181)
    smb_ent_consol_curves['ent_rev'] = np.zeros(181)
    smb_ent_consol_curves['smb_ent_cost'] = np.zeros(181)
    smb_ent_consol_curves['smb_ent_cashflow'] = np.zeros(181)
    smb_ent_consol_curves['smb_ent_cashflow_max_cap'] = np.zeros(181)
    smb_ent_consol_curves['smb_ent_cashflow_less_he_trnsprt'] = np.zeros(181)

    return smb_ent_consol_curves
######################################################################
# Combine SMB and ENT curves
######################################################################
def build_parent_smb_ent_consol_curves(probuild_id):
    smb_ent_consol_curves = prep_parent_smb_ent_consol_curves()
    smb_rev = smb_ent_consol_curves['smb_rev']
    ent_rev = smb_ent_consol_curves['ent_rev']
    cost = smb_ent_consol_curves['smb_ent_cost']
    cashflow = smb_ent_consol_curves['smb_ent_cashflow']
    cashflow_max_cap = smb_ent_consol_curves['smb_ent_cashflow_max_cap']
    cashflow_less_he_trnsprt = smb_ent_consol_curves['smb_ent_cashflow_less_he_trnsprt']

    #### Hit db for id's probuild
    sql = ('''EXEC BI_MIP.miBuilds.calculations_child_probuild_id_list_df_DEV
                   @probuild_id = {}
           ''').format(probuild_id)
    df = pd.read_sql(sql, connection)
    child_id_list = df['Probuild_Id'].tolist()

    x = 0
    while x < len(child_id_list):
        probuild_id = child_id_list[x]
        smb_ent_curves = build_parent_smb_ent_curves(probuild_id)

        i = 0
        for i in range(181):
            smb_rev[i] = (
                    smb_rev[i]
                    + smb_ent_curves['smb_rev'][i]
                    )
            ent_rev[i] = (
                    ent_rev[i]
                    + smb_ent_curves['ent_rev'][i]
                    )
            cost[i] = (
                    cost[i]
                    + smb_ent_curves['smb_ent_cost'][i]
                    )
            cashflow[i] = (
                    cashflow[i]
                    + smb_ent_curves['smb_ent_cashflow'][i]
                    )
            cashflow_max_cap[i] = (
                    cashflow_less_he_trnsprt[i]
                    + smb_ent_curves['smb_ent_cashflow_max_cap'][i]
                    )
            cashflow_less_he_trnsprt[i] = (
                    cashflow_less_he_trnsprt[i]
                    + smb_ent_curves['smb_ent_cashflow_less_he_trnsprt'][i]
                    )

            i += 1

        smb_ent_curves['smb_ent_cashflow'] = cashflow.copy()

        x += 1

    return smb_ent_consol_curves

######################################################################
# Combine SMB and ENT curves
######################################################################
def prep_parent_smb_ent_consol_inputs(probuild_id):
    ################################### Calculated Assumptions ###################################
    sql2 = ('''EXEC BI_MIP.miBuilds.calculations_parent_smb_ent_assumps_df_DEV
                   @probuild_id = {}
           ''').format(probuild_id)
    df2 = pd.read_sql(sql2, connection)

    lat_construct_upfront_pct = float(ifnull(df2['lat_pct'].values[0], 0))
    smb_arpu = float(ifnull(df2['smb_arpu'].values[0], 0))
    ent_arpu = float(ifnull(df2['ent_arpu'].values[0], 0))
    smb_12mo_pen = float(ifnull(df2['smb_12mo_pen'].values[0], 0))
    smb_36mo_pen = float(ifnull(df2['smb_36mo_pen'].values[0], 0))
    ent_12mo_pen = float(ifnull(df2['ent_12mo_pen'].values[0], 0))
    ent_36mo_pen = float(ifnull(df2['ent_36mo_pen'].values[0], 0))

    ################################### User inputs ###################################
    sql = ('''EXEC BI_MIP.miBuilds.calculations_parent_smb_ent_inputs_df_DEV
                   @probuild_id = {}
           ''').format(probuild_id)
    df = pd.read_sql(sql, connection)

    customer_contribution = float(ifnull(df['customer_contribution'].values[0], 0))
    access_fees_one_time = float(ifnull(df['access_fees_one_time'].values[0], 0))
    access_fees_monthly = float(ifnull(df['access_fees_monthly'].values[0], 0))
    row_est_build_cost = float(ifnull(df['row_est_build_cost'].values[0], 0))
    headend_cost = float(ifnull(df['headend_cost'].values[0], 0))
    transport_cost = float(ifnull(df['transport_cost'].values[0], 0))
    private_property_cost = float(ifnull(df['private_property_cost'].values[0], 0))
    dealinhand_ct = float(ifnull(df['dih_ct'].values[0], 0))
    mdu_ct = float(ifnull(df['mdu_ct'].values[0], 0))
    datacenter_ct = float(ifnull(df['dc_ct'].values[0], 0))

    ################################### Building count inputs ###################################
    record_ct = float(ifnull(df['record_ct'].values[0], 0))
    address_ct = float(ifnull(df['address_ct'].values[0], 0))
    address_null = float(ifnull(df['address_null'].values[0], 0))
    mdu_building_ct = float(ifnull(df['mdu_building_ct'].values[0], 0))
    if address_null > 0:
        building_ct = address_ct + address_null #+ mdu_building_ct + datacenter_ct
    elif record_ct > address_ct:
        building_ct = record_ct #+ mdu_ct + datacenter_ct
    else:
        building_ct = record_ct #+ mdu_ct + datacenter_ct
    multi_tenant_building_ct = float(ifnull(df['multi_tenant_building_ct'].values[0], 0))
    building_ct_less_multi = building_ct - multi_tenant_building_ct

    ################################### Business count inputs ###################################
    business_ct = float(ifnull(df['business_ct'].values[0], 0))
    smb_qb_ct = float(ifnull(df['smb_qb_ct'].values[0], 0))
    ent_qb_ct = float(ifnull(df['ent_qb_ct'].values[0], 0))

    ################################### Lateral calculation variables ###################################
    if building_ct == 0:
        lat_cost_per_building = 0
    else:
        lat_cost_per_building = private_property_cost / building_ct
    ######################################################################
    if multi_tenant_building_ct == 0:
        lat_cost_per_multi_tenant = 0
    elif (multi_tenant_building_ct - mdu_ct) == 0:
        lat_cost_per_multi_tenant = 0
    elif business_ct == 0:
        lat_cost_per_multi_tenant = 0
    elif (business_ct - building_ct_less_multi) == 0:
        lat_cost_per_multi_tenant = 0
    elif (
            ((business_ct - building_ct_less_multi) / (multi_tenant_building_ct - mdu_ct))
            *
            (smb_36mo_pen * smb_qb_ct / business_ct + ent_36mo_pen * ent_qb_ct / business_ct)
        ) == 0:
        lat_cost_per_multi_tenant = 0
    else:
        lat_cost_per_multi_tenant = (
                                    lat_cost_per_building
                                    /
                                    (
                                    ((business_ct - building_ct_less_multi) / (multi_tenant_building_ct - mdu_ct))
                                    *
                                    (smb_36mo_pen * smb_qb_ct / business_ct + ent_36mo_pen * ent_qb_ct / business_ct)
                                    )
                                    )
    ######################################################################
    if lat_construct_upfront_pct:
        lat_construct_upfront_pct = lat_construct_upfront_pct
    elif private_property_cost == 0:
        lat_construct_upfront_pct = 0
    elif business_ct == 0:
        lat_construct_upfront_pct = 0
    elif building_ct == 0:
        lat_construct_upfront_pct = 0
    else:
        lat_construct_upfront_pct = ((multi_tenant_building_ct
                                    + building_ct_less_multi
                                    * (smb_36mo_pen * smb_qb_ct / business_ct
                                    + ent_36mo_pen * ent_qb_ct / business_ct))
                                    / building_ct
                                    )
    ######################################################################
    if business_ct == 0:
        passing_cost_per = 0
    else:
        passing_cost_per = ((row_est_build_cost + headend_cost
                       + transport_cost + private_property_cost)
                       / business_ct
                       )
    ######################################################################
    if business_ct == 0:
        lat_cost_per_connect = 0
    else:
        lat_cost_per_connect = ((lat_cost_per_building
                           * building_ct_less_multi
                           / business_ct)
                           + lat_cost_per_multi_tenant
                           * (business_ct - building_ct_less_multi)
                           / business_ct
                           )

    ################### BUILD INPUTS DICTIONARY ###################
    inputs = {}
    inputs['probuild_id'] = probuild_id
    inputs['customer_contribution'] = customer_contribution
    inputs['access_fees_one_time'] = access_fees_one_time
    inputs['access_fees_monthly'] = access_fees_monthly
    inputs['row_est_build_cost'] = row_est_build_cost
    inputs['headend_cost'] = headend_cost
    inputs['transport_cost'] = transport_cost
    inputs['private_property_cost'] = private_property_cost
    inputs['smb_arpu'] = smb_arpu
    inputs['ent_arpu'] = ent_arpu
    inputs['smb_12mo_pen'] = smb_12mo_pen
    inputs['smb_36mo_pen'] = smb_36mo_pen
    inputs['ent_12mo_pen'] = ent_12mo_pen
    inputs['ent_36mo_pen'] = ent_36mo_pen
    inputs['smb_qb_ct'] = smb_qb_ct
    inputs['ent_qb_ct'] = ent_qb_ct
    inputs['business_ct'] = business_ct
    inputs['multi_tenant_building_ct'] = multi_tenant_building_ct
    inputs['building_ct'] = building_ct
    inputs['building_ct_less_multi'] = building_ct_less_multi
    inputs['mdu_building_ct'] = mdu_building_ct
    inputs['dealinhand_ct'] = dealinhand_ct
    inputs['mdu_ct'] = mdu_ct
    inputs['datacenter_ct'] = datacenter_ct
    inputs['lat_cost_per_building'] = lat_cost_per_building
    inputs['lat_cost_per_multi_tenant'] = lat_cost_per_multi_tenant
    inputs['lat_construct_upfront_pct'] = lat_construct_upfront_pct
    inputs['passing_cost_per'] = passing_cost_per
    inputs['lat_cost_per_connect'] = lat_cost_per_connect

    smb_ent_inputs = {}
    smb_ent_inputs = inputs.copy()

    return smb_ent_inputs

########################################################################################################
# Prep SMB and ENT assumptions
########################################################################################################
def prep_parent_smb_ent_inputs(probuild_id):
    #### Hit db for basic inputs from probuild
    sql = ('''EXEC BI_MIP.miBuilds.calculations_smb_ent_inputs_df_DEV
                   @probuild_id = {}
           ''').format(probuild_id)
    df = pd.read_sql(sql, connection)

    customer_contribution = float(ifnull(df['customer_contribution'].values[0], 0))
    access_fees_one_time = float(ifnull(df['access_fees_one_time'].values[0], 0))
    access_fees_monthly = float(ifnull(df['access_fees_monthly'].values[0], 0))
    row_est_build_cost = float(ifnull(df['row_est_build_cost'].values[0], 0))
    headend_cost = float(ifnull(df['headend_cost'].values[0], 0))
    transport_cost = float(ifnull(df['transport_cost'].values[0], 0))
    private_property_cost = float(ifnull(df['private_property_cost'].values[0], 0))
    lat_construct_upfront_pct = float(ifnull(df['lat_construct_upfront_pct'].values[0], 0))
    smb_arpu = float(ifnull(df['smb_arpu'].values[0], 0))
    ent_arpu = float(ifnull(df['ent_arpu'].values[0], 0))
    smb_12mo_pen = float(ifnull(df['smb_12mo_pen'].values[0], 0))
    smb_36mo_pen = float(ifnull(df['smb_36mo_pen'].values[0], 0))
    ent_12mo_pen = float(ifnull(df['ent_12mo_pen'].values[0], 0))
    ent_36mo_pen = float(ifnull(df['ent_36mo_pen'].values[0], 0))

    ################### Random Counts #######################
    dealinhand_ct = (AppSfDealinhand.objects
                       .filter(probuild=probuild_id)
                       .exclude(deleted=1)
                       .aggregate(count=Count('sf_dealinhand_id'))
                    )['count']
    mdu_ct = (AppMdu.objects
                       .filter(probuild=probuild_id)
                       .exclude(deleted=1)
                       .aggregate(count=Count('mdu_id'))
                    )['count']
    datacenter_ct = (AppDatacenter.objects
                       .filter(probuild=probuild_id)
                       .exclude(deleted=1)
                       .aggregate(count=Count('datacenter_id'))
                    )['count']

    ################################### Building count inputs ###################################
    building_sql = (''' SELECT	COUNT(Record_Id) as record_ct
                                ,COUNT(DISTINCT lower(Address)) as address_ct
								,SUM(IIF(Address IS NULL, 1, 0)) as address_null
                        		,SUM(IIF(Dwelling_Type_Id = 2, 1, 0)) as multi_tenant_building_ct
                        FROM BI_MIP.miBuilds.app_Building
                        WHERE Probuild_Id = {}
                                and ISNULL(Deleted, 0) = 0'''
                    ).format(probuild_id)
    building_df = pd.read_sql(building_sql, connection)

    mdu_sql = ('''  SELECT  SUM(Building_Ct) as mdu_building_ct
                    FROM    BI_MIP.miBuilds.app_MDU as a
                    WHERE   probuild_id = {}
                            and ISNULL(Deleted, 0) = 0'''
                ).format(probuild_id)
    mdu_df = pd.read_sql(mdu_sql, connection)

    ### Assign Variables ###
    record_ct = float(ifnull(building_df['record_ct'].values[0], 0))
    address_ct = float(ifnull(building_df['address_ct'].values[0], 0))
    address_null = float(ifnull(building_df['address_null'].values[0], 0))
    mdu_building_ct = float(ifnull(mdu_df['mdu_building_ct'].values[0], 0))
    if address_null > 0:
        building_ct = address_ct + address_null #+ mdu_building_ct + datacenter_ct
    elif record_ct > address_ct:
        building_ct = address_ct #+ mdu_building_ct + datacenter_ct
    else:
        building_ct = record_ct #+ mdu_building_ct + datacenter_ct
    multi_tenant_building_ct = float(ifnull(building_df['multi_tenant_building_ct'].values[0], 0))
    building_ct_less_multi = building_ct - multi_tenant_building_ct

    ################################### Business count inputs ###################################
    business_sql = (''' SELECT	COUNT(Record_Id) as business_ct
                        		,SUM(IIF(ISNULL(Revised_Segment_Type_Id, Segment_Type_Id) = 1, 1, 0)) as smb_qb_ct
                                ,SUM(IIF(ISNULL(Revised_Segment_Type_Id, Segment_Type_Id) <> 1, 1, 0)) as ent_qb_ct
                        FROM BI_MIP.miBuilds.app_Business
                        WHERE Probuild_Id = {}
                                and ISNULL(Deleted, 0) = 0'''
                    )
    business_sql = business_sql.format(probuild_id)
    business_df = pd.read_sql(business_sql, connection)

    ### Assign Variables ###
    business_ct = float(ifnull(business_df['business_ct'].values[0], 0))
    smb_qb_ct = float(ifnull(business_df['smb_qb_ct'].values[0], 0))
    ent_qb_ct = float(ifnull(business_df['ent_qb_ct'].values[0], 0))

    ################################### Lateral calculation variables ###################################
    if building_ct == 0:
        lat_cost_per_building = 0
    else:
        lat_cost_per_building = private_property_cost / building_ct

    if multi_tenant_building_ct == 0:
        lat_cost_per_multi_tenant = 0
    elif (multi_tenant_building_ct - mdu_ct) == 0:
        lat_cost_per_multi_tenant = 0
    elif business_ct == 0:
        lat_cost_per_multi_tenant = 0
    elif (business_ct - building_ct_less_multi) == 0:
        lat_cost_per_multi_tenant = 0
    elif (
            ((business_ct - building_ct_less_multi) / (multi_tenant_building_ct - mdu_ct))
            *
            (smb_36mo_pen * smb_qb_ct / business_ct + ent_36mo_pen * ent_qb_ct / business_ct)
        ) == 0:
        lat_cost_per_multi_tenant = 0
    else:
        lat_cost_per_multi_tenant = (
                                    lat_cost_per_building
                                    /
                                    (
                                    ((business_ct - building_ct_less_multi) / (multi_tenant_building_ct - mdu_ct))
                                    *
                                    (smb_36mo_pen * smb_qb_ct / business_ct + ent_36mo_pen * ent_qb_ct / business_ct)
                                    )
                                    )

    if lat_construct_upfront_pct:
        lat_construct_upfront_pct = lat_construct_upfront_pct
    elif private_property_cost == 0:
        lat_construct_upfront_pct = 0
    elif business_ct == 0:
        lat_construct_upfront_pct = 0
    elif building_ct == 0:
        lat_construct_upfront_pct = 0
    else:
        lat_construct_upfront_pct = ((multi_tenant_building_ct
                                    + building_ct_less_multi
                                    * (smb_36mo_pen * smb_qb_ct / business_ct
                                    + ent_36mo_pen * ent_qb_ct / business_ct))
                                    / building_ct
                                    )

    if private_property_cost == 0:
        exp_lat_construct_upfront_pct = 0
    elif business_ct == 0:
        exp_lat_construct_upfront_pct = 0
    elif building_ct == 0:
        exp_lat_construct_upfront_pct = 0
    else:
        exp_lat_construct_upfront_pct = ((multi_tenant_building_ct
                                        + building_ct_less_multi
                                        * (smb_36mo_pen * smb_qb_ct / business_ct
                                        + ent_36mo_pen * ent_qb_ct / business_ct))
                                        / building_ct
                                        )

    if business_ct == 0:
        passing_cost_per = 0
    else:
        passing_cost_per = ((row_est_build_cost + headend_cost
                       + transport_cost + private_property_cost)
                       / business_ct
                       )

    if business_ct == 0:
        lat_cost_per_connect = 0
    else:
        lat_cost_per_connect = ((lat_cost_per_building
                           * building_ct_less_multi
                           / business_ct)
                           + lat_cost_per_multi_tenant
                           * (business_ct - building_ct_less_multi)
                           / business_ct
                           )

    ################################### Deal In Hand inputs ###################################
    deal_in_hand_sql = (''' SELECT	ISNULL(SUM(IIF(Segment_Type_Id = 1, 1, 0)), 0) as smb_deal_in_hand_ct
                            		,ISNULL(SUM(IIF(Segment_Type_Id = 1, MRR, 0)), 0) as smb_deal_in_hand_mrc
                            		,ISNULL(SUM(IIF(Segment_Type_Id <> 1, 1, 0)), 0) as ent_deal_in_hand_ct
                            		,ISNULL(SUM(IIF(Segment_Type_Id <> 1, MRR, 0)), 0) as ent_deal_in_hand_mrc
                            FROM BI_MIP.miBuilds.app_SF_DealInHand
                            WHERE Probuild_Id = {}
                                    and ISNULL(Deleted, 0) = 0'''
                    )
    deal_in_hand_sql = deal_in_hand_sql.format(probuild_id)
    deal_in_hand_df = pd.read_sql(deal_in_hand_sql, connection)

    ### Assign Variables ###
    smb_deal_in_hand_ct = float(ifnull(deal_in_hand_df['smb_deal_in_hand_ct'].values[0], 0))
    smb_deal_in_hand_mrc = float(ifnull(deal_in_hand_df['smb_deal_in_hand_mrc'].values[0], 0))
    ent_deal_in_hand_ct = float(ifnull(deal_in_hand_df['ent_deal_in_hand_ct'].values[0], 0))
    ent_deal_in_hand_mrc = float(ifnull(deal_in_hand_df['ent_deal_in_hand_mrc'].values[0], 0))

    ################################### SMB Assumptions ###################################
    smb_assump_sql = ('''   SELECT	Capex_Data_and_Install as smb_capex_data
                            		,Capex_Voice_and_Install as smb_capex_voice
                            		,Capex_Video_and_Install as smb_capex_video
                            		,Opex_Load as smb_opex_load
                            		,Churn as smb_churn
                            FROM BI_MIP.miBuilds.assump_Segment
                            WHERE Segment_Type_Id = 1
                            	and IsActive = 1'''
                        )
    smb_assump_df = pd.read_sql(smb_assump_sql, connection)

    ################################### SMB Costing variables ###################################
    smb_capex_data = float(ifnull(smb_assump_df['smb_capex_data'].values[0], 0))
    smb_capex_voice = float(ifnull(smb_assump_df['smb_capex_voice'].values[0], 0))
    smb_capex_video = float(ifnull(smb_assump_df['smb_capex_video'].values[0], 0))
    smb_opex_load = float(ifnull(smb_assump_df['smb_opex_load'].values[0], 0))
    smb_churn = float(ifnull(smb_assump_df['smb_churn'].values[0], 0))
    smb_capex = (
                smb_capex_data
                + (smb_capex_voice * 0.7)
                + (smb_capex_video * 0.6)
                )
    smb_nrr = -1 * (smb_arpu * 0.25)
    smb_commission = smb_arpu * 0.6
    smb_total_upfront_cost = smb_capex + smb_nrr + smb_commission
    if business_ct == 0:
        smb_add_osp_lat_cost = 0
    else:
        smb_add_osp_lat_cost = (
                            lat_cost_per_building
                            * building_ct_less_multi
                            / business_ct
                            + lat_cost_per_multi_tenant
                            * (business_ct - building_ct_less_multi)
                            / business_ct
                            )
    smb_cost = smb_total_upfront_cost + smb_add_osp_lat_cost

    ################################### ENT Assumptions ###################################
    ent_assump_sql = ('''   SELECT	Capex as ent_capex
                            		,Maint_Opex as ent_maint_opex
                            		,Opex_Load as ent_opex_load
                            		,Churn as ent_churn
                            FROM BI_MIP.miBuilds.assump_Segment
                            WHERE Segment_Type_Id <> 1
                            	and IsActive = 1'''
                        )
    ent_assump_df = pd.read_sql(ent_assump_sql, connection)

    ################################### ENT Costing variables ###################################
    ent_capex = float(ifnull(ent_assump_df['ent_capex'].values[0], 0))
    ent_maint_opex = float(ifnull(ent_assump_df['ent_maint_opex'].values[0], 0))
    ent_opex_load = float(ifnull(ent_assump_df['ent_opex_load'].values[0], 0))
    ent_churn = float(ifnull(ent_assump_df['ent_churn'].values[0], 0))
    ent_arpu_div = float(AssumpRegion.objects.values_list('ent_arpu', flat=True).filter(region='7', isactive = '1')[0])
    ent_bandwidth_cost = 4.24 * 85 * ent_arpu / ent_arpu_div
    ent_nrr = -1 * (ent_arpu * 0.25)
    ent_commission = ent_arpu * 0.6
    ent_total_upfront_cost = ent_capex + ent_maint_opex + ent_bandwidth_cost + ent_nrr + ent_commission
    if business_ct == 0:
        ent_add_osp_lat_cost = 0
    else:
        ent_add_osp_lat_cost = (
                            lat_cost_per_building
                            * building_ct_less_multi
                            / business_ct
                            + lat_cost_per_multi_tenant
                            * (business_ct - building_ct_less_multi)
                            / business_ct
                            )
    ent_cost = ent_total_upfront_cost + ent_add_osp_lat_cost


    ################### BUILD INPUTS DICTIONARY ###################
    inputs = {}
    inputs['probuild_id'] = probuild_id
    inputs['customer_contribution'] = customer_contribution
    inputs['access_fees_one_time'] = access_fees_one_time
    inputs['access_fees_monthly'] = access_fees_monthly
    inputs['row_est_build_cost'] = row_est_build_cost
    inputs['headend_cost'] = headend_cost
    inputs['transport_cost'] = transport_cost
    inputs['private_property_cost'] = private_property_cost
    inputs['smb_arpu'] = smb_arpu
    inputs['ent_arpu'] = ent_arpu
    inputs['smb_12mo_pen'] = smb_12mo_pen
    inputs['smb_36mo_pen'] = smb_36mo_pen
    inputs['ent_12mo_pen'] = ent_12mo_pen
    inputs['ent_36mo_pen'] = ent_36mo_pen
    inputs['smb_qb_ct'] = smb_qb_ct
    inputs['ent_qb_ct'] = ent_qb_ct
    inputs['business_ct'] = business_ct
    inputs['multi_tenant_building_ct'] = multi_tenant_building_ct
    inputs['building_ct'] = building_ct
    inputs['building_ct_less_multi'] = building_ct_less_multi
    inputs['mdu_building_ct'] = mdu_building_ct
    inputs['dealinhand_ct'] = dealinhand_ct
    inputs['mdu_ct'] = mdu_ct
    inputs['datacenter_ct'] = datacenter_ct
    inputs['smb_churn'] = smb_churn
    inputs['smb_deal_in_hand_ct'] = smb_deal_in_hand_ct
    inputs['smb_deal_in_hand_mrc'] = smb_deal_in_hand_mrc
    inputs['ent_churn'] = ent_churn
    inputs['ent_deal_in_hand_ct'] = ent_deal_in_hand_ct
    inputs['ent_deal_in_hand_mrc'] = ent_deal_in_hand_mrc
    inputs['lat_cost_per_building'] = lat_cost_per_building
    inputs['lat_cost_per_multi_tenant'] = lat_cost_per_multi_tenant
    inputs['lat_construct_upfront_pct'] = lat_construct_upfront_pct
    inputs['exp_lat_construct_upfront_pct'] = exp_lat_construct_upfront_pct
    inputs['passing_cost_per'] = passing_cost_per
    inputs['lat_cost_per_connect'] = lat_cost_per_connect
    inputs['smb_cost'] = smb_cost
    inputs['smb_opex_load'] = smb_opex_load
    inputs['ent_cost'] = ent_cost
    inputs['ent_opex_load'] = ent_opex_load

    smb_ent_inputs = {}
    smb_ent_inputs = inputs.copy()

    return smb_ent_inputs

######################################################################
# Define Arrays
######################################################################
def prep_parent_smb_ent_curves():

    smb_ent_curves = {}

    smb_ent_curves['smb_pen'] = np.zeros(37)
    smb_ent_curves['smb_rev'] = np.zeros(181)
    smb_ent_curves['ent_pen'] = np.zeros(37)
    smb_ent_curves['ent_rev'] = np.zeros(181)
    smb_ent_curves['smb_ent_cost'] = np.zeros(181)
    smb_ent_curves['smb_ent_cost_max_cap'] = np.zeros(181)
    smb_ent_curves['smb_ent_cashflow'] = np.zeros(181)
    smb_ent_curves['smb_ent_cashflow_less_he_trnsprt'] = np.zeros(181)
    smb_ent_curves['smb_ent_cashflow_max_cap'] = np.zeros(181)

    return smb_ent_curves

######################################################################
# Build Cashflows for SMB and ENT
######################################################################
def build_parent_smb_ent_curves(probuild_id):
    smb_ent_inputs = prep_parent_smb_ent_inputs(probuild_id)
    smb_ent_curves = prep_parent_smb_ent_curves()
    smb_ent_curves = build_parent_smb_pen_curve(smb_ent_inputs, smb_ent_curves)
    smb_ent_curves = build_parent_ent_pen_curve(smb_ent_inputs, smb_ent_curves)
    smb_ent_curves = build_parent_smb_rev_flow(smb_ent_inputs, smb_ent_curves)
    smb_ent_curves = build_parent_ent_rev_flow(probuild_id, smb_ent_inputs, smb_ent_curves)
    smb_ent_curves = build_parent_smb_ent_cost_flow(probuild_id, smb_ent_inputs, smb_ent_curves)
    smb_ent_curves = build_parent_smb_ent_cashflow(smb_ent_inputs, smb_ent_curves)
    return smb_ent_curves

######################################################################
# Build pentration curve for SMB
######################################################################
def build_parent_smb_pen_curve(smb_ent_inputs, smb_ent_curves):

    smb_calc_pen = smb_ent_curves['smb_pen']
    inputs = smb_ent_inputs

    delta_24mo = inputs['smb_36mo_pen'] - inputs['smb_12mo_pen']
    for i in range(37):
        if i<=1:
            smb_calc_pen[i] = 0
        elif i>=2 and i<=12:
            smb_calc_pen[i] = inputs['smb_12mo_pen'] * (i / 12)
        elif i>=13 and i<=36:
            smb_calc_pen[i] = (inputs['smb_12mo_pen']
                                + delta_24mo
                                * (i - 12)/24
                                )
        else:
            print('Pentration curve months:', i, 'Error fall through')
            #sys.exit()

    smb_ent_curves['smb_pen'] = smb_calc_pen

    return smb_ent_curves

######################################################################
# Build pentration curve for ENT
######################################################################
def build_parent_ent_pen_curve(smb_ent_inputs, smb_ent_curves):

    ent_calc_pen = smb_ent_curves['ent_pen']
    inputs = smb_ent_inputs

    delta_24mo = inputs['ent_36mo_pen'] - inputs['ent_12mo_pen']
    for i in range(37):
        if i<=2:
            ent_calc_pen[i] = 0
        elif i>=3 and i<=12:
            ent_calc_pen[i] = inputs['ent_12mo_pen'] * (i / 12)
        elif i>=13 and i<=36:
            ent_calc_pen[i] = (inputs['ent_12mo_pen']
                                + delta_24mo
                                * (i - 12)/24
                                )
        else:
            print('Pentration curve months:', i, ' Error fall through')
            #sys.exit()

    smb_ent_curves['ent_pen'] = ent_calc_pen
    return smb_ent_curves

######################################################################
# Build revenue flows for SMB
######################################################################
def build_parent_smb_rev_flow(smb_ent_inputs, smb_ent_curves):

    smb_calc_rev = smb_ent_curves['smb_rev']
    inputs = smb_ent_inputs

    for i in range(181):
        if i<=1:
            smb_calc_rev[i] = 0
        elif i>=2 and i<=36:
            smb_calc_rev[i] = (
                               ((inputs['smb_qb_ct']
                               - inputs['smb_deal_in_hand_ct'])
                               * smb_ent_curves['smb_pen'][i]
                               * inputs['smb_arpu'])
                               + inputs['smb_deal_in_hand_mrc']
                               )
        elif i==37:
            smb_calc_rev[i] = (
                               (smb_calc_rev[i-1]
                               - inputs['smb_deal_in_hand_mrc'])
                               * (1 - inputs['smb_churn'])
                               )
        else:
            smb_calc_rev[i] = (
                                smb_calc_rev[i-1]
                                * (1 - inputs['smb_churn'])
                              )

    smb_ent_curves['smb_rev'] = smb_calc_rev
    return smb_ent_curves

######################################################################
# Build revenue flows for ENT
######################################################################
def build_parent_ent_rev_flow(probuild_id, smb_ent_inputs, smb_ent_curves):

    ent_calc_rev = smb_ent_curves['ent_rev']
    inputs = smb_ent_inputs

    (data_center_rev,
    data_center_opex,
    data_center_cashflow,
    data_center_circuits) = parent_data_center.build_parent_data_center_consol_curves(probuild_id)

    for i in range(181):
        if i<=2:
            ent_calc_rev[i] = 0
        elif i>=3 and i<=36:
            ent_calc_rev[i] = (
                               ((inputs['ent_qb_ct']
                               - inputs['ent_deal_in_hand_ct'])
                               * smb_ent_curves['ent_pen'][i]
                               * inputs['ent_arpu'])
                               + inputs['ent_deal_in_hand_mrc']
                               + data_center_rev[i]
                               )
        elif i==37:
            ent_calc_rev[i] = (
                               (ent_calc_rev[i-1]
                               - inputs['ent_deal_in_hand_mrc'])
                               * (1 - inputs['ent_churn'])
                               + (data_center_rev[i] - data_center_rev[i-1])
                               )
        else:
            ent_calc_rev[i] = (ent_calc_rev[i-1]
                               * (1 - inputs['ent_churn'])
                               + (data_center_rev[i] - data_center_rev[i-1])
                               )
    smb_ent_curves['ent_rev'] = ent_calc_rev
    return smb_ent_curves

######################################################################
# Build Cost Flows for SMB and ENT
######################################################################
def build_parent_smb_ent_cost_flow(probuild_id, smb_ent_inputs, smb_ent_curves):

    calc_cost = smb_ent_curves['smb_ent_cost']
    calc_cost_max_cap = smb_ent_curves['smb_ent_cost_max_cap']
    inputs = smb_ent_inputs
    curves = smb_ent_curves

    (data_center_rev,
    data_center_opex,
    data_center_cashflow,
    data_center_circuits) = parent_data_center.build_parent_data_center_consol_curves(probuild_id)

    delta_pen_smb = inputs['smb_36mo_pen'] - inputs['smb_12mo_pen']
    delta_pen_ent = inputs['ent_36mo_pen'] - inputs['ent_12mo_pen']

    for i in range(181):
        if i==0:
            calc_cost[i] = -1 * (inputs['row_est_build_cost']
                                 + inputs['headend_cost']
                                 + inputs['transport_cost']
                                 + inputs['access_fees_one_time']
                                 + inputs['access_fees_monthly']
                                 - inputs['customer_contribution']
                                 - data_center_cashflow[i]
                                 )
            calc_cost_max_cap[i] = -1 * (+ inputs['access_fees_one_time']
                                     + inputs['access_fees_monthly']
                                     - inputs['customer_contribution']
                                     - data_center_cashflow[i]
                                     )
        elif i==1 or i > 36:
            calc_cost[i] = -1 * (inputs['smb_opex_load']
                                 * curves['smb_rev'][i]
                                 + inputs['ent_opex_load']
                                 * curves['ent_rev'][i]
                                 + inputs['access_fees_monthly']
                                 - data_center_opex[i]
                                 )
            calc_cost_max_cap[i] = calc_cost[i]
        elif i==2:
            calc_cost[i] = -1 * (inputs['smb_12mo_pen'] * i / 12
                                 * (inputs['smb_qb_ct']
                                 - inputs['smb_deal_in_hand_ct'])
                                 * inputs['smb_cost']
                                 + inputs['smb_opex_load']
                                 * curves['smb_rev'][i]
                                 #+ inputs['ent_opex_load']
                                 #* curves['ent_rev'][i]
                                 + inputs['access_fees_monthly']
                                 + inputs['smb_deal_in_hand_ct']
                                 * inputs['smb_cost']
                                 - data_center_opex[i]
                                 )
            calc_cost_max_cap[i] = calc_cost[i]
        elif i==3:
            calc_cost[i] = -1 * (inputs['smb_12mo_pen'] / 12
                                 * (inputs['smb_qb_ct']
                                 - inputs['smb_deal_in_hand_ct'])
                                 * inputs['smb_cost']
                                 + inputs['smb_opex_load']
                                 * curves['smb_rev'][i]
                                 + inputs['ent_12mo_pen'] * i / 12
                                 * (inputs['ent_qb_ct']
                                 - inputs['ent_deal_in_hand_ct'])
                                 * inputs['ent_cost']
                                 + inputs['ent_opex_load']
                                 * (curves['ent_rev'][i]
                                 - data_center_rev[i])
                                 + inputs['access_fees_monthly']
                                 + inputs['ent_deal_in_hand_ct']
                                 * inputs['ent_cost']
                                 - data_center_opex[i]
                                 )
            calc_cost_max_cap[i] = calc_cost[i]
        elif i>=4 and i<=12:
            calc_cost[i] = -1 * (inputs['smb_12mo_pen'] / 12
                                * (inputs['smb_qb_ct']
                                - inputs['smb_deal_in_hand_ct'])
                                * inputs['smb_cost']
                                + inputs['smb_opex_load']
                                * curves['smb_rev'][i]
                                + inputs['ent_12mo_pen'] / 12
                                * (inputs['ent_qb_ct']
                                - inputs['ent_deal_in_hand_ct'])
                                * inputs['ent_cost']
                                + inputs['ent_opex_load']
                                * (curves['ent_rev'][i]
                                - data_center_rev[i])
                                + inputs['access_fees_monthly']
                                - data_center_opex[i]
                                )
            calc_cost_max_cap[i] = calc_cost[i]
        elif i>=13 and i<=36:
            calc_cost[i] = -1 * (delta_pen_smb / 24
                                 * (inputs['smb_qb_ct']
                                 - inputs['smb_deal_in_hand_ct'])
                                 * inputs['smb_cost']
                                 + inputs['smb_opex_load']
                                 * curves['smb_rev'][i]
                                 + delta_pen_ent / 24
                                 * (inputs['ent_qb_ct']
                                 - inputs['ent_deal_in_hand_ct'])
                                 * inputs['ent_cost']
                                 + inputs['ent_opex_load']
                                 * (curves['ent_rev'][i]
                                 - data_center_rev[i])
                                 + inputs['access_fees_monthly']
                                 - data_center_opex[i]
                                 )
            calc_cost_max_cap[i] = calc_cost[i]

    smb_ent_curves['smb_ent_cost'] = calc_cost
    smb_ent_curves['smb_ent_cost_max_cap'] = calc_cost_max_cap
    return smb_ent_curves

######################################################################
# Build Cashflows for SMB and ENT
######################################################################
def build_parent_smb_ent_cashflow(smb_ent_inputs, smb_ent_curves):

    calc_cashflow = smb_ent_curves['smb_ent_cashflow']
    calc_cashflow_less_he_trnsprt = smb_ent_curves['smb_ent_cashflow_less_he_trnsprt']
    calc_cashflow_max_cap = smb_ent_curves['smb_ent_cashflow_max_cap']
    inputs = smb_ent_inputs
    curves = smb_ent_curves

    for i in range(181):
        calc_cashflow[i] = (curves['smb_rev'][i]
                            + curves['ent_rev'][i]
                            + curves['smb_ent_cost'][i]
                            )
        calc_cashflow_max_cap[i] = (curves['smb_rev'][i]
                                    + curves['ent_rev'][i]
                                    + curves['smb_ent_cost_max_cap'][i]
                                    )
    smb_ent_curves['smb_ent_cashflow'] = calc_cashflow
    smb_ent_curves['smb_ent_cashflow_max_cap'] = calc_cashflow_max_cap

    calc_cashflow_less_he_trnsprt = list(calc_cashflow)
    calc_cashflow_less_he_trnsprt[0] = (calc_cashflow_less_he_trnsprt[0]
                                        + inputs['headend_cost']
                                        + inputs['transport_cost']
                                        )
    smb_ent_curves['smb_ent_cashflow_less_he_trnsprt'] = calc_cashflow_less_he_trnsprt

    return smb_ent_curves

######################################################################
# Build SMB and ENT Dicts
######################################################################
def build_smb_ent_dicts(probuild_id):
    ### Call function to build the smb_ent_curves ###
    smb_ent_curves = build_parent_smb_ent_curves(probuild_id)

    ### Build initial dicts before customizing with data ###
    smb_pen, smb_rev, ent_pen, ent_rev, smb_ent_cost, smb_ent_cashflow  = (
                    {} for i in range(6))

    for i in range(181):
        month = "Month_" + str(i)
        smb_rev[month] = round(smb_ent_curves['smb_rev'][i], 2)
        ent_rev[month] = round(smb_ent_curves['ent_rev'][i], 2)
        smb_ent_cost[month] = round(smb_ent_curves['smb_ent_cost'][i], 2)
        smb_ent_cashflow[month] = round(smb_ent_curves['smb_ent_cashflow'][i], 2)

    for i in range(37):
        month = "Month_" + str(i)
        smb_pen[month] = round(smb_ent_curves['smb_pen'][i], 3)
        ent_pen[month] = round(smb_ent_curves['ent_pen'][i], 3)

    return smb_pen, smb_rev, ent_pen, ent_rev, smb_ent_cost, smb_ent_cashflow
