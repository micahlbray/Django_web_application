from django.db.models import Sum, Max, Count
from django.db import connection
from miBuilds.models import (AppProbuild,
                            AppBuilding,
                            AppBusiness,
                            AppSfDealinhand,
                            AppMdu,
                            AppDatacenter,
                            AppFile,
                            AssumpRegion,
                            AssumpMduBuildRegion,
                            AssumpMduBuild,
                            AssumpSegment,
                            AssumpDataCenterType,
                            AssumpDataCenterEquipType,
                            AssumpDataCenterCircuitEoy,
                            LkRegion,
                            LkState,
                            LkDataCenterEquipType,
                            LkSegmentType,
                            LkBuildingType,
                            LkDwellingType,
                            )
from miBuilds.utils import(ifnull, strDollarToDecimal, strPercentToDecimal)
import numpy as np
import pandas as pd
import codecs, json, sqlalchemy, urllib, math

######################################################################
# Prep SMB and ENT data inputs for future use
######################################################################
def prep_smb_ent_inputs(request, *args):
    ### Extract inputs from the GET request
    if request.method == 'GET':
        probuild_id = request.GET.get('probuild_id', None)
        customer_contribution = strDollarToDecimal(ifnull(request.GET.get('customer_contribution'), 0))
        row_est_build_cost = strDollarToDecimal(ifnull(request.GET.get('row_est_build_cost'), 0))
        headend_cost = strDollarToDecimal(ifnull(request.GET.get('headend_cost'), 0))
        transport_cost = strDollarToDecimal(ifnull(request.GET.get('transport_cost'), 0))
        private_property_cost = strDollarToDecimal(ifnull(request.GET.get('private_property_cost'), 0))
        lat_construct_upfront_pct = strPercentToDecimal(ifnull(request.GET.get('lat_construct_upfront_pct'), 0))
        smb_arpu = strDollarToDecimal(ifnull(request.GET.get('smb_arpu'), 0))
        ent_arpu = strDollarToDecimal(ifnull(request.GET.get('ent_arpu'), 0))
        smb_12mo_pen = strPercentToDecimal(ifnull(request.GET.get('smb_12mo_pen'), 0))
        smb_36mo_pen = strPercentToDecimal(ifnull(request.GET.get('smb_36mo_pen'), 0))
        ent_12mo_pen = strPercentToDecimal(ifnull(request.GET.get('ent_12mo_pen'), 0))
        ent_36mo_pen = strPercentToDecimal(ifnull(request.GET.get('ent_36mo_pen'), 0))
        building_ct = strPercentToDecimal(ifnull(request.GET.get('building_ct'), 0))
        multi_tenant_building_ct = strPercentToDecimal(ifnull(request.GET.get('multi_tenant_building_ct'), 0))
        mdu_ct = strPercentToDecimal(ifnull(request.GET.get('mdu_ct'), 0))
        smb_qb_ct = strPercentToDecimal(ifnull(request.GET.get('smb_qb_ct'), 0))
        ent_qb_ct = strPercentToDecimal(ifnull(request.GET.get('ent_qb_ct'), 0))
        smb_deal_in_hand_ct = strPercentToDecimal(ifnull(request.GET.get('smb_deal_in_hand_ct'), 0))
        smb_deal_in_hand_mrc = strPercentToDecimal(ifnull(request.GET.get('smb_deal_in_hand_mrc'), 0))
        ent_deal_in_hand_ct = strPercentToDecimal(ifnull(request.GET.get('ent_deal_in_hand_ct'), 0))
        ent_deal_in_hand_mrc = strPercentToDecimal(ifnull(request.GET.get('ent_deal_in_hand_mrc'), 0))
    elif request.method == 'POST':
        probuild_id = request.POST.get('probuild_id', None)
        customer_contribution = ifnull(request.POST.get('customer_contribution'), 0)
        row_est_build_cost = ifnull(request.POST.get('row_est_build_cost'), 0)
        headend_cost = ifnull(request.POST.get('headend_cost'), 0)
        transport_cost = ifnull(request.POST.get('transport_cost'), 0)
        private_property_cost = ifnull(request.POST.get('private_property_cost'), 0)
        lat_construct_upfront_pct = ifnull(request.GET.get('lateral_construct_upfront_pct'), 0)
        smb_arpu = ifnull(request.POST.get('smb_arpu'), 0)
        ent_arpu = ifnull(request.POST.get('ent_arpu'), 0)
        smb_12mo_pen = ifnull(request.POST.get('smb_12mo_pen'), 0)
        smb_36mo_pen = ifnull(request.POST.get('smb_36mo_pen'), 0)
        ent_12mo_pen = ifnull(request.POST.get('ent_12mo_pen'), 0)
        ent_36mo_pen = ifnull(request.POST.get('ent_36mo_pen'), 0)
        building_ct = strPercentToDecimal(ifnull(request.POST.get('building_ct'), 0))
        multi_tenant_building_ct = strPercentToDecimal(ifnull(request.POST.get('multi_tenant_building_ct'), 0))
        mdu_ct = strPercentToDecimal(ifnull(request.POST.get('mdu_ct'), 0))
        smb_qb_ct = strPercentToDecimal(ifnull(request.POST.get('smb_qb_ct'), 0))
        ent_qb_ct = strPercentToDecimal(ifnull(request.POST.get('ent_qb_ct'), 0))
        smb_deal_in_hand_ct = strPercentToDecimal(ifnull(request.POST.get('smb_deal_in_hand_ct'), 0))
        smb_deal_in_hand_mrc = strPercentToDecimal(ifnull(request.POST.get('smb_deal_in_hand_mrc'), 0))
        ent_deal_in_hand_ct = strPercentToDecimal(ifnull(request.POST.get('ent_deal_in_hand_ct'), 0))
        ent_deal_in_hand_mrc = strPercentToDecimal(ifnull(request.POST.get('ent_deal_in_hand_mrc'), 0))

    ################################### Building/Business count inputs ###################################
    ### Assign Variables ###
    access_fees_one_time = 0
    access_fees_monthly = 0
    building_ct_less_multi = building_ct - multi_tenant_building_ct
    business_ct = smb_qb_ct + ent_qb_ct

    ################################### Lateral calculation variables ###################################
    if building_ct == 0:
        lat_cost_per_building = 0
    else:
        lat_cost_per_building = private_property_cost / building_ct

    if multi_tenant_building_ct == 0:
        lat_cost_per_multi_tenant = 0
    elif (multi_tenant_building_ct - mdu_ct) == 0:
        lat_cost_per_multi_tenant = 0
    elif business_ct == 0:
        lat_cost_per_multi_tenant = 0
    elif (business_ct - building_ct_less_multi) == 0:
        lat_cost_per_multi_tenant = 0
    elif (
            ((business_ct - building_ct_less_multi) / (multi_tenant_building_ct - mdu_ct))
            *
            (smb_36mo_pen * smb_qb_ct / business_ct + ent_36mo_pen * ent_qb_ct / business_ct)
        ) == 0:
        lat_cost_per_multi_tenant = 0
    else:
        lat_cost_per_multi_tenant = (
                                    lat_cost_per_building
                                    /
                                    (
                                    ((business_ct - building_ct_less_multi) / (multi_tenant_building_ct - mdu_ct))
                                    *
                                    (smb_36mo_pen * smb_qb_ct / business_ct + ent_36mo_pen * ent_qb_ct / business_ct)
                                    )
                                    )

    if lat_construct_upfront_pct:
        lat_construct_upfront_pct = lat_construct_upfront_pct
    elif private_property_cost == 0:
        lat_construct_upfront_pct = 0
    elif business_ct == 0:
        lat_construct_upfront_pct = 0
    elif building_ct == 0:
        lat_construct_upfront_pct = 0
    else:
        lat_construct_upfront_pct = ((multi_tenant_building_ct
                                    + building_ct_less_multi
                                    * (smb_36mo_pen * smb_qb_ct / business_ct
                                    + ent_36mo_pen * ent_qb_ct / business_ct))
                                    / building_ct
                                    )

    if private_property_cost == 0:
        exp_lat_construct_upfront_pct = 0
    elif business_ct == 0:
        exp_lat_construct_upfront_pct = 0
    elif building_ct == 0:
        exp_lat_construct_upfront_pct = 0
    else:
        exp_lat_construct_upfront_pct = ((multi_tenant_building_ct
                                        + building_ct_less_multi
                                        * (smb_36mo_pen * smb_qb_ct / business_ct
                                        + ent_36mo_pen * ent_qb_ct / business_ct))
                                        / building_ct
                                        )

    if business_ct == 0:
        passing_cost_per = 0
    else:
        passing_cost_per = ((row_est_build_cost + headend_cost
                       + transport_cost + private_property_cost)
                       / business_ct
                       )

    if business_ct == 0:
        lat_cost_per_connect = 0
    else:
        lat_cost_per_connect = ((lat_cost_per_building
                           * building_ct_less_multi
                           / business_ct)
                           + lat_cost_per_multi_tenant
                           * (business_ct - building_ct_less_multi)
                           / business_ct
                           )

    ################################### SMB Assumptions ###################################
    smb_assump_sql = ('''   SELECT	Capex_Data_and_Install as smb_capex_data
                            		,Capex_Voice_and_Install as smb_capex_voice
                            		,Capex_Video_and_Install as smb_capex_video
                            		,Opex_Load as smb_opex_load
                            		,Churn as smb_churn
                            FROM BI_MIP.miBuilds.assump_Segment
                            WHERE Segment_Type_Id = 1
                            	and IsActive = 1'''
                        )
    smb_assump_df = pd.read_sql(smb_assump_sql, connection)

    ################################### SMB Costing variables ###################################
    smb_capex_data = float(ifnull(smb_assump_df['smb_capex_data'].values[0], 0))
    smb_capex_voice = float(ifnull(smb_assump_df['smb_capex_voice'].values[0], 0))
    smb_capex_video = float(ifnull(smb_assump_df['smb_capex_video'].values[0], 0))
    smb_opex_load = float(ifnull(smb_assump_df['smb_opex_load'].values[0], 0))
    smb_churn = float(ifnull(smb_assump_df['smb_churn'].values[0], 0))
    smb_capex = (
                            smb_capex_data
                            + (smb_capex_voice * 0.7)
                            + (smb_capex_video * 0.6)
                            )
    smb_nrr = -1 * (smb_arpu * 0.25)
    smb_commission = smb_arpu * 0.6
    smb_total_upfront_cost = smb_capex + smb_nrr + smb_commission
    if business_ct == 0:
        smb_add_osp_lat_cost = 0
    else:
        smb_add_osp_lat_cost = (
                            lat_cost_per_building
                            * building_ct_less_multi
                            / business_ct
                            + lat_cost_per_multi_tenant
                            * (business_ct - building_ct_less_multi)
                            / business_ct
                            )
    smb_cost = smb_total_upfront_cost + smb_add_osp_lat_cost

    ################################### ENT Assumptions ###################################
    ent_assump_sql = ('''   SELECT	Capex as ent_capex
                            		,Maint_Opex as ent_maint_opex
                            		,Opex_Load as ent_opex_load
                            		,Churn as ent_churn
                            FROM BI_MIP.miBuilds.assump_Segment
                            WHERE Segment_Type_Id <> 1
                            	and IsActive = 1'''
                        )
    ent_assump_df = pd.read_sql(ent_assump_sql, connection)

    ################################### ENT Costing variables ###################################
    ent_capex = float(ifnull(ent_assump_df['ent_capex'].values[0], 0))
    ent_maint_opex = float(ifnull(ent_assump_df['ent_maint_opex'].values[0], 0))
    ent_opex_load = float(ifnull(ent_assump_df['ent_opex_load'].values[0], 0))
    ent_churn = float(ifnull(ent_assump_df['ent_churn'].values[0], 0))
    ent_arpu_div = float(AssumpRegion.objects.values_list('ent_arpu', flat=True).filter(region='7', isactive = '1')[0])
    ent_bandwidth_cost = 4.24 * 85 * ent_arpu / ent_arpu_div
    ent_nrr = -1 * (ent_arpu * 0.25)
    ent_commission = ent_arpu * 0.6
    ent_total_upfront_cost = ent_capex + ent_maint_opex + ent_bandwidth_cost + ent_nrr + ent_commission
    if business_ct == 0:
        ent_add_osp_lat_cost = 0
    else:
        ent_add_osp_lat_cost = (
                            lat_cost_per_building
                            * building_ct_less_multi
                            / business_ct
                            + lat_cost_per_multi_tenant
                            * (business_ct - building_ct_less_multi)
                            / business_ct
                            )
    ent_cost = ent_total_upfront_cost + ent_add_osp_lat_cost

    ################### BUILD INPUTS DICTIONARY ###################
    inputs = {}
    inputs['access_fees_one_time'] = access_fees_one_time
    inputs['access_fees_monthly'] = access_fees_monthly
    inputs['customer_contribution'] = customer_contribution
    inputs['row_est_build_cost'] = row_est_build_cost
    inputs['headend_cost'] = headend_cost
    inputs['transport_cost'] = transport_cost
    inputs['private_property_cost'] = private_property_cost
    inputs['smb_arpu'] = smb_arpu
    inputs['ent_arpu'] = ent_arpu
    inputs['smb_12mo_pen'] = smb_12mo_pen
    inputs['smb_36mo_pen'] = smb_36mo_pen
    inputs['ent_12mo_pen'] = ent_12mo_pen
    inputs['ent_36mo_pen'] = ent_36mo_pen
    inputs['smb_qb_ct'] = smb_qb_ct
    inputs['ent_qb_ct'] = ent_qb_ct
    inputs['business_ct'] = business_ct
    inputs['multi_tenant_building_ct'] = multi_tenant_building_ct
    inputs['building_ct'] = building_ct
    inputs['building_ct_less_multi'] = building_ct_less_multi
    inputs['dealinhand_ct'] = smb_deal_in_hand_ct + ent_deal_in_hand_ct
    inputs['mdu_ct'] = mdu_ct
    inputs['smb_churn'] = smb_churn
    inputs['smb_deal_in_hand_ct'] = smb_deal_in_hand_ct
    inputs['smb_deal_in_hand_mrc'] = smb_deal_in_hand_mrc
    inputs['ent_churn'] = ent_churn
    inputs['ent_deal_in_hand_ct'] = ent_deal_in_hand_ct
    inputs['ent_deal_in_hand_mrc'] = ent_deal_in_hand_mrc
    inputs['lat_cost_per_building'] = lat_cost_per_building
    inputs['lat_cost_per_multi_tenant'] = lat_cost_per_multi_tenant
    inputs['lat_construct_upfront_pct'] = lat_construct_upfront_pct
    inputs['exp_lat_construct_upfront_pct'] = exp_lat_construct_upfront_pct
    inputs['passing_cost_per'] = passing_cost_per
    inputs['lat_cost_per_connect'] = lat_cost_per_connect
    inputs['smb_cost'] = smb_cost
    inputs['smb_opex_load'] = smb_opex_load
    inputs['ent_cost'] = ent_cost
    inputs['ent_opex_load'] = ent_opex_load

    #print(inputs)

    smb_ent_inputs = {}
    smb_ent_inputs = inputs.copy()

    return smb_ent_inputs

######################################################################
# Define Arrays
######################################################################
def prep_smb_ent_curves():

    smb_ent_curves = {}

    smb_ent_curves['smb_pen'] = np.zeros(37)
    smb_ent_curves['smb_rev'] = np.zeros(181)
    smb_ent_curves['ent_pen'] = np.zeros(37)
    smb_ent_curves['ent_rev'] = np.zeros(181)
    smb_ent_curves['smb_ent_cost'] = np.zeros(181)
    smb_ent_curves['smb_ent_cashflow'] = np.zeros(181)
    smb_ent_curves['smb_ent_cashflow_less_he_trnsprt'] = np.zeros(181)

    return smb_ent_curves

######################################################################
# Build pentration curve for SMB
######################################################################
def build_smb_pen_curve(smb_ent_inputs, smb_ent_curves):

    smb_calc_pen = smb_ent_curves['smb_pen']
    inputs = smb_ent_inputs

    delta_24mo = inputs['smb_36mo_pen'] - inputs['smb_12mo_pen']
    for i in range(37):
        if i<=1:
            smb_calc_pen[i] = 0
        elif i>=2 and i<=12:
            smb_calc_pen[i] = inputs['smb_12mo_pen'] * (i / 12)
        elif i>=13 and i<=36:
            smb_calc_pen[i] = (inputs['smb_12mo_pen']
                                + delta_24mo
                                * (i - 12)/24
                                )
        else:
            print('Pentration curve months:', i, 'Error fall through')
            #sys.exit()

    smb_ent_curves['smb_pen'] = smb_calc_pen

    return smb_ent_curves

######################################################################
# Build pentration curve for ENT
######################################################################
def build_ent_pen_curve(smb_ent_inputs, smb_ent_curves):

    ent_calc_pen = smb_ent_curves['ent_pen']
    inputs = smb_ent_inputs

    delta_24mo = inputs['ent_36mo_pen'] - inputs['ent_12mo_pen']
    for i in range(37):
        if i<=2:
            ent_calc_pen[i] = 0
        elif i>=3 and i<=12:
            ent_calc_pen[i] = inputs['ent_12mo_pen'] * (i / 12)
        elif i>=13 and i<=36:
            ent_calc_pen[i] = (inputs['ent_12mo_pen']
                                + delta_24mo
                                * (i - 12)/24
                                )
        else:
            print('Pentration curve months:', i, ' Error fall through')
            #sys.exit()

    smb_ent_curves['ent_pen'] = ent_calc_pen
    return smb_ent_curves

######################################################################
# Build revenue flows for SMB
######################################################################
def build_smb_rev_flow(smb_ent_inputs, smb_ent_curves):

    smb_calc_rev = smb_ent_curves['smb_rev']
    inputs = smb_ent_inputs

    for i in range(181):
        if i<=1:
            smb_calc_rev[i] = 0
        elif i>=2 and i<=36:
            smb_calc_rev[i] = (
                               ((inputs['smb_qb_ct']
                               - inputs['smb_deal_in_hand_ct'])
                               * smb_ent_curves['smb_pen'][i]
                               * inputs['smb_arpu'])
                               + inputs['smb_deal_in_hand_mrc']
                               )
        elif i==37:
            smb_calc_rev[i] = (
                               (smb_calc_rev[i-1]
                               - inputs['smb_deal_in_hand_mrc'])
                               * (1 - inputs['smb_churn'])
                               )
        else:
            smb_calc_rev[i] = (
                                smb_calc_rev[i-1]
                                * (1 - inputs['smb_churn'])
                              )

    smb_ent_curves['smb_rev'] = smb_calc_rev
    return smb_ent_curves

######################################################################
# Build revenue flows for ENT
######################################################################
def build_ent_rev_flow(request, smb_ent_inputs, smb_ent_curves):

    ent_calc_rev = smb_ent_curves['ent_rev']
    inputs = smb_ent_inputs

    for i in range(181):
        if i<=2:
            ent_calc_rev[i] = 0
        elif i>=3 and i<=36:
            ent_calc_rev[i] = (
                               ((inputs['ent_qb_ct']
                               - inputs['ent_deal_in_hand_ct'])
                               * smb_ent_curves['ent_pen'][i]
                               * inputs['ent_arpu'])
                               + inputs['ent_deal_in_hand_mrc']
                               )
        elif i==37:
            ent_calc_rev[i] = (
                               (ent_calc_rev[i-1]
                               - inputs['ent_deal_in_hand_mrc'])
                               * (1 - inputs['ent_churn'])
                               )
        else:
            ent_calc_rev[i] = (ent_calc_rev[i-1]
                               * (1 - inputs['ent_churn'])
                               )
    smb_ent_curves['ent_rev'] = ent_calc_rev
    return smb_ent_curves

######################################################################
# Build Cost Flows for SMB and ENT
######################################################################
def build_smb_ent_cost_flow(request, smb_ent_inputs, smb_ent_curves):

    calc_cost = smb_ent_curves['smb_ent_cost']
    inputs = smb_ent_inputs
    curves = smb_ent_curves

    delta_pen_smb = inputs['smb_36mo_pen'] - inputs['smb_12mo_pen']
    delta_pen_ent = inputs['ent_36mo_pen'] - inputs['ent_12mo_pen']

    for i in range(181):
        if i==0:
            calc_cost[i] = -1 * (inputs['row_est_build_cost']
                                 + inputs['headend_cost']
                                 + inputs['transport_cost']
                                 + inputs['access_fees_one_time']
                                 + inputs['access_fees_monthly']
                                 - inputs['customer_contribution']
                                 )
        elif i==1 or i > 36:
            calc_cost[i] = -1 * (inputs['smb_opex_load']
                                 * curves['smb_rev'][i]
                                 + inputs['ent_opex_load']
                                 * curves['ent_rev'][i]
                                 + inputs['access_fees_monthly']
                                 )
        elif i==2:
            calc_cost[i] = -1 * (inputs['smb_12mo_pen'] * i / 12
                                 * (inputs['smb_qb_ct']
                                 - inputs['smb_deal_in_hand_ct'])
                                 * inputs['smb_cost']
                                 + inputs['smb_opex_load']
                                 * curves['smb_rev'][i]
                                 + inputs['access_fees_monthly']
                                 + inputs['smb_deal_in_hand_ct']
                                 * inputs['smb_cost']
                                 )
        elif i==3:
            calc_cost[i] = -1 * (inputs['smb_12mo_pen'] / 12
                                 * (inputs['smb_qb_ct']
                                 - inputs['smb_deal_in_hand_ct'])
                                 * inputs['smb_cost']
                                 + inputs['smb_opex_load']
                                 * curves['smb_rev'][i]
                                 + inputs['ent_12mo_pen'] * i / 12
                                 * (inputs['ent_qb_ct']
                                 - inputs['ent_deal_in_hand_ct'])
                                 * inputs['ent_cost']
                                 + inputs['ent_opex_load']
                                 * (curves['ent_rev'][i])
                                 + inputs['access_fees_monthly']
                                 + inputs['ent_deal_in_hand_ct']
                                 * inputs['ent_cost']
                                 )
        elif i>=4 and i<=12:
            calc_cost[i] = -1 * (inputs['smb_12mo_pen'] / 12
                                * (inputs['smb_qb_ct']
                                - inputs['smb_deal_in_hand_ct'])
                                * inputs['smb_cost']
                                + inputs['smb_opex_load']
                                * curves['smb_rev'][i]
                                + inputs['ent_12mo_pen'] / 12
                                * (inputs['ent_qb_ct']
                                - inputs['ent_deal_in_hand_ct'])
                                * inputs['ent_cost']
                                + inputs['ent_opex_load']
                                * (curves['ent_rev'][i])
                                + inputs['access_fees_monthly']
                                )
        elif i>=13 and i<=36:
            calc_cost[i] = -1 * (delta_pen_smb / 24
                                 * (inputs['smb_qb_ct']
                                 - inputs['smb_deal_in_hand_ct'])
                                 * inputs['smb_cost']
                                 + inputs['smb_opex_load']
                                 * curves['smb_rev'][i]
                                 + delta_pen_ent / 24
                                 * (inputs['ent_qb_ct']
                                 - inputs['ent_deal_in_hand_ct'])
                                 * inputs['ent_cost']
                                 + inputs['ent_opex_load']
                                 * (curves['ent_rev'][i])
                                 + inputs['access_fees_monthly']
                                 )

    smb_ent_curves['smb_ent_cost'] = calc_cost
    return smb_ent_curves

######################################################################
# Build Cashflows for SMB and ENT
######################################################################
def build_smb_ent_cashflow(smb_ent_inputs, smb_ent_curves):

    calc_cashflow = smb_ent_curves['smb_ent_cashflow']
    calc_cashflow_less_he_trnsprt = smb_ent_curves['smb_ent_cashflow_less_he_trnsprt']
    inputs = smb_ent_inputs
    curves = smb_ent_curves

    for i in range(181):
        calc_cashflow[i] = (curves['smb_rev'][i]
                            + curves['ent_rev'][i]
                            + curves['smb_ent_cost'][i]
                            )
    smb_ent_curves['smb_ent_cashflow'] = calc_cashflow

    calc_cashflow_less_he_trnsprt = list(calc_cashflow)
    calc_cashflow_less_he_trnsprt[0] = (calc_cashflow_less_he_trnsprt[0]
                                        + inputs['headend_cost']
                                        + inputs['transport_cost']
                                        )
    smb_ent_curves['smb_ent_cashflow_less_he_trnsprt'] = calc_cashflow_less_he_trnsprt

    return smb_ent_curves

######################################################################
# Build Cashflows for SMB and ENT
######################################################################
def build_smb_ent_curves(request):
    smb_ent_inputs = prep_smb_ent_inputs(request)
    smb_ent_curves = prep_smb_ent_curves()
    smb_ent_curves = build_smb_pen_curve(smb_ent_inputs, smb_ent_curves)
    smb_ent_curves = build_ent_pen_curve(smb_ent_inputs, smb_ent_curves)
    smb_ent_curves = build_smb_rev_flow(smb_ent_inputs, smb_ent_curves)
    smb_ent_curves = build_ent_rev_flow(request, smb_ent_inputs, smb_ent_curves)
    smb_ent_curves = build_smb_ent_cost_flow(request, smb_ent_inputs, smb_ent_curves)
    smb_ent_curves = build_smb_ent_cashflow(smb_ent_inputs, smb_ent_curves)

    return smb_ent_curves

######################################################################
# Define Arrays
######################################################################
def prep_consol_curves():

    consol_curves = {}

    consol_curves['rev'] = np.zeros(181)
    consol_curves['opex'] = np.zeros(181)
    consol_curves['cost'] = np.zeros(181)
    consol_curves['cashflow'] = np.zeros(181)
    consol_curves['cashflow_less_he_trnsprt'] = np.zeros(181)

    return consol_curves

######################################################################
# Build consolidated Cashflow for SMB, ENT, Data Centers, and MDUs
######################################################################
def build_consol_curves(request):
    smb_ent_curves = build_smb_ent_curves(request)

    consol_curves = prep_consol_curves()
    calc_cashflow = consol_curves['cashflow']
    calc_cashflow_less_he_trnsprt = consol_curves['cashflow_less_he_trnsprt']

    for i in range(181):
        calc_cashflow[i] = (smb_ent_curves['smb_ent_cashflow'][i])
        calc_cashflow_less_he_trnsprt[i] = (
                            smb_ent_curves['smb_ent_cashflow_less_he_trnsprt'][i]
                            )


    consol_curves['cashflow'] = calc_cashflow
    consol_curves['cashflow_less_he_trnsprt'] = calc_cashflow_less_he_trnsprt
    return consol_curves

######################################################################
# Calc NPV and IRR
######################################################################
def calc_NPV_IRR(consol_curves):
    cost_cap_pct = 0.1
    cost_cap_time = IRR_time = 12
    WACC = cost_cap_pct / cost_cap_time
    NaN_Value_NPV = -99999999.99
    NaN_Value_IRR = -99.999
    NaN_Value_IRR_HE_Trnsprt = -99.999

    NPV = np.npv(WACC, consol_curves['cashflow'])
    NPV_Less_HE_Trnsprt = np.npv(WACC, consol_curves['cashflow_less_he_trnsprt'])
    IRR = ((1 + np.irr(consol_curves['cashflow']))
                ** IRR_time
                - 1
                )
    IRR_Less_HE_Trnsprt = ((1 + np.irr(consol_curves['cashflow_less_he_trnsprt']))
                            ** IRR_time
                            - 1
                            )

    if np.isnan(NPV):
        NPV = NaN_Value_NPV
    if np.isnan(NPV_Less_HE_Trnsprt):
        NPV_Less_HE_Trnsprt = NaN_Value_NPV
    if np.isnan(IRR):
        IRR = NaN_Value_IRR
    if np.isnan(IRR_Less_HE_Trnsprt):
        IRR_Less_HE_Trnsprt = NaN_Value_IRR_HE_Trnsprt

    return NPV, NPV_Less_HE_Trnsprt, IRR, IRR_Less_HE_Trnsprt

######################################################################
# Calc CAR Value
######################################################################
def calc_CAR(request):
    smb_ent_inputs = prep_smb_ent_inputs(request)

    data_center_capex = 0
    i = 0

    CAR = (smb_ent_inputs['row_est_build_cost']
          + smb_ent_inputs['headend_cost']
          + smb_ent_inputs['transport_cost']
          + (smb_ent_inputs['building_ct']
          * smb_ent_inputs['lat_construct_upfront_pct']
          * smb_ent_inputs['lat_cost_per_building'])
          + smb_ent_inputs['access_fees_one_time']
          )

    return CAR

######################################################################
# Calc Payback Month
######################################################################
def calc_payback_mo(consol_curves):
    cashflow = consol_curves['cashflow']
    cum_cashflow = 0
    payback_mo = 0

    for i in range(181):
        cum_cashflow = cum_cashflow + cashflow[i]
        if cum_cashflow >= 0:
            payback_mo = i
            break
        else:
            payback_mo = ''

    return payback_mo

######################################################################
# Calc ROE Gate
######################################################################
def calc_roe_gate(request):
    smb_ent_inputs = prep_smb_ent_inputs(request)
    smb_ent_curves = build_smb_ent_curves(request)

    smb_arpu = smb_ent_inputs['smb_arpu']
    ent_arpu = smb_ent_inputs['ent_arpu']
    smb_rev = smb_ent_curves['smb_rev'][36]
    ent_rev = smb_ent_curves['ent_rev'][36]

    if smb_arpu == 0:
        smb = 0
    else:
        smb = smb_rev / smb_arpu
    if ent_arpu == 0:
        ent = 0
    else:
        ent = ent_rev / ent_arpu

    ROE_Gate = math.floor(smb + ent)

    return ROE_Gate

def calc_business_resi_capital_pct(request):
    smb_ent_curves = build_smb_ent_curves(request)

    mdu_inputs = prep_mdu_inputs(request)
    mdu_curves = build_mdu_curves(mdu_inputs)
    mdu_consol_cashflow = build_mdu_consol_cashflow(mdu_curves)

    WACC = 1 ** (1/12) - 1
    NaN_Value_NPV = 0

    Business_NPV = np.npv(WACC, smb_ent_curves['smb_ent_cashflow'])
    Resi_NPV = np.npv(WACC, mdu_consol_cashflow)

    if np.isnan(Business_NPV):
        Business_NPV = NaN_Value_NPV
    if np.isnan(Resi_NPV):
        Resi_NPV = NaN_Value_NPV

    Total_NPV = Business_NPV + Resi_NPV

    if Total_NPV == 0:
        Business_Pct = 0
        Resi_Pct = 0
    else:
        Business_Pct = Business_NPV / Total_NPV
        Resi_Pct = Resi_NPV / Total_NPV

    return Business_NPV, Resi_NPV, Business_Pct, Resi_Pct

######################################################################
# Calc ROE Gate
######################################################################
def store_smb_ent_dicts(request, probuild_id):
    smb_pen, smb_rev, ent_pen, ent_rev, smb_ent_cost, smb_ent_cashflow = build_smb_ent_dicts(request)
    list_dicts = [smb_pen, smb_rev, ent_pen, ent_rev,
                    smb_ent_cost, smb_ent_cashflow]

    for dict in list_dicts:
        store_sql = ('''    INSERT INTO BI_MIP_Dev.Dev.rpt_Calculations_Dict (
                                    probuild_id, dict_category, dict_string)
                            VALUES  ({},'{}','{}')''')
        store_sql = store_sql.format(probuild_id, dict_name, dict)
        connection.cursor.execute(store_sql)
