from django import forms #ModelForm, BaseModelFormSet
from django.conf import settings
from django.utils import timezone
from django.utils.safestring import mark_safe
from django.core.exceptions import ValidationError, NON_FIELD_ERRORS
from django.utils.translation import ugettext_lazy as _
from miBuilds.models import (AppProbuild,
                            AppProbuildNote,
                            RptProbuild,
                            AppBuilding,
                            AppBuildingUpload,
                            AppBusiness,
                            AppBusinessUpload,
                            AppSfDealinhand,
                            AppMdu,
                            AppDatacenter,
                            AppDatacenterCircuitEoy,
                            AppFile,
                            AppUserFeedback,
                            RptCalculator,
                            )
import re
from decimal import Decimal
from datetime import date
from datetime import datetime

######################################################################
# Forms
######################################################################
class BusinessCaseAddSuccessForm(forms.Form):
    probuild_id = forms.IntegerField()

class BusinessCaseSelectForm(forms.ModelForm):
    class Meta:
        model = AppProbuild
        fields = ('probuild_id','name','region',
                    'addedon','addedby','submittedon','submittedby',
                    'approvedon','approvedby')

class BusinessCaseAddForm(forms.ModelForm):
    class Meta:
        model = AppProbuild
        fields = '__all__'
        widgets = {'cross_functional_review_on': forms.DateInput(
                            attrs={'type': 'date'}),
                    'est_compl_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'roe_gate_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'permitting_gate_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'access_fees_one_time': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'access_fees_monthly': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'customer_contribution': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'row_est_build_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'headend_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'transport_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'private_property_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'lateral_construct_upfront_pct': forms.TextInput(
                        attrs={'placeholder': '###.##%'}),
                    'smb_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'ent_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'smb_12mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.##%'}),
                    'smb_36mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.##%'}),
                    'ent_12mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.##%'}),
                    'ent_36mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.##%'}),
                    'roe_gate': forms.NumberInput(),
                    #'spectrum_job_id': forms.HiddenInput(),
                    'region_assump': forms.HiddenInput(),
                    'mdu_build_region_assump': forms.HiddenInput(),
                    'added': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'edited': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'submitted': forms.HiddenInput(),
                    'submittedon': forms.HiddenInput(),
                    'submittedby': forms.HiddenInput(),
                    'approved': forms.HiddenInput(),
                    'approvedon': forms.HiddenInput(),
                    'approvedby': forms.HiddenInput(),
                    'todelete': forms.HiddenInput(),
                    'todeleteon': forms.HiddenInput(),
                    'todeleteby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                    'parent_probuild_id': forms.HiddenInput(),
                    'cloned': forms.HiddenInput(),
                    'clonedon': forms.HiddenInput(),
                    'clonedby': forms.HiddenInput(),
        }
        help_texts = {
            'name': _('Please pick a unique name.'),
        }

    def clean_ent_arpu(self):
          value = strDollarToDecimal(self.cleaned_data['ent_arpu'])
          return value

class BusinessCaseRptForm(forms.ModelForm):
    class Meta:
        model = RptProbuild
        fields = '__all__'
        widgets = {'probuild': forms.HiddenInput(),
                    'lateral_construct_upfront_pct': forms.TextInput(
                        attrs={ 'placeholder': '###.#%'}),
                    'fund_bucket': forms.TextInput(
                        attrs={'readonly':'readonly'}),
                    'business_max_actual_capital': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'resi_max_actual_capital': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'smb_qb_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'ent_qb_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'building_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'multi_tenant_building_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'dealinhand_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'mdu_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'datacenter_ct': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'car_value': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'irr_pct': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'irr_pct_less_he_trnsprt': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'npv': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'npv_less_he_trnsprt': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'payback_mo': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'passing_cost_per': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'additional_osp_lateral_cost_per_connect': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'business_capital_pct': forms.HiddenInput(),
                    'resi_capital_pct': forms.HiddenInput(),
                }

class BusinessCaseEditForm(forms.ModelForm):
    class Meta:
        model = AppProbuild
        fields = '__all__'
        widgets = { 'cross_functional_review_on': forms.DateInput(
                            attrs={'type': 'date'}),
                    'est_compl_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'roe_gate_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'permitting_gate_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'access_fees_one_time': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'access_fees_monthly': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'customer_contribution': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'row_est_build_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'headend_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'transport_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'private_property_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'lateral_construct_upfront_pct': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'smb_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'ent_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'smb_12mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'smb_36mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'ent_12mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'ent_36mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'roe_gate': forms.NumberInput(),
                    'probuild_id': forms.HiddenInput(),
                    'spectrum_job_id': forms.HiddenInput(),
                    'region_assump': forms.HiddenInput(),
                    'mdu_build_region_assump': forms.HiddenInput(),
                    'added': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'edited': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'submitted': forms.HiddenInput(),
                    'submittedon': forms.HiddenInput(),
                    'submittedby': forms.HiddenInput(),
                    'approved': forms.HiddenInput(),
                    'approvedon': forms.HiddenInput(),
                    'approvedby': forms.HiddenInput(),
                    'todelete': forms.HiddenInput(),
                    'todeleteon': forms.HiddenInput(),
                    'todeleteby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                    'parent_probuild_id': forms.HiddenInput(),
                    'cloned': forms.HiddenInput(),
                    'clonedon': forms.HiddenInput(),
                    'clonedby': forms.HiddenInput(),
        }
        help_texts = {
            'jt_id': _('Required to submit.'),
            'est_compl_dt': _('Required to submit.'),
            'roe_gate_dt': _('Required to submit.'),
            'permitting_gate_dt': _('Required to submit.'),
        }
        error_messages = {
            'jt_id': {
                'required': _('Please enter a value to complete submission.')
            },
            'est_compl_dt':{
                'required': _('Please enter a value to complete submission.')
            },
            'roe_gate_dt': {
                'required': _('Please enter a value to complete submission.')
            },
            'permitting_gate_dt': {
                'required': _('Please enter a value to complete submission.')
            },
        }

#class BusinessCaseDispositionForm(forms.ModelForm):
#    class Meta:
#        model = AppProbuild
#        fields = ('disposition_type',)

class BusinessCaseNoteAddForm(forms.ModelForm):
    class Meta:
        model = AppProbuildNote
        fields = '__all__'
        widgets = {'probuild': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }
        help_texts = {
            'building_id': _('Please leave blank if there is no ID.'),
        }


class BuildingAddForm(forms.ModelForm):
    class Meta:
        model = AppBuilding
        fields = '__all__'
        widgets = { 'probuild': forms.HiddenInput(),
                    'sellability_color_coax': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'sellability_color_fiber': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }
        help_texts = {
            'building_id': _('Please leave blank if there is no ID.'),
        }


class BuildingUploadForm(forms.ModelForm):
    class Meta:
        model = AppBuildingUpload
        fields = '__all__'
        widgets = {'probuild': forms.HiddenInput(),
                    'root': forms.HiddenInput(),
                    'isdeleted': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }

class BuildingEditForm(forms.ModelForm):
    class Meta:
        model = AppBuilding
        fields = '__all__'
        widgets = { 'probuild': forms.HiddenInput(),
                    'sellability_color_coax': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'sellability_color_fiber': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'addedon': forms.DateTimeInput(
                            attrs={'readonly':'readonly'}),
                    'addedby': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'editedon': forms.DateTimeInput(
                            attrs={'readonly':'readonly'}),
                    'editedby': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }

class BusinessAddForm(forms.ModelForm):
    class Meta:
        model = AppBusiness
        fields = '__all__'
        widgets = { 'probuild': forms.HiddenInput(),
                    'sellability_color_coax': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'sellability_color_fiber': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'mip_in_or_out': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'address_id': forms.HiddenInput(),
                    'city': forms.HiddenInput(),
                    'state': forms.HiddenInput(),
                    'zip': forms.HiddenInput(),
                    'segment_assump': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }
        help_texts = {
            'business_id': _('Please leave blank if there is no ID.'),
        }

class BusinessUploadForm(forms.ModelForm):
    class Meta:
        model = AppBusinessUpload
        fields = '__all__'
        widgets = {'probuild': forms.HiddenInput(),
                    'root': forms.HiddenInput(),
                    'isdeleted': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }

class BusinessEditForm(forms.ModelForm):
    class Meta:
        model = AppBusiness
        fields = '__all__'
        widgets = {'probuild': forms.HiddenInput(),
                    'sellability_color_coax': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'sellability_color_fiber': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'mip_in_or_out': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'address_id': forms.HiddenInput(),
                    'city': forms.HiddenInput(),
                    'state': forms.HiddenInput(),
                    'zip': forms.HiddenInput(),
                    'address_id': forms.HiddenInput(),
                    'segment_assump': forms.HiddenInput(),
                    'addedon': forms.DateTimeInput(
                            attrs={'readonly':'readonly'}),
                    'addedby': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'editedon': forms.DateTimeInput(
                            attrs={'readonly':'readonly'}),
                    'editedby': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }

class RptCalculatorForm(forms.ModelForm):
    class Meta:
        model = RptCalculator
        fields = '__all__'
        widgets = { 'customer_contribution': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'row_est_build_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'headend_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'transport_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'private_property_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'lateral_construct_upfront_pct': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'smb_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'ent_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'smb_12mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'smb_36mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'ent_12mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'ent_36mo_pen': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'roe_gate': forms.NumberInput(),
                    'lateral_construct_upfront_pct': forms.TextInput(
                        attrs={ 'placeholder': '###.#%'}),
                    'fund_bucket': forms.TextInput(
                        attrs={'readonly':'readonly'}),
                    'business_max_actual_capital': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'resi_max_actual_capital': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'smb_qb_ct': forms.NumberInput(),
                    'ent_qb_ct': forms.NumberInput(),
                    'building_ct': forms.NumberInput(),
                    'multi_tenant_building_ct': forms.NumberInput(),
                    'mdu_ct': forms.NumberInput(),
                    'car_value': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'irr_pct': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'irr_pct_less_he_trnsprt': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '###.#%'}),
                    'npv': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'npv_less_he_trnsprt': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'payback_mo': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'passing_cost_per': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'additional_osp_lateral_cost_per_connect': forms.TextInput(
                        attrs={ 'readonly':'readonly',
                                'placeholder': '$#,###.00' }),
                    'business_capital_pct': forms.HiddenInput(),
                    'resi_capital_pct': forms.HiddenInput(),
                }

class DealInHandAddForm(forms.ModelForm):
    class Meta:
        model = AppSfDealinhand
        fields = '__all__'
        widgets = { 'mrr': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'probuild': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }
        help_texts = {
            'opportunity_id': _(
                '''Please use the opportunity ID that starts with the letter "O-".'''),
        }

class DealInHandEditForm(forms.ModelForm):
    class Meta:
        model = AppSfDealinhand
        fields = '__all__'
        widgets = { 'mrr': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'probuild': forms.HiddenInput(),
                    'addedon': forms.DateTimeInput(
                            attrs={'readonly':'readonly'}),
                    'addedby': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'editedon': forms.DateTimeInput(
                            attrs={'readonly':'readonly'}),
                    'editedby': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }

class MduAddForm(forms.ModelForm):
    class Meta:
        model = AppMdu
        fields = '__all__'
        widgets = { 'est_compl_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'video_penetration': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'data_penetration': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'voice_penetration': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'video_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'data_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'voice_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'video_rev_share': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'data_rev_share': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'voice_rev_share': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'opex_load': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'door_fees': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'isp_per_unit': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'converter': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'modem': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'emta': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'commission': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'penetration_ramp': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'probuild': forms.HiddenInput(),
                    'system_name': forms.HiddenInput(),
                    'mdu_build_assump': forms.HiddenInput(),
                    'mdu_build_region_assump': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }

class MduEditForm(forms.ModelForm):
    class Meta:
        model = AppMdu
        fields = '__all__'
        widgets = { 'est_compl_dt': forms.DateInput(
                            attrs={'type': 'date'}),
                    'video_penetration': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'data_penetration': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'voice_penetration': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'video_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'data_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'voice_arpu': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'video_rev_share': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'data_rev_share': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'voice_rev_share': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'opex_load': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'door_fees': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'isp_per_unit': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'converter': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'modem': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'emta': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'commission': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'penetration_ramp': forms.NumberInput(
                        attrs={'readonly':'readonly'}),
                    'probuild': forms.HiddenInput(),
                    'system_name': forms.HiddenInput(),
                    'mdu_build_assump': forms.HiddenInput(),
                    'mdu_build_region_assump': forms.HiddenInput(),
                    'addedon': forms.DateTimeInput(
                            attrs={'readonly':'readonly'}),
                    'addedby': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'editedon': forms.DateTimeInput(
                            attrs={'readonly':'readonly'}),
                    'editedby': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }

class DataCenterAddForm(forms.ModelForm):
    class Meta:
        model = AppDatacenter
        fields = '__all__'
        widgets = { 'rack': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'colo_fee': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'connect_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'mrr_per_circ_avg': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'equip_capex': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'equip_opex': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'opex_pct': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'probuild': forms.HiddenInput(),
                    'data_center_type_assump': forms.HiddenInput(),
                    'data_center_equip_type_assump': forms.HiddenInput(),
                    'data_center_circuit_eoy_assump': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }

class DataCenterEditForm(forms.ModelForm):
    class Meta:
        model = AppDatacenter
        fields = '__all__'
        widgets = { 'rack': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'colo_fee': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'connect_cost': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'mrr_per_circ_avg': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'equip_capex': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'equip_opex': forms.TextInput(
                        attrs={'placeholder': '$#,###.00'}),
                    'opex_pct': forms.TextInput(
                        attrs={'placeholder': '###.#%'}),
                    'probuild': forms.HiddenInput(),
                    'data_center_type_assump': forms.HiddenInput(),
                    'data_center_equip_type_assump': forms.HiddenInput(),
                    'data_center_circuit_eoy_assump': forms.HiddenInput(),
                    'addedon': forms.DateInput(
                            attrs={'readonly':'readonly'}),
                    'addedby': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'editedon': forms.DateInput(
                            attrs={'readonly':'readonly'}),
                    'editedby': forms.TextInput(
                            attrs={'readonly':'readonly'}),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }

class DataCenterCircuitEoyForm(forms.ModelForm):
    class Meta:
        model = AppDatacenterCircuitEoy
        fields = '__all__'
        widgets = { 'yr': forms.NumberInput(),
                    'circuit_ct': forms.NumberInput(),
                    'datacenter_id': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }

class FileUploadForm(forms.ModelForm):
    class Meta:
        model = AppFile
        fields = '__all__'
        widgets = {'probuild': forms.HiddenInput(),
                    'root': forms.HiddenInput(),
                    'isdeleted': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }


class FileEditForm(forms.ModelForm):
    class Meta:
        model = AppFile
        fields = '__all__'
        widgets = {'probuild': forms.HiddenInput(),
                    'root': forms.HiddenInput(),
                    'isdeleted': forms.HiddenInput(),
                    'addedon': forms.HiddenInput(),
                    'addedby': forms.HiddenInput(),
                    'editedon': forms.HiddenInput(),
                    'editedby': forms.HiddenInput(),
                    'deleted': forms.HiddenInput(),
                    'deletedon': forms.HiddenInput(),
                    'deletedby': forms.HiddenInput(),
                }

class UploadTestForm(forms.Form):
    upload = forms.FileField()

class PictureWidget(forms.widgets.Widget):
    def render(self, name, value, attrs=None):
        if str(value) == '':
            html1 = "<img id='id_image' style='display:block' class='rounded float-left d-block'/>"
        else:
            html1 = "<img id='id_image' style='display:block' class='rounded float-left d-block' src='" + settings.STATIC_URL + str(value) + "'/>"
        return mark_safe(html1)

class ImageTestForm(forms.ModelForm):
    image_container = forms.CharField(required=False, widget=forms.HiddenInput())

    class Meta:
        model = AppFile
        fields = '__all__'
        widgets = {
            'image': PictureWidget(),
        }

    def save(self, commit=True):
        # check image_container data
        self.instance.image.delete(False)
        imgdata = self.cleaned_data['image_container'].split(',')
        try:
            ftype = imgdata[0].split(';')[0].split('/')[1]
            fname = slugify(self.instance.title)
            self.instance.image.save('path/%s.%s' % (fname, ftype), ContentFile(imgdata[1].decode("base64")))
        except:
            pass
        return super(MyForm, self).save(commit=commit)
