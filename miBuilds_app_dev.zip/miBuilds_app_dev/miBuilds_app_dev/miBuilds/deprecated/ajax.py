from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.views import generic
from django.contrib import messages
from django.http import JsonResponse
from django.forms.models import model_to_dict
from django.conf import settings
from django.db import connection
from django.db.models import Sum, Max
from miBuilds.models import (AppProbuild,
                            RptProbuild,
                            AppBuilding,
                            AppBusiness,
                            AppSfDealinhand,
                            AppMdu,
                            AppDatacenter,
                            AppFile,
                            AssumpRegion,
                            AssumpMduBuildRegion,
                            AssumpMduBuild,
                            AssumpSegment,
                            AssumpDataCenterType,
                            AssumpDataCenterEquipType,
                            AssumpDataCenterCircuitEoy,
                            LkState,
                            LkDataCenterEquipType,
                            LkSegmentType,
                            LkBuildingType,
                            LkDwellingType,
                            )
from miBuilds import calculations, emails, calculator
from miBuilds.utils import(ifnull, strDollarToDecimal, strPercentToDecimal)
from datetime import datetime
import pandas as pd
import sqlalchemy, pickle, json, csv, codecs, urllib
from io import TextIOWrapper

######################################################################
# Functions to handle Ajax calls for Jquery
######################################################################
def get_user_permissions(request):
    user_sql = (''' EXEC BI_MIP.miBuilds.app_user_group_permission_df
                        @user_id = {}
                ''').format(request.user.id)
    user_df = pd.read_sql(user_sql, connection)
    user_perm = user_df.to_dict('records')[0]
    return JsonResponse(user_perm, safe=False)

def get_business_case_status(request):
    probuild_id = request.GET.get('probuild_id', None)
    case_sql = (''' EXEC BI_MIP.miBuilds.app_probuild_status_df
                        @probuild_id = {}
                ''').format(probuild_id)
    case_df = pd.read_sql(case_sql, connection)
    case_status = case_df.to_dict('records')[0]
    return JsonResponse(case_status, safe=False)

def get_business_case_status_and_user_group_permission(request):
    probuild_id = request.GET.get('probuild_id', None)
    sql = (''' EXEC BI_MIP.miBuilds.app_probuild_status_and_user_group_permission_df_DEV
                        @probuild_id = {},
                        @user_id = {}
                ''').format(probuild_id, request.user.id)
    df = pd.read_sql(sql, connection)
    case_status_user_perm = df.to_dict('records')[0]
    return JsonResponse(case_status_user_perm, safe=False)

def delete_business_case(request):
    probuild_id = request.GET.get('probuild_id', None)
    deletedby = request.user.username
    delete_sql = (''' EXEC BI_MIP.miBuilds.ajax_business_case_delete_update
                        @probuild_id = '{}',
                        @deletedby = '{}'
                ''')
    delete_sql = delete_sql.format(probuild_id, deletedby)
    connection.cursor().execute(delete_sql)
    return JsonResponse({'success': 'success'}, safe=False)

def select_state(request):
    region = request.GET.get('region', None)
    list_states = []
    used_states = []
    for state in LkState.objects.filter(region=region):
        if state.name not in used_states:
            used_states.append(state.name)
            list_states.append({'name': state.name, 'state_id': state.state_id})
    return JsonResponse(list_states, safe=False)

def assumps_region(request):
    region = request.GET.get('region', None)
    assumps = model_to_dict(AssumpRegion.objects.filter(
        region=region, isactive=1)[0])
    return JsonResponse(assumps, safe=False)

def email_business_case_note(request):
    emails.send_note_email(request)
    return JsonResponse({'success': 'success'}, safe=False)

def autofill_building(request):
    building_id = request.GET.get('building_id', None)
    autofill_sql = (''' EXEC BI_MIP.miBuilds.ajax_autofill_building_df
                            @building_id = '{}'
                    ''')
    autofill_sql = autofill_sql.format(building_id)
    autofill = pd.read_sql(autofill_sql, connection)
    autofill = autofill.to_dict('records')
    return JsonResponse(autofill, safe=False)

def highlight_building_unmatched(request):
    probuild_id = request.GET.get('probuild_id', None)
    sql = (''' EXEC BI_MIP.miBuilds.ajax_highlight_building_unmatched_df
                            @probuild_id = {}
                    ''').format(probuild_id)
    unmatched = pd.read_sql(sql, connection)
    unmatched = unmatched.to_dict('list')
    return JsonResponse(unmatched, safe=False)

def flag_building_serviceability(request):
    probuild_id = request.GET.get('probuild_id', None)
    sql = (''' EXEC BI_MIP.miBuilds.ajax_flag_building_transport_type_df
                            @probuild_id = {}
                    ''').format(probuild_id)
    unmatched = pd.read_sql(sql, connection)
    unmatched = unmatched.to_dict('list')
    return JsonResponse(unmatched, safe=False)

def flag_building_dwelling_type(request):
    probuild_id = request.GET.get('probuild_id', None)
    sql = (''' EXEC BI_MIP.miBuilds.ajax_flag_building_dwelling_type_df
                            @probuild_id = {}
                    ''').format(probuild_id)
    flagged = pd.read_sql(sql, connection)
    flagged = flagged.to_dict('list')
    return JsonResponse(flagged, safe=False)

def delete_building(request):
    record_id = request.GET.get('record_id', None)
    building_id = request.GET.get('building_id', None)
    deletedby = request.user.username
    deletedon = timezone.localtime(timezone.now())
    AppBuilding.objects.filter(record_id=record_id).update(
            deleted='1', deletedon=deletedon, deletedby=deletedby)
    deleted = {'building_id': building_id}
    return JsonResponse(deleted, safe=False)

def delete_building_selection(request):
    record_id_list = request.GET.getlist('record_id_list', None)
    deletedby = request.user.username
    deletedon = timezone.localtime(timezone.now())
    AppBuilding.objects.filter(record_id__in=record_id_list).update(
            deleted='1', deletedon=deletedon, deletedby=deletedby)
    return JsonResponse({'success': 'success'}, safe=False)

def autofill_business(request):
    business_id = request.GET.get('business_id', None)
    autofill_sql = (''' EXEC BI_MIP.miBuilds.ajax_autofill_business_df
                            @business_id = '{}'
                    ''')
    autofill_sql = autofill_sql.format(business_id)
    autofill = pd.read_sql(autofill_sql, connection)
    autofill = autofill.to_dict('records')
    return JsonResponse(autofill, safe=False)

def highlight_business_unmatched(request):
    probuild_id = request.GET.get('probuild_id', None)
    sql = (''' EXEC BI_MIP.miBuilds.ajax_highlight_business_unmatched_df
                            @probuild_id = {}
                    ''').format(probuild_id)
    unmatched = pd.read_sql(sql, connection)
    unmatched = unmatched.to_dict('list')
    return JsonResponse(unmatched, safe=False)

def delete_business(request):
    record_id = request.GET.get('record_id', None)
    business_id = request.GET.get('business_id', None)
    deletedby = request.user.username
    deletedon = timezone.localtime(timezone.now())
    AppBusiness.objects.filter(record_id=record_id).update(
            deleted='1', deletedon=deletedon, deletedby=deletedby)
    deleted = {'business_id': business_id}
    return JsonResponse(deleted, safe=False)

def delete_business_selection(request):
    record_id_list = request.GET.getlist('record_id_list', None)
    deletedby = request.user.username
    deletedon = timezone.localtime(timezone.now())
    AppBusiness.objects.filter(record_id__in=record_id_list).update(
            deleted='1', deletedon=deletedon, deletedby=deletedby)
    return JsonResponse({'success': 'success'}, safe=False)

def autofill_deal_in_hand(request):
    opportunity_id = request.GET.get('opportunity_id', None)
    autofill_sql = (''' SELECT  Formula_Account_Name__c as customer_name
                                ,Term_months__c as term_length_id
                                ,b.segment_type_id as segment_type_id
                                ,Total_MRC__c as mrr
                        FROM    ExternalUser.MIP.MIP2_BUSINESS_PROFILE as a
                            LEFT JOIN BI_MIP.miBuilds.lk_Segment_Type as b
                            ON a.Customer_Classification__c = b.name
                        WHERE   Record__c = {} '''
                        )
    autofill_sql = autofill_sql.format(business_id)
    autofill = pd.read_sql(autofill_sql, connection)
    autofill = autofill.to_dict('records')
    return JsonResponse(autofill, safe=False)

def delete_deal_in_hand(request):
    sf_dealinhand_id = request.GET.get('sf_dealinhand_id', None)
    sf_dealinhand_name = request.GET.get('sf_dealinhand_name', None)
    deletedby = request.user.username
    deletedon = timezone.localtime(timezone.now())
    AppSfDealinhand.objects.filter(sf_dealinhand_id=sf_dealinhand_id).update(
            deleted='1', deletedon=deletedon, deletedby=deletedby)
    deleted = {'sf_dealinhand_name': sf_dealinhand_name}
    return JsonResponse(deleted, safe=False)

def assumps_mdu(request):
    probuild_id = request.GET.get('probuild', None)
    mdu_build_type = request.GET.get('mdu_build_type', None)
    current_service_type = request.GET.get('current_service_type', None)
    if mdu_build_type == '3' and current_service_type == '4': # SFU assumptions are different
        region = AppProbuild.objects.values('region').filter(probuild_id=probuild_id)
        assumps = []
        assumps.append(model_to_dict(AssumpMduBuildRegion.objects.filter(region=region)[0]))
        assumps.append(model_to_dict(AssumpMduBuild.objects.filter(
                mdu_build_type=mdu_build_type, current_service_type=current_service_type)[0]))
        return JsonResponse(assumps, safe=False)
    else:
        assumps = model_to_dict(AssumpMduBuild.objects.filter(
                mdu_build_type=mdu_build_type, current_service_type=current_service_type)[0])
        return JsonResponse(assumps, safe=False)

def delete_mdu(request):
    mdu_id = request.GET.get('mdu_id', None)
    mdu_name = request.GET.get('mdu_name', None)
    deletedby = request.user.username
    deletedon = timezone.localtime(timezone.now())
    AppMdu.objects.filter(mdu_id=mdu_id).update(
            deleted='1', deletedon=deletedon, deletedby=deletedby)
    deleted = {'mdu_name': mdu_name}
    return JsonResponse(deleted, safe=False)

def assumps_data_center_type(request):
    data_center_type = request.GET.get('data_center_type', None)
    data_center_equip_type_id = AssumpDataCenterType.objects.values_list(
            'data_center_equip_type', flat=True).filter(data_center_type=data_center_type)[0]

    data_center_circuit_ct = {}
    for year in AssumpDataCenterCircuitEoy.objects.filter(
        data_center_type=data_center_type):
        yr = year.yr
        circuit_ct = year.circuit_ct
        data_center_circuit_ct[yr] = circuit_ct

    assumps = []
    assumps.append(model_to_dict(AssumpDataCenterType.objects.filter(
            data_center_type=data_center_type)[0]))
    assumps.append(model_to_dict(AssumpDataCenterEquipType.objects.filter(
            data_center_equip_type_id=data_center_equip_type_id)[0]))
    assumps.append(data_center_circuit_ct)
    return JsonResponse(assumps, safe=False)

def assumps_data_center_equip(request):
    data_center_equip_type_id = request.GET.get('data_center_equip_type', None)
    assumps = model_to_dict(AssumpDataCenterEquipType.objects.filter(
            data_center_equip_type_id=data_center_equip_type_id)[0])
    return JsonResponse(assumps, safe=False)

def delete_data_center(request):
    datacenter_id = request.GET.get('datacenter_id', None)
    datacenter_name = request.GET.get('datacenter_name', None)
    deletedby = request.user.username
    deletedon = timezone.localtime(timezone.now())
    AppDatacenter.objects.filter(datacenter_id=datacenter_id).update(
            deleted='1', deletedon=deletedon, deletedby=deletedby)
    deleted = {'datacenter_name': datacenter_name}
    return JsonResponse(deleted, safe=False)

def delete_file(request):
    file_id = request.GET.get('file_id', None)
    file_name = request.GET.get('file_name', None)
    deletedby = request.user.username
    deletedon = timezone.localtime(timezone.now())
    AppFile.objects.filter(file_id=file_id).update(
            deleted='1', deletedon=deletedon, deletedby=deletedby)
    deleted = {'file_name': file_name}
    return JsonResponse(deleted, safe=False)

def calcs_calculator(request):
    smb_ent_inputs = calculator.prep_smb_ent_inputs(request)
    consol_curves = calculator.build_consol_curves(request)
    NPV, NPV_Less_HE_Trnsprt, IRR, IRR_Less_HE_Trnsprt = calculator.calc_NPV_IRR(consol_curves)
    CAR = calculator.calc_CAR(request)
    payback_mo = calculator.calc_payback_mo(consol_curves)
    ROE_Gate = calculator.calc_roe_gate(request)

    calcs = {}
    if Total_CAR == 0 and Total_CAR < 200000:
        calcs['fund_bucket'] = 'Region'
    elif Total_CAR >= 200000:
        if ROW_CAR >= 1000000 and Resi_Pct > 0:
            calcs['fund_bucket'] = 'CHQ MU'
        elif ROW_CAR < 1000000 and Resi_Pct >= 0.75:
            calcs['fund_bucket'] = 'Region Resi'
        else:
            calcs['fund_bucket'] = 'Division'
    else:
        calcs['fund_bucket'] = 'Division'
    calcs['lat_construct_upfront_pct'] = round(smb_ent_inputs['lat_construct_upfront_pct'], 3)
    calcs['exp_lat_construct_upfront_pct'] = round(smb_ent_inputs['exp_lat_construct_upfront_pct'], 3)
    calcs['smb_qb_ct'] = smb_ent_inputs['smb_qb_ct']
    calcs['ent_qb_ct'] = smb_ent_inputs['ent_qb_ct']
    calcs['building_ct'] = smb_ent_inputs['building_ct']
    calcs['multi_tenant_building_ct'] = smb_ent_inputs['multi_tenant_building_ct']
    calcs['dealinhand_ct'] = smb_ent_inputs['dealinhand_ct']
    calcs['mdu_ct'] = smb_ent_inputs['mdu_ct']
    calcs['passing_cost_per'] = round(smb_ent_inputs['passing_cost_per'], 2)
    calcs['lat_cost_per_connect'] = round(smb_ent_inputs['lat_cost_per_connect'], 2)
    calcs['NPV'] = round(NPV, 2)
    calcs['NPV_Less_HE_Trnsprt'] = round(NPV_Less_HE_Trnsprt, 2)
    calcs['IRR'] = round(IRR, 3)
    calcs['IRR_Less_HE_Trnsprt'] = round(IRR_Less_HE_Trnsprt, 3)
    calcs['CAR'] = round(CAR, 2)
    calcs['payback_mo'] = payback_mo
    calcs['roe_gate'] = ROE_Gate

    return JsonResponse(calcs, safe=False)

def calcs_child_business_case(request):
    smb_ent_inputs = calculations.prep_child_smb_ent_inputs(request)
    consol_curves = calculations.build_child_consol_curves(request)
    (NPV, NPV_Less_HE_Trnsprt,
    IRR, IRR_Less_HE_Trnsprt) = calculations.calc_child_NPV_IRR(consol_curves)
    ROW_CAR, Lat_CAR, Total_CAR = calculations.calc_child_CAR(request)
    payback_mo = calculations.calc_child_payback_mo(consol_curves)
    roe_target, roe_acquired, roe_needed = calculations.calc_child_roe_gate(request)
    (Business_NPV, Resi_NPV,
    Business_Pct, Resi_Pct) = calculations.calc_child_business_resi_capital_pct(request)

    calcs = {}
    if Total_CAR == 0 and Total_CAR < 200000:
        calcs['fund_bucket'] = 'Region'
    elif Total_CAR >= 200000:
        if ROW_CAR >= 1000000 and Resi_Pct > 0:
            calcs['fund_bucket'] = 'CHQ MU'
        elif ROW_CAR < 1000000 and Resi_Pct >= 0.75:
            calcs['fund_bucket'] = 'Region Resi'
        else:
            calcs['fund_bucket'] = 'Division'
    else:
        calcs['fund_bucket'] = 'Division'
    calcs['lat_construct_upfront_pct'] = round(smb_ent_inputs['lat_construct_upfront_pct'], 3)
    calcs['exp_lat_construct_upfront_pct'] = round(smb_ent_inputs['exp_lat_construct_upfront_pct'], 3)
    calcs['smb_qb_ct'] = smb_ent_inputs['smb_qb_ct']
    calcs['ent_qb_ct'] = smb_ent_inputs['ent_qb_ct']
    calcs['building_ct'] = smb_ent_inputs['building_ct']
    calcs['multi_tenant_building_ct'] = smb_ent_inputs['multi_tenant_building_ct']
    calcs['dealinhand_ct'] = smb_ent_inputs['dealinhand_ct']
    calcs['mdu_ct'] = smb_ent_inputs['mdu_ct']
    calcs['datacenter_ct'] = smb_ent_inputs['datacenter_ct']
    calcs['business_pct'] = round(Business_Pct, 3)
    calcs['resi_pct'] = round(Resi_Pct, 3)
    calcs['business_NPV'] = round(Business_NPV, 2)
    calcs['resi_NPV'] = round(Resi_NPV, 2)
    calcs['NPV'] = round(NPV, 2)
    calcs['NPV_Less_HE_Trnsprt'] = round(NPV_Less_HE_Trnsprt, 2)
    calcs['IRR'] = round(IRR, 3)
    calcs['IRR_Less_HE_Trnsprt'] = round(IRR_Less_HE_Trnsprt, 3)
    calcs['ROW_CAR'] = round(ROW_CAR, 2)
    calcs['Lat_CAR'] = round(Lat_CAR, 2)
    calcs['Total_CAR'] = round(Total_CAR, 2)
    calcs['payback_mo'] = payback_mo
    calcs['roe_target'] = roe_target
    calcs['roe_acquired'] = roe_acquired
    calcs['roe_needed'] = roe_needed
    calcs['passing_cost_per'] = round(smb_ent_inputs['passing_cost_per'], 2)
    calcs['lat_cost_per_connect'] = round(smb_ent_inputs['lat_cost_per_connect'], 2)

    return JsonResponse(calcs, safe=False)

def calcs_parent_business_case(request):
    if request.method == 'GET':
        probuild_id = request.GET.get('probuild_id', None)
    elif request.method == 'POST':
        probuild_id = request.POST.get('probuild_id', None)

    smb_ent_inputs = calculations.prep_parent_smb_ent_consol_inputs(probuild_id)
    consol_curves = calculations.build_parent_consol_curves(request)
    (NPV, NPV_Less_HE_Trnsprt,
    IRR, IRR_Less_HE_Trnsprt) = calculations.calc_parent_NPV_IRR(consol_curves)
    ROW_CAR, Lat_CAR, Total_CAR = calculations.calc_parent_CAR(probuild_id)
    payback_mo = calculations.calc_parent_payback_mo(consol_curves)
    roe_target, roe_acquired, roe_needed = calculations.calc_parent_roe_gate(probuild_id)
    (Business_NPV,
    Resi_NPV,
    Business_Pct,
    Resi_Pct) = calculations.calc_parent_business_resi_capital_pct(probuild_id)

    calcs = {}
    if Total_CAR == 0 and Total_CAR < 200000:
        calcs['fund_bucket'] = 'Region'
    elif Total_CAR >= 200000:
        if ROW_CAR >= 1000000 and Resi_Pct > 0:
            calcs['fund_bucket'] = 'CHQ MU'
        elif ROW_CAR < 1000000 and Resi_Pct >= 0.75:
            calcs['fund_bucket'] = 'Region Resi'
        else:
            calcs['fund_bucket'] = 'Division'
    else:
        calcs['fund_bucket'] = 'Division'
    calcs['customer_contribution'] = round(smb_ent_inputs['customer_contribution'], 2)
    calcs['access_fees_one_time'] = round(smb_ent_inputs['access_fees_one_time'], 2)
    calcs['access_fees_monthly'] = round(smb_ent_inputs['access_fees_monthly'], 2)
    calcs['row_est_build_cost'] = round(smb_ent_inputs['row_est_build_cost'], 2)
    calcs['headend_cost'] = round(smb_ent_inputs['headend_cost'], 2)
    calcs['transport_cost'] = round(smb_ent_inputs['transport_cost'], 2)
    calcs['private_property_cost'] = round(smb_ent_inputs['private_property_cost'], 2)
    calcs['lat_construct_upfront_pct'] = round(smb_ent_inputs['lat_construct_upfront_pct'], 3)
    calcs['smb_arpu'] = round(smb_ent_inputs['smb_arpu'], 2)
    calcs['ent_arpu'] = round(smb_ent_inputs['ent_arpu'], 2)
    calcs['smb_12mo_pen'] = round(smb_ent_inputs['smb_12mo_pen'], 3)
    calcs['smb_36mo_pen'] = round(smb_ent_inputs['smb_36mo_pen'], 3)
    calcs['ent_12mo_pen'] = round(smb_ent_inputs['ent_12mo_pen'], 3)
    calcs['ent_36mo_pen'] = round(smb_ent_inputs['ent_36mo_pen'], 3)
    calcs['smb_qb_ct'] = smb_ent_inputs['smb_qb_ct']
    calcs['ent_qb_ct'] = smb_ent_inputs['ent_qb_ct']
    calcs['building_ct'] = smb_ent_inputs['building_ct']
    calcs['multi_tenant_building_ct'] = smb_ent_inputs['multi_tenant_building_ct']
    calcs['dealinhand_ct'] = smb_ent_inputs['dealinhand_ct']
    calcs['mdu_ct'] = smb_ent_inputs['mdu_ct']
    calcs['datacenter_ct'] = smb_ent_inputs['datacenter_ct']
    calcs['business_pct'] = round(Business_Pct, 3)
    calcs['resi_pct'] = round(Resi_Pct, 3)
    calcs['business_NPV'] = round(Business_NPV, 2)
    calcs['resi_NPV'] = round(Resi_NPV, 2)
    calcs['NPV'] = round(NPV, 2)
    calcs['NPV_Less_HE_Trnsprt'] = round(NPV_Less_HE_Trnsprt, 2)
    calcs['IRR'] = round(IRR, 3)
    calcs['IRR_Less_HE_Trnsprt'] = round(IRR_Less_HE_Trnsprt, 3)
    calcs['ROW_CAR'] = round(ROW_CAR, 2)
    calcs['Lat_CAR'] = round(Lat_CAR, 2)
    calcs['Total_CAR'] = round(Total_CAR, 2)
    calcs['payback_mo'] = payback_mo
    calcs['roe_target'] = roe_target
    calcs['roe_acquired'] = roe_acquired
    calcs['roe_needed'] = roe_needed
    calcs['passing_cost_per'] = round(smb_ent_inputs['passing_cost_per'], 2)
    calcs['lat_cost_per_connect'] = round(smb_ent_inputs['lat_cost_per_connect'], 2)

    return JsonResponse(calcs, safe=False)
