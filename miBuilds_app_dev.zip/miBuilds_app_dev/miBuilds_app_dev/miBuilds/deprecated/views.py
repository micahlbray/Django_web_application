from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.views import generic
from django.views.generic.base import View
from django.contrib import messages
from django.http import JsonResponse
from django.forms.models import model_to_dict
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.db import connection, reset_queries
from django.db.models import Sum, Max, Value
from django_tables2 import RequestConfig
from django import forms
from miBuilds.models import (AppProbuild,
                            AppProbuildNote,
                            RptProbuild,
                            AppBuilding,
                            AppBusiness,
                            AppSfDealinhand,
                            AppMdu,
                            AppDatacenter,
                            AppDatacenterCircuitEoy,
                            AppFile,
                            AppUserProfile,
                            AssumpRegion,
                            AssumpMduBuildRegion,
                            AssumpMduBuild,
                            AssumpSegment,
                            AssumpDataCenterType,
                            AssumpDataCenterEquipType,
                            AssumpDataCenterCircuitEoy,
                            LkState,
                            LkDataCenterEquipType,
                            LkSegmentType,
                            LkBuildingType,
                            LkDwellingType,
                            )
from miBuilds.forms import (RptCalculatorForm,
                            BusinessCaseAddForm,
                            BusinessCaseRptForm,
                            BusinessCaseAddSuccessForm,
                            BusinessCaseSelectForm,
                            BusinessCaseEditForm,
                            BusinessCaseNoteAddForm,
                            BuildingAddForm,
                            BuildingUploadForm,
                            BuildingEditForm,
                            BusinessAddForm,
                            BusinessUploadForm,
                            BusinessEditForm,
                            DealInHandAddForm,
                            DealInHandEditForm,
                            MduAddForm,
                            MduEditForm,
                            DataCenterAddForm,
                            DataCenterEditForm,
                            DataCenterCircuitEoyForm,
                            FileUploadForm,
                            FileEditForm,
                            UploadTestForm,
                            ImageTestForm,
                            )
from miBuilds.tables import (BusinessCaseSearchTable,
                             BusinessCaseAddedTable,
                             BusinessCaseSubmittedTable,
                             BusinessCaseApprovedTable,
                             BusinessCaseNoteTable,
                             BuildingTable,
                             BusinessTable,
                             MduTable,
                             DataCenterTable,
                             DealInHandTable,
                             FileTable,
                             )
from miBuilds import ajax, calculations, emails, cashflow, buttons
from miBuilds.utils import( ifnull,
                            strDollarToDecimal,
                            strPercentToDecimal,
                            cashflowTableHTMLstyle,
                            )
from miBuilds.decorators import (user_is_authorized)
from miBuilds.filters import (BusinessCaseFilter)
from datetime import datetime
import pandas as pd
import sqlalchemy, csv, codecs, urllib
from io import TextIOWrapper
from decimal import Decimal

from easy_pdf.rendering import render_to_pdf_response, render_to_pdf

from django.template.loader import get_template
from django.template import RequestContext
from django.http import HttpResponse

from weasyprint import HTML, CSS

from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse
from django.template.loader import render_to_string

def html_to_pdf_view(request, probuild_id):
    form = get_object_or_404(AppProbuild, probuild_id=probuild_id)
    html = render_to_string('business_case_edit_pdf.html',
                            {'form': form})

    pdf = HTML(string=html).write_pdf(stylesheets=[CSS(
            settings.STATIC_ROOT + 'css\style.css')])

    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="test.pdf"'

    return response

def generate_pdf(request):
    """Generate pdf."""
    form = get_object_or_404(AppProbuild, probuild_id=probuild_id)
    html = render_to_string('business_case_edit_pdf.html',
                            {'form': form})
    html_string = render_to_string('bedjango/pdf.html', {'people': people})
    result = HTML(string=html_string).write_pdf(stylesheets=[CSS(
            settings.STATIC_ROOT + '\miBuilds\static\css\style.css')])

    # Creating http response
    response = HttpResponse(content_type='application/pdf;')
    response['Content-Disposition'] = 'inline; filename=list_people.pdf'
    response['Content-Transfer-Encoding'] = 'binary'
    with tempfile.NamedTemporaryFile(delete=True) as output:
        output.write(result)
        output.flush()
        output = open(output.name, 'r')
        response.write(output.read())

    return response

def detail_to_pdf(request, probuild_id):
    template = 'business_case_edit_pdf.html'
    form = AppProbuild.objects.get(probuild_id=probuild_id)
    context = {'form' : form}
    download_filename = 'test'
    return render_to_pdf_response(request, template, context)
    #return render_to_pdf(template, context)

################################################################################
### Home and Reporting forms ###
################################################################################
def index(request):
    #user_id = request.user.id
    #user_region_id = AppUserProfile.objects.values_list('region',
        #flat=True).filter(auth_user_id=user_id)[0]
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')

@login_required
def reporting_home(request):
    return render(request, 'reporting.html')

################################################################################
### Reset password forms ###
################################################################################
def pw_change(request,template_name='registration/password_change_form.html'):
    hyperbuild_req = HyperBuildReq.objects.get(user=request.user)
    extra_context = {'hyperbuild_req':hyperbuild_req}
    return password_change(request,
                           template_name=template_name,
                           extra_context=extra_context)

def pw_change_done(request,
                   template_name='registration/password_change_done.html'):
    hyperbuild_req = HyperBuildReq.objects.get(user=request.user)
    extra_context = {'hyperbuild_req':hyperbuild_req}
    return password_change_done(request,
                           template_name=template_name,
                           extra_context=extra_context)


def imagetest(request, probuild_id):
    if request.method == 'POST':
        print(request.POST)
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            file = form.save(commit=False)
            file.path = request.FILES['path']
            file.root = str(settings.MEDIA_ROOT)
            file.addedby = request.user.username
            file.addedon = timezone.localtime(timezone.now())
            file.save()
            return redirect('imagetest', probuild_id=probuild_id)
        else:
            return render(request, 'imagetest2.html', {'form': form, 'probuild_id': probuild_id})
    else:
        form = ImageTestForm(initial={'probuild': probuild_id})
        return render(request, 'imagetest2.html', {'form': form, 'probuild_id': probuild_id})

def imagetestaccept(request):
    print(request.GET)
    if request.method == 'POST':
        print("test")
        return 'ok' # to send the status_code 200
    else:
        return render(request, 'imagetest.html')


################################################################################
### miBuilds other forms ###
################################################################################
def calculator(request):
    user_id = request.user.id
    user_region_id = AppUserProfile.objects.values_list('region',
        flat=True).filter(auth_user_id=user_id)[0]
    form = RptCalculatorForm(initial={'region': user_region_id})
    return render(request, 'calculator.html', {'form': form})
################################################################################
### miBuilds main Business Case forms ###
################################################################################
@login_required
def business_case_add(request):
    user_id = request.user.id
    user_region_id = AppUserProfile.objects.values_list('region',
        flat=True).filter(auth_user_id=user_id)[0]

    if request.method == 'POST':
        ### Alter the string fields from the form to numerical values ####
        post = request.POST.copy()
        list_fields_strDollars = ['customer_contribution',
            'access_fees_one_time','access_fees_monthly',
            'row_est_build_cost', 'headend_cost', 'transport_cost',
            'private_property_cost', 'smb_arpu', 'ent_arpu',
            'business_max_actual_capital', 'resi_max_actual_capital',
            'car_value', 'npv',
            'npv_less_he_trnsprt', 'passing_cost_per',
            'additional_osp_lateral_cost_per_connect']
        for field in list_fields_strDollars:
            dollars = strDollarToDecimal(request.POST.get(field))
            post[field] = dollars
        list_fields_strPercent = ['smb_12mo_pen','smb_36mo_pen',
            'ent_12mo_pen', 'ent_36mo_pen', 'lateral_construct_upfront_pct',
            'business_capital_pct', 'resi_capital_pct',
            'irr_pct', 'irr_pct_less_he_trnsprt']
        for field in list_fields_strPercent:
            percent = strPercentToDecimal(request.POST.get(field))
            post[field] = percent
        request.POST = post

        form = BusinessCaseEditForm(request.POST)
        rpt = BusinessCaseRptForm(request.POST)
        if form.is_valid():
            case = form.save(commit=False)
            case.region_assump = AssumpRegion.objects.get(
                region = request.POST.get('region'), isactive = 1)
            case.mdu_build_region_assump = AssumpMduBuildRegion.objects.get(
                region = request.POST.get('region'), isactive = 1)
            case.added = 1
            case.addedby = request.user.username
            case.addedon = timezone.localtime(timezone.now())
            case.save()
            messages.success(request, 'You succesfully added ' + case.name.title() + ' as a Business Case')
            return redirect('business_case_add_success', probuild_id=case.probuild_id)
        else:
            return render(request, 'business_case_add.html', {'form': form, 'rpt': rpt})
    else:
        form = BusinessCaseAddForm(initial={'region': user_region_id})
        rpt = BusinessCaseRptForm()
        return render(request, 'business_case_add.html', {
            'form': form, 'rpt': rpt})

@login_required
def business_case_add_success(request, probuild_id):
    form = BusinessCaseAddSuccessForm(initial={'probuild_id': probuild_id})
    return render(request, 'business_case_add_success.html', {'form': form,
                    'probuild_id': probuild_id})

@login_required
def business_case_search(request):
    case_list = AppProbuild.objects.exclude(
            deleted=1).all()
    case_filter = BusinessCaseFilter(request.GET, queryset=case_list)
    case_table = BusinessCaseSearchTable(case_filter.qs)
    RequestConfig(request, paginate={'per_page': 10}).configure(case_table)
    return render(request, 'business_case_search.html',
        {'case_filter': case_filter, 'case_table': case_table})

@login_required
def business_case_select(request):
    #### Limit view based on user ####
    user_id = request.user.id
    user_region_id = AppUserProfile.objects.values_list('region',
        flat=True).filter(auth_user_id=user_id)[0]

    #### Handle search requests from this page ####
    if request.method == 'GET' and 'btnSearchBizCase' in request.GET:
        case_list = AppProbuild.objects.exclude(
                deleted=1).all()
        case_filter = BusinessCaseFilter(request.GET, queryset=case_list)
        case_table = BusinessCaseSearchTable(case_filter.qs)
        RequestConfig(request, paginate={'per_page': 10}).configure(case_table)
        return render(request, 'business_case_search.html', {
            'case_filter': case_filter, 'case_table': case_table})

    ##### Base form variables to pass to HTML ####
    form = BusinessCaseSelectForm()
    case_list = AppProbuild.objects.all()
    case_filter = BusinessCaseFilter(request.GET, queryset=case_list)

    if user_region_id == 7:
        addedset = BusinessCaseAddedTable(AppProbuild.objects.exclude(
                deleted=1).exclude(submitted=1).exclude(approved=1).filter(added=1))
        submittedset = BusinessCaseSubmittedTable(AppProbuild.objects.exclude(
                deleted=1).exclude(approved=1).filter(submitted=1))
        approvedset = BusinessCaseApprovedTable(AppProbuild.objects.exclude(
                deleted=1).filter(approved=1))
    else:
        addedset = BusinessCaseAddedTable(AppProbuild.objects.exclude(
                deleted=1).exclude(submitted=1).exclude(approved=1).filter(
                added=1, region=user_region_id))
        submittedset = BusinessCaseSubmittedTable(AppProbuild.objects.exclude(
                deleted=1).exclude(approved=1).filter(submitted=1,
                region=user_region_id))
        approvedset = BusinessCaseApprovedTable(AppProbuild.objects.exclude(
                deleted=1).filter(approved=1, region=user_region_id))

    RequestConfig(request, paginate={'per_page': 10}).configure(addedset)
    RequestConfig(request, paginate={'per_page': 10}).configure(submittedset)
    RequestConfig(request, paginate={'per_page': 10}).configure(approvedset)

    return render(request, 'business_case_select.html', {'form': form,
        'addedset': addedset, 'submittedset': submittedset,
        'approvedset': approvedset, 'case_filter': case_filter})

@login_required
def business_case_select_failure(request):
    return render(request, 'business_case_select_failure.html')

@login_required
#@user_is_authorized
def business_case_edit(request, probuild_id):
    user_name = request.user.username
    request_time = datetime.now().isoformat(timespec='seconds')
    if request.method == 'POST':
        ### Alter the string fields from the form to numerical values ####
        post = request.POST.copy()
        list_fields_strDollars = ['customer_contribution',
            'access_fees_one_time','access_fees_monthly',
            'row_est_build_cost', 'headend_cost', 'transport_cost',
            'private_property_cost', 'smb_arpu', 'ent_arpu',
            'business_max_actual_capital', 'resi_max_actual_capital',
            'car_value', 'npv',
            'npv_less_he_trnsprt', 'passing_cost_per',
            'additional_osp_lateral_cost_per_connect']
        for field in list_fields_strDollars:
            dollars = strDollarToDecimal(request.POST.get(field))
            post[field] = dollars
        list_fields_strPercent = ['smb_12mo_pen','smb_36mo_pen',
            'ent_12mo_pen', 'ent_36mo_pen', 'lateral_construct_upfront_pct',
            'business_capital_pct', 'resi_capital_pct',
            'irr_pct', 'irr_pct_less_he_trnsprt']
        for field in list_fields_strPercent:
            percent = strPercentToDecimal(request.POST.get(field))
            post[field] = percent
        request.POST = post

        form = BusinessCaseEditForm(request.POST,
                        instance=AppProbuild.objects.get(probuild_id=probuild_id))
        rpt = BusinessCaseRptForm(request.POST)

        #######################################################################
        ### Handle if the Save Button was clicked
        #######################################################################
        if 'btnSaveBizCase' in request.POST:
            if not form.is_valid():
                print('\nFAIL Form')
            if not rpt.is_valid():
                print('\nFAIL Report')
                #print(rpt.errors)
            if form.is_valid() and rpt.is_valid():
                case = form.save(commit=False)
                case.edited = 1
                case.editedby = request.user.username
                case.editedon = timezone.localtime(timezone.now())
                case.save()
                rpt_case = rpt.save(commit=False)
                rpt_case.probuild = probuild_id
                rpt_case.saved = 1
                rpt_case.addedby = request.user.username
                rpt_case.addedon = timezone.localtime(timezone.now())
                rpt_case.save()
                return redirect('business_case_edit', probuild_id=probuild_id)
            else:
                return render(request, 'business_case_edit.html',
                    {'form': form, 'rpt': rpt, 'probuild_id': probuild_id})
        #######################################################################
        ### Handle if the Clone Button was clicked
        #######################################################################
        elif 'btnCloneBizCase' in request.POST:
            if form.is_valid() and rpt.is_valid():
                case = form.save(commit=False)
                case.edited = 1
                case.editedby = request.user.username
                case.editedon = timezone.localtime(timezone.now())
                case.save()
                rpt_case = rpt.save(commit=False)
                rpt_case.probuild = probuild_id
                rpt_case.saved = 1
                rpt_case.addedby = request.user.username
                rpt_case.addedon = timezone.localtime(timezone.now())
                rpt_case.save()

                sql = ('''  EXEC BI_MIP.miBuilds.buttons_business_case_clone
                                        @probuild_id = '{}'
                                        ,@clonedby = '{}'

                        ''').format(probuild_id, user_name)
                df = pd.read_sql(sql, connection)
                cloned_name = df['Cloned_Name'].values[0]
                cloned_probuild_id = AppProbuild.objects.values_list('probuild_id',
                    flat=True).filter(name=cloned_name)[0]
                return redirect('business_case_edit', probuild_id=cloned_probuild_id)
            else:
                return render(request, 'business_case_edit.html',
                    {'form': form, 'rpt': rpt, 'probuild_id': probuild_id})
        #######################################################################
        ### Handle if the Check Button was clicked
        #######################################################################
        elif 'btnCheckBizCase' in request.POST:
            sql = (''' EXEC BI_MIP.miBuilds.buttons_business_case_check_available_df
                                    @probuild_id = '{}'
                            ''').format(probuild_id)
            df = pd.read_sql(sql, connection)
            df = df.fillna(0)

            ### If there are business in another build ###
            ### , redirect to page showing the matching values ###
            if len(df.index) > 0:
                failed_items = df.to_html(index=False)
                failed_message = ('These items are tied to a different build.')
                request.session['failed_message'] = failed_message
                request.session['failed_items'] = failed_items
                return redirect('business_case_check_failure',
                                probuild_id=probuild_id)
            else:
                failed_message = ''
                request.session['failed_message'] = ''
                request.session['failed_items'] = ''
                return render(request, 'check_available_success.html',
                            {'probuild_id': probuild_id,})
        #######################################################################
        ### Handle if the Status Button was clicked
        #######################################################################
        elif 'btnStatusBizCase' in request.POST:
            if form.is_valid() and rpt.is_valid():
                case = form.save(commit=False)
                case.edited = 1
                case.editedby = request.user.username
                case.editedon = timezone.localtime(timezone.now())
                rpt_case = rpt.save(commit=False)
                rpt_case.probuild = probuild_id
                rpt_case.saved = 1
                rpt_case.addedby = request.user.username
                rpt_case.addedon = timezone.localtime(timezone.now())
                rpt_case.save()
                if request.POST.get('btnStatusBizCase') == 'Move To Pending':
                    case.submitted = None
                    case.submittedon = None
                    case.submittedby = None
                    case.save()
                    sql = (''' EXEC BI_MIP.miBuilds.rpt_probuild_status_log_insert
                                        	@proBuild_id = '{}'
                                        	,@addedon = '{}'
                                            ,@addedby = '{}'
                                            ,@status = '{}'
                                    ''').format(probuild_id, request_time,
                                    user_name, 'Pending')
                    connection.cursor().execute(sql)
                elif request.POST.get('btnStatusBizCase') == 'Move To Submitted':
                    case.approved = None
                    case.approvedon = None
                    case.approvedby = None
                    case.save()
                    sql = (''' EXEC BI_MIP.miBuilds.rpt_probuild_status_log_insert
                                        	@proBuild_id = '{}'
                                        	,@addedon = '{}'
                                            ,@addedby = '{}'
                                            ,@status = '{}'
                                    ''').format(probuild_id, request_time,
                                    user_name, 'Submitted')
                    connection.cursor().execute(sql)
                else:
                    case.save()
                return redirect('business_case_edit', probuild_id=probuild_id)
            else:
                return render(request, 'business_case_edit.html',
                    {'form': form, 'rpt': rpt, 'probuild_id': probuild_id})
        #######################################################################
        ### Handle if the Submit Button was clicked
        #######################################################################
        elif 'btnSubBizCase' in request.POST:
            required = 'btnSubBizCase' in request.POST
            form.fields['name'].required = required
            form.fields['region'].required = required
            form.fields['jt_id'].required = required
            form.fields['est_compl_dt'].required = required
            form.fields['roe_gate_dt'].required = required
            form.fields['permitting_gate_dt'].required = required
            if form.is_valid():
                case = form.save(commit=False)
                case.edited = 1
                case.editedby = request.user.username
                case.editedon = timezone.localtime(timezone.now())
                case.submitted = 1
                case.submittedby = request.user.username
                case.submittedon = timezone.localtime(timezone.now())
                case.save()
                rpt_case = rpt.save(commit=False)
                rpt_case.probuild = probuild_id
                rpt_case.submitted = 1
                rpt_case.addedby = request.user.username
                rpt_case.addedon = timezone.localtime(timezone.now())
                rpt_case.save()
                ### Update status log ###
                sql = (''' EXEC BI_MIP.miBuilds.rpt_probuild_status_log_insert
                                        @proBuild_id = '{}'
                                        ,@addedon = '{}'
                                        ,@addedby = '{}'
                                        ,@status = '{}'
                                ''').format(probuild_id, request_time,
                                user_name, 'Submitted')
                connection.cursor().execute(sql)
                ### Send email to appropriate parties ###
                emails.send_submit_email(request)
                ### Redirect to the success screen before moving on ###
                messages.success(request, 'You succesfully submitted ' + case.name.title() + ' for Approval')
                return redirect('business_case_add_success', probuild_id=case.probuild_id)
            else:
                return render(request, 'business_case_edit.html', {'form': form,
                            'rpt': rpt, 'probuild_id': probuild_id})
        #######################################################################
        ### Handle if the Approve Button was clicked
        #######################################################################
        elif 'btnApprvBizCase' in request.POST:
            sql = (''' EXEC BI_MIP.miBuilds.buttons_business_case_check_available_df
                                    @probuild_id = '{}'
                            ''').format(probuild_id)
            df = pd.read_sql(sql, connection)
            df = df.fillna(0)
            ### If there are business in another build ###
            ### , redirect to page showing the matching values ###
            if len(df.index) > 0:
                failed_items = df.to_html(index=False)
                failed_message = ('These items are tied to a different build.')
                request.session['failed_message'] = failed_message
                request.session['failed_items'] = failed_items
                return redirect('business_case_check_failure',
                                probuild_id=probuild_id)
            else:
                required = 'btnApprvBizCase' in request.POST
                form.fields['name'].required = required
                form.fields['region'].required = required
                form.fields['jt_id'].required = required
                form.fields['est_compl_dt'].required = required
                form.fields['roe_gate_dt'].required = required
                form.fields['permitting_gate_dt'].required = required
                if form.is_valid():
                    case = form.save(commit=False)
                    case.edited = 1
                    case.editedby = request.user.username
                    case.editedon = timezone.localtime(timezone.now())
                    case.approved = 1
                    case.approvedby = request.user.username
                    case.approvedon = timezone.localtime(timezone.now())
                    case.save()
                    rpt_case = rpt.save(commit=False)
                    rpt_case.probuild = probuild_id
                    rpt_case.approved = 1
                    rpt_case.addedby = request.user.username
                    rpt_case.addedon = timezone.localtime(timezone.now())
                    rpt_case.save()
                    ### Update status log ###
                    sql = (''' EXEC BI_MIP.miBuilds.rpt_probuild_status_log_insert
                                            @proBuild_id = '{}'
                                            ,@addedon = '{}'
                                            ,@addedby = '{}'
                                            ,@status = '{}'
                                    ''').format(probuild_id, request_time,
                                    user_name, 'Approved')
                    ### Save Cash Flow information in rpt Table ###
                    calculations.build_smb_ent_df(request)
                    connection.cursor().execute(sql)
                    ### Send email to appropriate parties ###
                    emails.send_approval_email(request)
                    ### Redirect to the success screen before moving on ###
                    messages.success(request, 'You succesfully Approved '
                                    + case.name.title())
                    return redirect('business_case_add_success',
                                    probuild_id=case.probuild_id)
                else:
                    return render(request, 'business_case_edit.html', {'form': form,
                                'rpt': rpt, 'probuild_id': probuild_id})
    else:
        form = BusinessCaseEditForm(instance=
                AppProbuild.objects.get(probuild_id=probuild_id))
        if RptProbuild.objects.filter(probuild=probuild_id).exists():
            max_rpt_record = (RptProbuild.objects
                               .filter(probuild=probuild_id)
                               .aggregate(max=Max('record_id'))
                            )['max']
            rpt = BusinessCaseRptForm(instance=
                RptProbuild.objects.get(probuild=probuild_id,
                            record_id=max_rpt_record))
        else:
            rpt = BusinessCaseRptForm(initial={'probuild': probuild_id})
        return render(request, 'business_case_edit.html', {'form': form,
                    'rpt': rpt, 'probuild_id': probuild_id})

def business_case_check_failure(request, probuild_id):
    failed_message = request.session.get('failed_message', None)
    failed_items = request.session.get('failed_items', None)
    return render(request, 'check_available_failure.html', {'probuild_id': probuild_id,
                'failed_message': failed_message, 'failed_items': failed_items})

@login_required
def business_case_note_add(request, probuild_id):
    if request.method == 'POST':
        form = BusinessCaseNoteAddForm(request.POST)
        note_table = BusinessCaseNoteTable(AppProbuildNote.objects.exclude(
                deleted=1).filter(probuild=probuild_id))
        RequestConfig(request, paginate={'per_page': 20}).configure(note_table)
        if form.is_valid():
            case = form.save(commit=False)
            case.addedby = request.user.username
            case.addedon = timezone.localtime(timezone.now())
            case.save()
            return redirect('business_case_note_add',
                    probuild_id=case.probuild_id)
        else:
            return render(request, 'business_case_note_add.html',
                    {'form': form, 'note_table': note_table,
                        'probuild_id': probuild_id})
    else:
        form = BusinessCaseNoteAddForm(initial={'probuild': probuild_id})
        note_table = BusinessCaseNoteTable(AppProbuildNote.objects.exclude(
                deleted=1).filter(probuild=probuild_id))
        RequestConfig(request, paginate={'per_page': 20}).configure(note_table)
        return render(request, 'business_case_note_add.html',
                {'form': form, 'note_table': note_table,
                    'probuild_id': probuild_id})

@login_required
def business_case_review(request, probuild_id):
    print(request.GET)
    return render(request, 'business_case_review.html', {'probuild_id': probuild_id})

@login_required
def building_add(request, probuild_id):
    if request.method == 'POST':
        form = BuildingAddForm(request.POST)
        building_table = BuildingTable(AppBuilding.objects.exclude(
                deleted=1).filter(probuild=probuild_id))
        RequestConfig(request, paginate={'per_page': 50}).configure(building_table)
        ### Check the database to make sure the buildings in the file aren't tied to another build ###
        building = request.POST.get('building_id')
        ### If there are buildings in another build, redirect to page showing the matching values ###
        if building == 0:
            failed_message = '''Please leave blank if there is no Building ID.
                Please edit and try again.'''
            request.session['failed_message'] = failed_message
            request.session['failed_items'] = ''
            return redirect('building_add_failure', probuild_id)
        else:
            if form.is_valid():
                building = form.save(commit=False)
                building.addedby = request.user.username
                building.addedon = timezone.localtime(timezone.now())
                building.save()
                return redirect('building_add', probuild_id=probuild_id)
            else:
                return render(request, 'building_add.html', {'form': form,
                        'building_table': building_table, 'probuild_id': probuild_id})
    else:
        form = BuildingAddForm(initial={'probuild': probuild_id})
        building_table = BuildingTable(AppBuilding.objects.exclude(
                deleted=1).filter(probuild=probuild_id))
        RequestConfig(request, paginate={'per_page': 50}).configure(building_table)
        return render(request, 'building_add.html', {'form': form,
                        'building_table': building_table, 'probuild_id': probuild_id})

@login_required
def building_add_failure(request, probuild_id):
    failed_message = request.session.get('failed_message', None)
    failed_items = request.session.get('failed_items', None)
    return render(request, 'building_add_failure.html', {'probuild_id': probuild_id,
                'failed_message': failed_message, 'failed_items': failed_items})

@login_required
def greenfield_building_add_upload(request, probuild_id):
    if request.method == 'POST':
        form = BuildingUploadForm(request.POST, request.FILES)
        addedby = request.user.username
        addedon = datetime.now().isoformat(timespec='seconds')
        if form.is_valid():
            upload = form.save(commit=False)
            upload.path = request.FILES['path']
            upload.root = str(settings.MEDIA_ROOT)
            upload.addedby = addedby
            upload.addedon = timezone.localtime(timezone.now())
            upload.save()

            try:
                data = request.FILES['path'].get_dict(sheet_name='Buildings')
            except:
                request.session['successful_message'] = ''
                request.session['successful_items'] = ''
                request.session['upload_failed_message'] = ''
                request.session['upload_failed_items'] = ''
                request.session['failed_message'] = '''
                                Please double check the file has the proper tab
                                names and the headers are correct.
                                '''
                request.session['failed_items'] = ''
                return redirect('building_add_upload_failure', probuild_id)

            if len(data['State']) > 0:
                try:
                    upload_df = pd.DataFrame.from_dict(data, orient='columns')

                    state_list = LkState.objects.values('abbrev','state_id').filter(
                            isactive=1)
                    state_dict = {}
                    for i in range(len(state_list)):
                        abbrev = state_list[i]['abbrev']
                        id = state_list[i]['state_id']
                        state_dict[abbrev] = id
                    building_type_list = LkBuildingType.objects.values('name',
                            'building_type_id').filter(isactive=1)
                    building_type_dict = {}
                    for i in range(len(building_type_list)):
                        name = building_type_list[i]['name']
                        id = building_type_list[i]['building_type_id']
                        building_type_dict[name] = id
                    dwelling_type_list = LkDwellingType.objects.values('name',
                            'dwelling_type_id').filter(isactive=1)
                    dwelling_type_dict = {}
                    for i in range(len(dwelling_type_list)):
                        name = dwelling_type_list[i]['name']
                        id = dwelling_type_list[i]['dwelling_type_id']
                        dwelling_type_dict[name] = id

                    probuild_id_list = [probuild_id for i in range(upload_df['State'].count())]
                    addedby_list = [addedby for i in range(upload_df['State'].count())]
                    addedon_list = [addedon for i in range(upload_df['State'].count())]

                    upload_df['Probuild_Id'] = probuild_id_list
                    upload_df['AddedBy'] = addedby_list
                    upload_df['AddedOn'] = addedon_list
                    upload_df['State'] = upload_df['State'].map(state_dict)
                    upload_df['Building_Type'] = upload_df['Building_Type'].map(building_type_dict)
                    upload_df['Dwelling_Type'] = upload_df['Dwelling_Type'].map(dwelling_type_dict)
                    upload_df.rename(columns={
                            'State': 'State_Id',
                            'Zip_Code': 'Zip',
                            'Building_Type': 'Building_Type_Id',
                            'Dwelling_Type': 'Dwelling_Type_Id',
                            'ROE_Id': 'Building_ROE_Id'}, inplace=True)

                    engine = settings.DB_ENGINE
                    upload_df.to_sql(name='app_Building', con=engine,
                        schema='Dev', if_exists='append', index=False)

                    sql = (''' EXEC BI_MIP.miBuilds.views_greenfield_building_add_upload
                                            @probuild_id = '{}'
                                    ''').format(probuild_id)
                    connection.cursor().execute(sql)

                except:
                    request.session['successful_message'] = ''
                    request.session['successful_items'] = ''
                    request.session['upload_failed_message'] = ''
                    request.session['upload_failed_items'] = ''
                    request.session['failed_message'] = '''
                                    Please double check the file for errors.
                                    '''
                    request.session['failed_items'] = ''
                    return redirect('building_add_upload_failure', probuild_id)
                return redirect('building_add', probuild_id=probuild_id)
            else:
                request.session['successful_message'] = ''
                request.session['successful_items'] = ''
                request.session['upload_failed_message'] = ''
                request.session['upload_failed_items'] = ''
                request.session['failed_message'] = 'There were was no data in the file.'
                request.session['failed_items'] = ''
                return redirect('building_add_upload_failure', probuild_id)
            return redirect('building_add', probuild_id=probuild_id)
        else:
            return render(request, 'greenfield_building_add_upload.html',
                {'form': form, 'probuild_id': probuild_id})
    else:
        form = BuildingUploadForm(initial={'probuild': probuild_id,
                'upload_type':'2'})
        return render(request, 'greenfield_building_add_upload.html',
                {'form': form, 'probuild_id': probuild_id})

@login_required
def building_add_upload(request, probuild_id):
    if request.method == 'POST':
        form = BuildingUploadForm(request.POST, request.FILES)
        probuild_id = probuild_id
        addedby = request.user.username
        if form.is_valid():
            upload = form.save(commit=False)
            upload.path = request.FILES['path']
            upload.root = str(settings.MEDIA_ROOT)
            upload.addedby = request.user.username
            upload.addedon = timezone.localtime(timezone.now())
            upload.save()
            file_extension = upload.extension()
            print(file_extension)

            ### Read in the CSV file
            data = csv.DictReader(codecs.iterdecode(request.FILES['path'],'utf-8'))
            csv_headers = data.fieldnames
            poss_headers = ['building_id','BUILDING_ID','MIP_BUILDING_ID'
                            'Building_Id','MIP_Building_Id','mip_building_id']
            buildings_list = []
            for header in poss_headers:
                if header in csv_headers:
                    for row in data:
                        buildings_list.append(row[header])
            buildings_list = list(set(filter(None, buildings_list)))
            buildings = ",".join(buildings_list)
            ### If one of the possible headers isn't in file show error message. ###
            if len(buildings_list) == 0:
                failed_message = ('''The correct possible headers aren't in the file.
                            Please make sure the file contains one of the following:''')
                failed_items = (''' <ul>
                                        <li>building_id</li>
                                        <li>BUILDING_ID</li>
                                        <li>MIP_BUILDING_ID</li>
                                    </ul>''')
                request.session['successful_message'] = ''
                request.session['successful_items'] = ''
                request.session['upload_failed_message'] = ''
                request.session['upload_failed_items'] = ''
                request.session['failed_message'] = failed_message
                request.session['failed_items'] = failed_items
                return redirect('building_add_upload_failure', probuild_id)
            ### Match the buildings to the MIP table and write information to the Application table ###
            upload_sql = (''' EXEC BI_MIP.miBuilds.views_building_add_upload_df
                                @probuild_id = '{}',
                                @addedby = '{}',
                                @nax_building_id_list = '{}'
                        ''')
            upload_sql = upload_sql.format(probuild_id, addedby, buildings)
            upload_df = pd.read_sql(upload_sql, connection)
            ### Write to the buildings to the DB ###
            engine = settings.DB_ENGINE
            upload_df.to_sql(name='app_Building', con=engine,
                schema='Dev', if_exists='append', index=False)
            ### Succesfully uploaded buildings ###
            upload_list = list(set(
                                upload_df['building_id'].astype('int').tolist()
                                ))
            upload_list = [str(x) for x in upload_list]
            upload_fail_list = [x for x in buildings_list
                                if x not in upload_list]
            upload_pass_list = [x for x in upload_list
                                if x not in upload_fail_list]
            upload_fail = ", ".join(list(set(upload_fail_list)))
            upload_pass = ", ".join(list(set(upload_pass_list)))

            ### If there are buildings in another build, redirect to page showing the matching values ###
            if len(upload_fail) > 0:
                successful_message = '''These buildings were uploaded:'''
                successful_items = ifnull(upload_pass, 'No buildings were uploaded.') #pd.concat([upload_df['building_id']], axis=1, keys=['Building']).to_html(index=False)
                upload_failed_message = '''These buildings were not uploaded.
                    Please double check to ensure these are correct:'''
                upload_failed_items = ifnull(upload_fail, '')
                #failed_items = upload_df.to_html(index=False)
                #failed_message = '''These buildings are tied to a different build:'''
                request.session['successful_message'] = successful_message
                request.session['successful_items'] = successful_items
                request.session['upload_failed_message'] = upload_failed_message
                request.session['upload_failed_items'] = upload_failed_items
                request.session['failed_message'] = ''
                request.session['failed_items'] = ''
                return redirect('building_add_upload_failure', probuild_id)
            else:
                ### Redirect back to the Building Add page to see uploaded items ###
                return redirect('building_add', probuild_id=probuild_id)
        else:
            return render(request, 'building_add_upload.html', {'form': form,
                'probuild_id': probuild_id})

    else:
        form = BuildingUploadForm(initial={'probuild': probuild_id, 'upload_type':'1'})
        return render(request, 'building_add_upload.html', {'form': form, 'probuild_id': probuild_id})

@login_required
def building_add_upload_failure(request, probuild_id):
    successful_message = request.session.get('successful_message', None)
    successful_items = request.session.get('successful_items', None)
    upload_failed_message = request.session.get('upload_failed_message', None)
    upload_failed_items = request.session.get('upload_failed_items', None)
    failed_message = request.session.get('failed_message', None)
    failed_items = request.session.get('failed_items', None)
    return render(request, 'building_add_upload_failure.html', {
            'probuild_id': probuild_id, 'successful_message': successful_message,
            'successful_items': successful_items,
            'upload_failed_message': upload_failed_message,
            'upload_failed_items': upload_failed_items,
            'failed_message': failed_message, 'failed_items': failed_items})

@login_required
def building_edit(request, record_id):
    if request.method == 'POST':
        form = BuildingEditForm(request.POST, instance=AppBuilding.objects.get(record_id=record_id))
        probuild_id = AppBuilding.objects.values_list('probuild_id',
            flat=True).filter(record_id=record_id)[0]
        if form.is_valid():
            building = form.save(commit=False)
            building.editedby = request.user.username
            building.editedon = timezone.localtime(timezone.now())
            building.save()
            return redirect('building_edit', record_id=record_id)
        else:
            return render(request, 'building_edit.html', {'form': form,
                'probuild_id': probuild_id})
    else:
        form = BuildingEditForm(instance=AppBuilding.objects.get(record_id=record_id))
        probuild_id = AppBuilding.objects.values_list('probuild_id',
            flat=True).filter(record_id=record_id)[0]
        return render(request, 'building_edit.html', {'form': form,
            'probuild_id': probuild_id})

@login_required
def business_add(request, probuild_id):
    if request.method == 'POST':
        form = BusinessAddForm(request.POST)
        business_table = BusinessTable(AppBusiness.objects.exclude(
                deleted=1).filter(probuild=probuild_id))
        RequestConfig(request, paginate={'per_page': 50}).configure(business_table)
        ### Check the database to make sure the business in the file aren't tied to another build ###
        business = request.POST.get('business_id')

        if business == 0:
            failed_message = '''Please leave blank if there is no Business ID.
                    Please edit and try again.'''
            request.session['failed_message'] = failed_message
            request.session['failed_items'] = ''
            return redirect('business_add_failure', probuild_id)
            ### Check the web application tables ###
        else:
            if form.is_valid():
                business = form.save(commit=False)
                business.segment_assump = AssumpSegment.objects.get(
                        segment_type = request.POST.get('segment_type_id'),
                            isactive = 1)
                business.addedby = request.user.username
                business.addedon = timezone.localtime(timezone.now())
                business.save()
                ### Redirect back to the Business Add page to see uploaded items ###
                return redirect('business_add', probuild_id=probuild_id)
            else:
                return render(request, 'business_add.html', {'form': form,
                    'business_table': business_table,
                    'probuild_id': probuild_id})
    else:
        form = BusinessAddForm(initial={
                                    'probuild': probuild_id,
                                    'segment_assump': '1'})
        business_table = BusinessTable(AppBusiness.objects.exclude(
                deleted=1).filter(probuild=probuild_id))
        RequestConfig(request, paginate={'per_page': 50}).configure(business_table)
        return render(request, 'business_add.html', {'form': form,
                    'business_table': business_table, 'probuild_id': probuild_id})

@login_required
def business_add_failure(request, probuild_id):
    failed_message = request.session.get('failed_message', None)
    failed_items = request.session.get('failed_items', None)
    return render(request, 'business_add_failure.html', {'probuild_id': probuild_id,
                'failed_message': failed_message, 'failed_items': failed_items})

@login_required
def greenfield_business_add_upload(request, probuild_id):
    if request.method == 'POST':
        form = BusinessUploadForm(request.POST, request.FILES)
        addedby = request.user.username
        addedon = datetime.now().isoformat(timespec='seconds')
        if form.is_valid():
            upload = form.save(commit=False)
            upload.path = request.FILES['path']
            upload.root = str(settings.MEDIA_ROOT)
            upload.addedby = addedby
            upload.addedon = timezone.localtime(timezone.now())
            upload.save()

            try:
                data = request.FILES['path'].get_dict(sheet_name='Businesses')
            except:
                request.session['successful_message'] = ''
                request.session['successful_items'] = ''
                request.session['upload_failed_message'] = ''
                request.session['upload_failed_items'] = ''
                request.session['failed_message'] = '''
                                Please double check the file has the proper tab
                                names and the headers are correct.
                                '''
                request.session['failed_items'] = ''
                return redirect('business_add_upload_failure', probuild_id)

            if len(data['State']) > 0:
                try:
                    upload_df = pd.DataFrame.from_dict(data, orient='columns')

                    state_list = LkState.objects.values('abbrev','state_id').filter(
                            isactive=1)
                    state_dict = {}
                    for i in range(len(state_list)):
                        abbrev = state_list[i]['abbrev']
                        id = state_list[i]['state_id']
                        state_dict[abbrev] = id
                    segment_type_list = LkSegmentType.objects.values('name','segment_type_id').filter(
                            isactive=1)
                    segment_type_dict = {}
                    for i in range(len(segment_type_list)):
                        name = segment_type_list[i]['name']
                        id = segment_type_list[i]['segment_type_id']
                        segment_type_dict[name] = id

                    probuild_id_list = [probuild_id for i in range(upload_df['State'].count())]
                    addedby_list = [addedby for i in range(upload_df['State'].count())]
                    addedon_list = [addedon for i in range(upload_df['State'].count())]

                    upload_df['Probuild_Id'] = probuild_id_list
                    upload_df['AddedBy'] = addedby_list
                    upload_df['AddedOn'] = addedon_list
                    upload_df['State'] = upload_df['State'].map(state_dict)
                    upload_df['Segment_Type'] = upload_df['Segment_Type'].map(segment_type_dict)
                    upload_df.rename(columns={
                            'State': 'State_Id',
                            'Zip_Code': 'Zip',
                            'Segment_Type': 'Segment_Type_Id'}, inplace=True)

                    engine = settings.DB_ENGINE
                    upload_df.to_sql(name='app_Business', con=engine,
                        schema='Dev', if_exists='append', index=False)

                    sql = (''' EXEC BI_MIP.miBuilds.views_greenfield_business_add_upload
                                            @probuild_id = '{}'
                                    ''').format(probuild_id)
                    connection.cursor().execute(sql)

                except:
                    request.session['successful_message'] = ''
                    request.session['successful_items'] = ''
                    request.session['upload_failed_message'] = ''
                    request.session['upload_failed_items'] = ''
                    request.session['failed_message'] = '''
                                    Please double check the file for errors.
                                    '''
                    request.session['failed_items'] = ''
                    return redirect('business_add_upload_failure', probuild_id)
                return redirect('business_add', probuild_id=probuild_id)
            else:
                request.session['successful_message'] = ''
                request.session['successful_items'] = ''
                request.session['upload_failed_message'] = ''
                request.session['upload_failed_items'] = ''
                request.session['failed_message'] = 'There were was no data in the file.'
                request.session['failed_items'] = ''
                return redirect('business_add_upload_failure', probuild_id)
            return redirect('business_add', probuild_id=probuild_id)
        else:
            return render(request, 'greenfield_business_add_upload.html', {'form': form,
                'probuild_id': probuild_id})
    else:
        form = BuildingUploadForm(initial={'probuild': probuild_id, 'upload_type':'2'})
        return render(request, 'greenfield_business_add_upload.html', {'form': form, 'probuild_id': probuild_id})


@login_required
def business_add_upload(request, probuild_id):
    if request.method == 'POST':
        form = BusinessUploadForm(request.POST, request.FILES)
        probuild_id = probuild_id
        addedby = request.user.username
        ### Read in CSV and search for possible headers and append data ###
        if form.is_valid():
            upload = form.save(commit=False)
            upload.path = request.FILES['path']
            upload.root = str(settings.MEDIA_ROOT)
            upload.addedby = request.user.username
            upload.addedon = timezone.localtime(timezone.now())
            upload.save()

            data = csv.DictReader(codecs.iterdecode(request.FILES['path'],'utf-8'))
            csv_headers = data.fieldnames
            poss_headers = ['business_id','BUSINESS_ID','MIP_QB_ID']
            businesses_list = []
            for header in poss_headers:
                if header in csv_headers:
                    for row in data:
                        businesses_list.append(row[header])
            businesses_list = list(filter(None, businesses_list))
            businesses = ",".join(businesses_list)
            ### If one of the possible headers isn't in file show error message. ###
            if len(businesses_list) == 0:
                failed_message = ('''The correct possible headers aren't in the file.
                            Please make sure the file contains one of the following:''')
                failed_items = (''' <ul>
                                        <li>business_id</li>
                                        <li>BUSINESS_ID</li>
                                        <li>MIP_QB_ID</li>
                                    </ul>''')
                request.session['successful_message'] = ''
                request.session['successful_items'] = ''
                request.session['upload_failed_message'] = ''
                request.session['upload_failed_items'] = ''
                request.session['failed_message'] = failed_message
                request.session['failed_items'] = failed_items
                return redirect('business_add_upload_failure', probuild_id)

            ### Save the upload information and write to database ###
            ### Match the businesses to the MIP table and write information to the Application table ###
            upload_sql = (''' EXEC BI_MIP.miBuilds.views_business_add_upload_df
                                @probuild_id = '{}',
                                @addedby = '{}',
                                @business_id_list = '{}'
                        ''')
            upload_sql = upload_sql.format(probuild_id, addedby, businesses)
            upload_df = pd.read_sql(upload_sql, connection)
            ### Write to the buildings to the DB ###
            engine = settings.DB_ENGINE
            upload_df.to_sql(name='app_Business', con=engine,
                schema='Dev', if_exists='append', index=False)
            ### Succesfully uploaded buildings ###
            upload_list = list(set(
                                upload_df['business_id'].astype(str).tolist()
                                ))
            upload_list = [str(x) for x in upload_list]
            upload_fail_list = [x for x in businesses_list
                                if x not in upload_list]
            upload_pass_list = [x for x in upload_list
                                if x not in upload_fail_list]
            upload_fail = ", ".join(list(set(upload_fail_list)))
            upload_pass = ", ".join(list(set(upload_pass_list)))

            ### If there are business in another build, redirect to page showing the matching values ###
            if len(upload_fail) > 0:
                successful_message = '''These businesses were uploaded:'''
                successful_items = ifnull(upload_pass, 'No businesses were uploaded.') #pd.concat([upload_df['building_id']], axis=1, keys=['Building']).to_html(index=False)
                upload_failed_message = '''These businesses were not uploaded.
                    Please double check to ensure these are correct:'''
                upload_failed_items = ifnull(upload_fail, 'No businesses failed the upload.')
                #failed_items = businesses_df.to_html(index=False)
                #failed_message = '''These businesses are tied to a different build:'''
                request.session['successful_message'] = successful_message
                request.session['successful_items'] = successful_items
                request.session['upload_failed_message'] = upload_failed_message
                request.session['upload_failed_items'] = upload_failed_items
                request.session['failed_message'] = ''
                request.session['failed_items'] = ''
                return redirect('business_add_upload_failure', probuild_id)
            else:
                ### Redirect back to the Business Add page to see uploaded items ###
                return redirect('business_add', probuild_id=probuild_id)
        else:
            return render(request, 'business_add_upload.html', {'form': form,
                'probuild_id': probuild_id})
    else:
        form = BusinessUploadForm(initial={'probuild': probuild_id, 'upload_type':'1'})
        return render(request, 'business_add_upload.html', {'form': form,
            'probuild_id': probuild_id})

@login_required
def business_add_upload_failure(request, probuild_id):
    successful_message = request.session.get('successful_message', None)
    successful_items = request.session.get('successful_items', None)
    upload_failed_message = request.session.get('upload_failed_message', None)
    upload_failed_items = request.session.get('upload_failed_items', None)
    failed_message = request.session.get('failed_message', None)
    failed_items = request.session.get('failed_items', None)
    return render(request, 'business_add_upload_failure.html', {
            'probuild_id': probuild_id, 'successful_message': successful_message,
            'successful_items': successful_items,
            'upload_failed_message': upload_failed_message,
            'upload_failed_items': upload_failed_items,
            'failed_message': failed_message, 'failed_items': failed_items})

@login_required
def business_edit(request, record_id):
    if request.method == 'POST':
        form = BusinessEditForm(request.POST,instance=AppBusiness.objects.get(record_id=record_id))
        probuild_id = AppBusiness.objects.values_list('probuild_id', flat=True).filter(record_id=record_id)[0]
        if form.is_valid():
            business = form.save(commit=False)
            business.segment_assump = AssumpSegment.objects.get(
                segment_type = request.POST.get('segment_type_id'),
                    isactive = 1)
            business.editedby = request.user.username
            business.editedon = timezone.localtime(timezone.now())
            business.save()
            return redirect('business_edit', record_id=record_id)
        else:
            return render(request, 'business_edit.html',
                    {'form': form, 'probuild_id': probuild_id})
    else:
        form = BusinessEditForm(instance=AppBusiness.objects.get(record_id=record_id))
        probuild_id = AppBusiness.objects.values_list('probuild_id', flat=True).filter(record_id=record_id)[0]
    return render(request, 'business_edit.html', {'form': form, 'probuild_id': probuild_id})

@login_required
def deal_in_hand_add(request, probuild_id):
    if request.method == 'POST':
        ### Alter the string fields from the form to numerical values ####
        post = request.POST.copy()
        list_fields_strDollars = ['mrr']
        for field in list_fields_strDollars:
            dollars = strDollarToDecimal(request.POST.get(field))
            post[field] = dollars
        request.POST = post

        form = DealInHandAddForm(request.POST)
        if form.is_valid():
            deal = form.save(commit=False)
            deal.addedby = request.user.username
            deal.addedon = timezone.localtime(timezone.now())
            deal.save()
            return redirect('deal_in_hand_add', probuild_id=deal.probuild_id)
        else:
            deal_table = DealInHandTable(AppSfDealinhand.objects.exclude(
                deleted=1).filter(probuild=probuild_id))
            RequestConfig(request, paginate={'per_page': 20}).configure(deal_table)
            return render(request, 'deal_in_hand_add.html',
                    {'form': form, 'deal_table': deal_table, 'probuild_id': probuild_id})
    else:
        form = DealInHandAddForm(initial={'probuild': probuild_id })
        deal_table = DealInHandTable(AppSfDealinhand.objects.exclude(
            deleted=1).filter(probuild=probuild_id))
        RequestConfig(request, paginate={'per_page': 20}).configure(deal_table)
    return render(request, 'deal_in_hand_add.html',
            {'form': form, 'deal_table': deal_table, 'probuild_id': probuild_id})

@login_required
def deal_in_hand_edit(request, sf_dealinhand_id):
    if request.method == 'POST':
        ### Alter the string fields from the form to numerical values ####
        post = request.POST.copy()
        list_fields_strDollars = ['mrr']
        for field in list_fields_strDollars:
            dollars = strDollarToDecimal(request.POST.get(field))
            post[field] = dollars
        request.POST = post

        form = DealInHandEditForm(request.POST,instance=
            AppSfDealinhand.objects.get(sf_dealinhand_id=sf_dealinhand_id))
        if form.is_valid():
            deal = form.save(commit=False)
            deal.editedby = request.user.username
            deal.editedon = timezone.localtime(timezone.now())
            deal.save()
            return redirect('deal_in_hand_edit', sf_dealinhand_id=sf_dealinhand_id)
        else:
            return render(request, 'deal_in_hand_edit.html',
                {'form': form, 'probuild_id': probuild_id})
    else:
        form = DealInHandEditForm(instance=AppSfDealinhand.objects.get(sf_dealinhand_id=sf_dealinhand_id))
        probuild_id = AppSfDealinhand.objects.values_list('probuild', flat=True).filter(sf_dealinhand_id=sf_dealinhand_id)[0]
    return render(request, 'deal_in_hand_edit.html', {'form': form, 'probuild_id': probuild_id})

@login_required
def mdu_add(request, probuild_id):
    if request.method == 'POST':
        ### Alter the string fields from the form to numerical values ####
        post = request.POST.copy()
        list_fields_strDollars = ['video_arpu','data_arpu', 'voice_arpu',
            'door_fees', 'isp_per_unit', 'converter', 'modem', 'emta',
            'commission']
        for field in list_fields_strDollars:
            dollars = strDollarToDecimal(request.POST.get(field))
            post[field] = dollars
        list_fields_strPercent = ['video_penetration', 'data_penetration',
            'voice_penetration', 'video_rev_share', 'data_rev_share',
            'voice_rev_share', 'opex_load']
        for field in list_fields_strPercent:
            percent = strPercentToDecimal(request.POST.get(field))
            post[field] = percent
        request.POST = post

        form = MduAddForm(request.POST)
        mdu_build_type = request.POST.get('mdu_build_type')
        current_service_type = request.POST.get('current_service_type')
        region = AppProbuild.objects.values_list('region', flat=True).filter(probuild_id=probuild_id)[0]
        if form.is_valid():
            mdu = form.save(commit=False)
            mdu.mdu_build_assump = AssumpMduBuild.objects.get(
                mdu_build_type=mdu_build_type, current_service_type=current_service_type, isactive='1')
            mdu.mdu_build_region_assump = AssumpMduBuildRegion.objects.get(region=region, isactive='1')
            mdu.addedby = request.user.username
            mdu.addedon = timezone.localtime(timezone.now())
            mdu.save()
            return redirect('mdu_add', probuild_id=probuild_id)

        else:
            form = MduAddForm(initial={'probuild': probuild_id })
            mdu_table = MduTable(AppMdu.objects.exclude(
                    deleted=1).filter(probuild=probuild_id))
            RequestConfig(request, paginate={'per_page': 20}).configure(mdu_table)
            return render(request, 'mdu_add.html', {'form': form,
                        'mdu_table': mdu_table,'probuild_id': probuild_id})
    else:
        form = MduAddForm(initial={'probuild': probuild_id })
        mdu_table = MduTable(AppMdu.objects.exclude(
                deleted=1).filter(probuild=probuild_id))
        RequestConfig(request, paginate={'per_page': 20}).configure(mdu_table)
        return render(request, 'mdu_add.html', {'form': form,
                'mdu_table': mdu_table,'probuild_id': probuild_id})

@login_required
def mdu_edit(request, mdu_id):
    if request.method == 'POST':
        ### Alter the string fields from the form to numerical values ####
        post = request.POST.copy()
        list_fields_strDollars = ['video_arpu','data_arpu', 'voice_arpu',
            'door_fees', 'isp_per_unit', 'converter', 'modem', 'emta',
            'commission']
        for field in list_fields_strDollars:
            dollars = strDollarToDecimal(request.POST.get(field))
            post[field] = dollars
        list_fields_strPercent = ['video_penetration', 'data_penetration',
            'voice_penetration', 'video_rev_share', 'data_rev_share',
            'voice_rev_share', 'opex_load']
        for field in list_fields_strPercent:
            percent = strPercentToDecimal(request.POST.get(field))
            post[field] = percent
        request.POST = post

        form = MduEditForm(request.POST,instance=AppMdu.objects.get(mdu_id=mdu_id))
        if form.is_valid():
            mdu = form.save(commit=False)
            mdu.editedby = request.user.username
            mdu.editedon = timezone.localtime(timezone.now())
            mdu.save()
            return redirect('mdu_edit', mdu_id=mdu_id)
        else:
            return render(request, 'mdu_edit.html',
                {'form': form, 'probuild_id': probuild_id})
    else:
        form = MduEditForm(instance=AppMdu.objects.get(mdu_id=mdu_id))
        probuild_id = AppMdu.objects.values_list('probuild', flat=True).filter(mdu_id=mdu_id)[0]
    return render(request, 'mdu_edit.html', {'form': form, 'probuild_id': probuild_id})

@login_required
def data_center_add(request, probuild_id):
    if request.method == 'POST':
        ### Alter the string fields from the form to numerical values ####
        post = request.POST.copy()
        list_fields_strDollars = ['rack','colo_fee', 'connect_cost',
            'mrr_per_circ_avg', 'equip_capex', 'equip_opex']
        for field in list_fields_strDollars:
            dollars = strDollarToDecimal(request.POST.get(field))
            post[field] = dollars
        list_fields_strPercent = ['opex_pct']
        for field in list_fields_strPercent:
            percent = strPercentToDecimal(request.POST.get(field))
            post[field] = percent
        request.POST = post

        form = DataCenterAddForm(request.POST)
        data_center_type = request.POST.get('data_center_type')
        data_center_equip_type = request.POST.get('data_center_equip_type')
        if form.is_valid():
            center = form.save(commit=False)
            center.data_center_type_assump = AssumpDataCenterType.objects.get(
                data_center_type = data_center_type, isactive = 1)
            center.data_center_equip_type_assump = AssumpDataCenterEquipType.objects.get(
                data_center_equip_type = data_center_equip_type, isactive = 1)
            center.data_center_circuit_eoy_assump = AssumpDataCenterCircuitEoy.objects.filter(
                data_center_type = data_center_type, isactive = 1).aggregate(
                id=Max('data_center_circuit_eoy_assump_id'))['id']
            center.addedby = request.user.username
            center.addedon = timezone.localtime(timezone.now())
            center.save()
            return redirect('data_center_add', probuild_id=probuild_id)
        else:
            form = DataCenterAddForm(initial={
                                            'probuild': probuild_id,
                                            'data_center_assump': '1'
                                            })
            data_centers = DataCenterTable(AppDatacenter.objects.exclude(
                    deleted=1).filter(probuild=probuild_id))
            RequestConfig(request, paginate={'per_page': 20}).configure(data_centers)
            return render(request, 'data_center_add.html',
                {'form': form, 'data_centers': data_centers, 'probuild_id': probuild_id})
    else:
        form = DataCenterAddForm(initial={
                                        'probuild': probuild_id,
                                        'data_center_assump': '1'
                                        })
        data_centers = DataCenterTable(AppDatacenter.objects.exclude(
                deleted=1).filter(probuild=probuild_id))
        RequestConfig(request, paginate={'per_page': 20}).configure(data_centers)
    return render(request, 'data_center_add.html', {'form': form,
            'data_centers': data_centers, 'probuild_id': probuild_id})

@login_required
def data_center_edit(request, datacenter_id):
    if request.method == 'POST':
        ### Alter the string fields from the form to numerical values ####
        post = request.POST.copy()
        list_fields_strDollars = ['rack','colo_fee', 'connect_cost',
            'mrr_per_circ_avg', 'equip_capex', 'equip_opex']
        for field in list_fields_strDollars:
            dollars = strDollarToDecimal(request.POST.get(field))
            post[field] = dollars
        list_fields_strPercent = ['opex_pct']
        for field in list_fields_strPercent:
            percent = strPercentToDecimal(request.POST.get(field))
            post[field] = percent
        request.POST = post

        form = DataCenterEditForm(request.POST,
                instance=AppDatacenter.objects.get(datacenter_id=datacenter_id))
        data_center_type = request.POST.get('data_center_type')
        data_center_equip_type = request.POST.get('data_center_equip_type')
        if form.is_valid():
            center = form.save(commit=False)
            center.editedby = request.user.username
            center.editedon = timezone.localtime(timezone.now())
            center.data_center_type_assump = AssumpDataCenterType.objects.get(
                data_center_type = data_center_type, isactive = 1)
            center.data_center_equip_type_assump = AssumpDataCenterEquipType.objects.get(
                data_center_equip_type = data_center_equip_type, isactive = 1)
            center.data_center_circuit_eoy_assump = AssumpDataCenterCircuitEoy.objects.filter(
                data_center_type = data_center_type, isactive = 1).aggregate(
                id=Max('data_center_circuit_eoy_assump_id'))['id']
            center.save()
            return redirect('data_center_edit', datacenter_id=datacenter_id)
        else:
            return render(request, 'data_center_edit.html',
                    {'form': form, 'probuild_id': probuild_id})
    else:
        form = DataCenterEditForm(instance=AppDatacenter.objects.get(datacenter_id=datacenter_id))
        probuild_id = AppDatacenter.objects.values_list('probuild', flat=True).filter(datacenter_id=datacenter_id)[0]
    return render(request, 'data_center_edit.html', {'form': form, 'probuild_id': probuild_id})

@login_required
def file_upload(request, probuild_id):
    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            file = form.save(commit=False)
            file.path = request.FILES['path']
            file.root = str(settings.MEDIA_ROOT)
            file.addedby = request.user.username
            file.addedon = timezone.localtime(timezone.now())
            file.save()
            return redirect('file_upload', probuild_id=probuild_id)
        else:
            file_table = FileTable(AppFile.objects.exclude(
                    deleted=1).filter(probuild=probuild_id))
            RequestConfig(request, paginate={'per_page': 20}).configure(file_table)
            return render(request, 'file_upload.html',
                    {'form': form, 'file_table': file_table, 'probuild_id': probuild_id})
    else:
        form = FileUploadForm(initial={'probuild': probuild_id})
        file_table = FileTable(AppFile.objects.exclude(
                deleted=1).filter(probuild=probuild_id))
        RequestConfig(request, paginate={'per_page': 20}).configure(file_table)
    return render(request, 'file_upload.html', {'form': form,
            'file_table': file_table, 'probuild_id': probuild_id})

@login_required
def file_edit(request, file_id):
    if request.method == 'POST':
        form = FileEditForm(request.POST, request.FILES,
                instance=AppFile.objects.get(file_id=file_id))
        if form.is_valid():
            file = form.save(commit=False)
            if request.FILES:
                file.path = request.FILES['path']
                file.root = str(settings.MEDIA_ROOT)
            file.editedby = request.user.username
            file.editedon = timezone.localtime(timezone.now())
            file.save()
            return redirect('file_edit', file_id=file_id)
        else:
            return render(request, 'file_edit.html',
                {'form': form, 'probuild_id': probuild_id})
    else:
        form = FileEditForm(instance=AppFile.objects.get(file_id=file_id))
        probuild_id = AppFile.objects.values_list('probuild_id', flat=True).filter(file_id=file_id)[0]
    return render(request, 'file_edit.html', {'form': form, 'probuild_id': probuild_id})

@login_required
def upload_test(request):
    if request.method == 'POST':
        form = UploadTestForm(request.POST, request.FILES)
        data = csv.DictReader(codecs.iterdecode(request.FILES['upload'],'utf-8'))
        csv_headers = data.fieldnames
        ### Check file for the correct business headers and pull the data. ###
        ### If the correct heders are present. ###
        ### Otherwise, redirect to a page illustrating proper headers ###
        ### BUILDINGS ###
        building_headers = ['building_id','BUILDING_ID','MIP_BUILDING_ID']
        buildings_list = []
        for header in building_headers:
            if header in csv_headers:
                for row in data:
                    buildings_list.append(row[header])
        buildings_list = list(set(filter(None, buildings_list)))
        buildings = "'" + "','".join(buildings_list) + "'"
        ### BUSINESSES ###
        business_headers = ['business_id','BUSINESS_ID','MIP_QB_ID']
        businesses_list = []
        for header in business_headers:
            if header in csv_headers:
                for row in data:
                    businesses_list.append(row[header])
        businesses_list = list(filter(None, businesses_list))
        businesses = "'" + "','".join(businesses_list) + "'"
        failed_message = ('''The correct possible headers aren't in the file.
                    Please make sure the file contains one of the following:''')
        failed_items = (''' <ul>
                                <li>building_id</li>
                                <li>BUILDING_ID</li>
                                <li>MIP_BUILDING_ID</li>
                                <li>business_id</li>
                                <li>BUSINESS_ID</li>
                                <li>MIP_QB_ID</li>
                            </ul>''')
        ### If one of the possible headers isn't in file show error message. ###
        if (len(buildings_list) == 0) and (len(businesses_list) == 0):
            request.session['failed_message'] = failed_message
            request.session['failed_items'] = failed_items
            return redirect('upload_test_failure')
        ### Check the database to make sure the buildings in the file ###
        ### aren't tied to another build ###
        if len(buildings_list) > 0:
            buildings_sql = ('''SELECT  b.Name as Probuild
                                        ,a.Building_Id as Building
                                        ,NULL as Business
                                FROM    BI_MIP.miBuilds.app_Building as a
                                    JOIN BI_MIP.miBuilds.app_Probuild as b
                                    ON a.Probuild_Id = b.Probuild_Id
                                WHERE   a.building_id IN ({})
                                        and ISNULL(a.Deleted, 0) = 0'''
                            )
            buildings_sql = buildings_sql.format(buildings)
            buildings_df = pd.read_sql(buildings_sql, connection)
            ### Check the previous Excel version tables ###
            buildings_prev_sql = ('''   SELECT  a.BUILD_NAME + ' (Legacy Build)' as Probuild
                                                ,CAST(a.NAX_BUILDING_ID as INT) as Building
                                                ,NULL as Business
                                        FROM    BI_MIP.MIP2.PROBUILD_BUILDINGS as a
                                        WHERE   a.NAX_BUILDING_ID IN ({})'''
                        )
            buildings_prev_sql = buildings_prev_sql.format(buildings)
            buildings_prev_df = pd.read_sql(buildings_prev_sql, connection)
        ### Append to Failed Items Data Frames ###
        failed_items_df = buildings_df.append(buildings_prev_df, ignore_index=True)
        ### Check to database to make sure the businesses in the file ###
        ### aren't tied to another build ###
        if len(businesses_list) > 0:
            businesses_sql = ('''   SELECT  b.Name as Probuild
                                            ,NULL as Building
                                            ,a.Business_Id as Business
                                    FROM    BI_MIP.miBuilds.app_Business as a
                                        JOIN BI_MIP.miBuilds.app_Probuild as b
                                        ON a.Probuild_Id = b.Probuild_Id
                                    WHERE   a.Business_Id IN ({})
                                            and ISNULL(a.Deleted, 0) = 0'''
                        )
            businesses_sql = businesses_sql.format(businesses)
            businesses_df = pd.read_sql(businesses_sql, connection)
            failed_items_df = failed_items_df.append(businesses_df, ignore_index=True)
        ### Convert Failed Items to HTML table for representation
        failed_items = failed_items_df.to_html(index=False)
        ### Failed message ###
        failed_message = ('''These items are tied to a different build.
                            Please edit the file before trying again.''')
        ### If there are business in another build ###
        ### , redirect to page showing the matching values ###
        if len(failed_items_df.index) > 0:
            request.session['failed_message'] = failed_message
            request.session['failed_items'] = failed_items
            return redirect('upload_test_failure')
        else:
            return redirect('upload_test_success')
    else:
        form = UploadTestForm()
        return render(request, 'upload_test.html', {'form': form})

@login_required
def upload_test_success(request):
    return render(request, 'upload_test_success.html')

@login_required
def upload_test_failure(request):
    failed_message = request.session.get('failed_message', None)
    failed_items = request.session.get('failed_items', None)
    return render(request, 'upload_test_failure.html',
            {'failed_message': failed_message, 'failed_items': failed_items})

@login_required
def cashflow_view(request, probuild_id):
    sql = (''' EXEC BI_MIP.miBuilds.views_cashflow_df
                            @probuild_id = {}
                    ''').format(probuild_id)
    inputs_df = pd.read_sql(sql, connection)

    get = request.GET.copy()
    get['probuild_id'] = probuild_id
    get['customer_contribution'] = str(inputs_df['customer_contribution'].values[0])
    get['access_fees_one_time'] = str(inputs_df['access_fees_one_time'].values[0])
    get['access_fees_monthly'] = str(inputs_df['access_fees_monthly'].values[0])
    get['row_est_build_cost'] = str(inputs_df['row_est_build_cost'].values[0])
    get['headend_cost'] = str(inputs_df['headend_cost'].values[0])
    get['transport_cost'] = str(inputs_df['transport_cost'].values[0])
    get['private_property_cost'] = str(inputs_df['private_property_cost'].values[0])
    get['lat_construct_upfront_pct'] = str(inputs_df['lateral_construct_upfront_pct'].values[0])
    get['smb_arpu'] = str(inputs_df['smb_arpu'].values[0])
    get['ent_arpu'] = str(inputs_df['ent_arpu'].values[0])
    get['smb_12mo_pen'] = str(inputs_df['smb_12mo_pen'].values[0])
    get['smb_36mo_pen'] = str(inputs_df['smb_36mo_pen'].values[0])
    get['ent_12mo_pen'] = str(inputs_df['ent_12mo_pen'].values[0])
    get['ent_36mo_pen'] = str(inputs_df['ent_36mo_pen'].values[0])
    request.GET = get

    smb_ent_df = cashflow.build_smb_ent_df(request)
    smb_ent_df = smb_ent_df.fillna(0)
    smb_ent_df = smb_ent_df.to_html(index=False, classes='" id="id_smb_ent_cashflow_table')
    smb_ent_df = cashflowTableHTMLstyle(smb_ent_df)

    dc_df = cashflow.build_data_center_df(request)
    dc_df = dc_df.fillna(0)
    dc_df = dc_df.to_html(index=False, classes='" id="id_data_center_cashflow_table')
    dc_df = cashflowTableHTMLstyle(dc_df)

    return render(request, 'cashflow.html', {'smb_ent_df': smb_ent_df,
            'dc_df': dc_df, 'probuild_id': probuild_id})
