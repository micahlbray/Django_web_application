
from django.shortcuts import render, redirect, get_object_or_404
from django.core.exceptions import PermissionDenied
from django.db import connection
from miBuilds.models import AppProbuild
import pandas as pd

def user_is_authorized(function):
    def wrap(request, *args, **kwargs):
        ### Business case information ###
        probuild_id = kwargs['probuild_id']
        case = AppProbuild.objects.get(probuild_id = probuild_id)
        ### User permission information ###
        user_id = request.user.id
        user_sql = (''' EXEC BI_MIP.miBuilds.app_user_group_permission_df
                            @user_id = {}
                    ''').format(user_id)
        user_df = pd.read_sql(user_sql, connection)

        if len(user_df.index) <= 0:
            return redirect('business_case_select_failure')

        user_nt_login = user_df['NT_Login'].values[0]
        user_region = user_df['Region_Id'].values[0]
        user_canviewonlycreated = user_df['CanViewOnlyCreated'].values[0]
        user_canviewallregion = user_df['CanViewAllRegion'].values[0]
        user_canviewalldivision = user_df['CanViewAllDivision'].values[0]

        if user_canviewalldivision == 1:
            return function(request, *args, **kwargs)
        elif user_canviewallregion == 1:
            if user_region == case.region_id:
                return function(request, *args, **kwargs)
            else:
                return redirect('business_case_select_failure')
        elif user_canviewonlycreated == 1:
            if user_nt_login == case.addedby:
                return function(request, *args, **kwargs)
            else:
                return redirect('business_case_select_failure')
        else:
            return redirect('business_case_select_failure')
    wrap.__doc__ = function.__doc__
    wrap.__name__ = function.__name__
    return wrap
