function clearSearch() {
  var search_type_id = $('#id_search_type_id').val('');
  var search_value = $('#id_search_value').val('');
}

function hideSearchBtn() {
  var btn = $('#id_search_btn');
  btn.css('display','none');
}

function showSearchBtn() {
  var btn = $('#id_search_btn');
  btn.css('display','block');
  btn.css('float','right');
}

function hideSearchClearBtn() {
  var btn = $('#id_search_clear_btn');
  btn.css('display','none');
}

function showSearchClearBtn() {
  var btn = $('#id_search_clear_btn');
  btn.css('display','block');
  btn.css('float','right');
}

function displaySearchBizCaseTable() {
  var div = $(".content__detail__search__table-wrapper");
  div.css('display','block');
  div.css('width','100%');
}

function hideSearchBizCaseTable() {
  var div = $(".content__detail__search__table-wrapper");
  div.css('display','none');
  div.css('width','100%');
}

function displayBizCaseSelectTables() {
  var div = $(".content__detail__biz-case-select-wrapper");
  div.css('display','block');
  div.css('width','100%');
}

function hideBizCaseSelectTables() {
  var div = $(".content__detail__biz-case-select-wrapper");
  div.css('display','none');
  div.css('width','100%');
}

function searchResults() {
  var region_id = $('#id_user_region_id').val();
  var search_type_id = $('#id_search_type_id').val();
  var search_value = $('#id_search_value').val();

  if (search_type_id && search_value){
    hideBizCaseSelectTables();
    displaySearchBizCaseTable();
    hideSearchBtn();
    getSearchBizCaseDetail(region_id, search_type_id, search_value);
    showSearchClearBtn();
  } else {  
    if (search_type_id) {
      //do nothing
    } else {
      alert("Please select a Search Type.")
    };

    if (search_value){
      //do nothing
    } else {
      alert("Please enter a Search Value.")
    };
  }; 
}

function searchClear() {
  clearSearch();
  hideSearchClearBtn();
  hideSearchBizCaseTable();
  displayBizCaseSelectTables();
  showSearchBtn();
}



