function formatSmbEntCashFlowTable() {
  $('#id_smb_ent_cashflow_table tbody tr').each(function(){
    var i =  $(this).index();
    if (i < 2) {
      $(this).find('td').each (function() {
        txt = $(this).text()
        if (~txt.indexOf("Estimated")) {
          //do nothing
        } else {
          //format to %
          $(this).text(toFinalPercentFormatWithVal(txt))
        }
      });
    } else {
      $(this).find('td').each (function() {
        txt = $(this).text()
        if (~txt.indexOf("Estimated")) {
          //do nothing
        } else {
          //format to %
          $(this).text(toFinalDollarFormatWithVal(txt))
        }
      });
    }
  });
}

function formatDataCenterCashFlowTable() {
  $('#id_data_center_cashflow_table tbody tr').each(function(){
    var i =  $(this).index();
    if (i > 0) {
      $(this).find('td').each (function() {
        txt = $(this).text()
        if (~txt.indexOf("Estimated")) {
          //do nothing
        } else {
          //format to %
          $(this).text(toFinalDollarFormatWithVal(txt))
        }
      });
    } else {
      //
    }
  });
}
