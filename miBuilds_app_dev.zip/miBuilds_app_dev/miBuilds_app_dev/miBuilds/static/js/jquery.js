function openNav() {
    document.getElementById("menu-open").style.width = "250px";
    document.getElementById("menu-closed").style.marginLeft = "250px";
    document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
}

function closeNav() {
    document.getElementById("menu-open").style.width = "0";
    document.getElementById("menu-closed").style.marginLeft= "0";
    document.body.style.backgroundColor = "#000000";
}

function disableEnter(e) {
  var keyCode = e.keyCode || e.which;
  if (keyCode === 13) {
    e.preventDefault();
    return false;
  }
}

function removeRequiredFieldBorder() {
  field = $(this).val();
  if (field == null) {
    $(this).attr('required', true)
  } else if(field.length > 0) {
    $(this).removeAttr('required')
  } else {
    $(this).attr('required', true)
  }
}

function removeRequiredFieldBorderWithId(id) {
  field = $(id).val();
  if (field == null) {
    $(id).attr('required', true)
  } else if(field.length > 0) {
    $(id).removeAttr('required')
  } else {
    $(id).attr('required', true)
  }
}

function toFinalDollarFormat(){
  var field = $(this).val();
  var enteredNumber = '' + field;
  enteredNumber = enteredNumber.replace(/[^0-9\.]+/g, '');
  $(this).val(Number(enteredNumber).toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD'
    })
  );
}

function toFinalDollarFormatWithId(id){
  var field = $(id).val();
  var enteredNumber = '' + field;
  enteredNumber = enteredNumber.replace(/[^0-9\.]+/g, '');
  formatted = Number(enteredNumber).toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD'
  })
  if (field < 0) {
    $(id).val("-" + formatted);
  } else {
    $(id).val(formatted);
  }
}

function toFinalDollarFormatWithVal(val){
  var field = val
  var enteredNumber = '' + field;
  enteredNumber = enteredNumber.replace(/[^0-9\.]+/g, '');
  formatted = (Number(enteredNumber).toLocaleString('en-US', {
        style: 'currency',
        currency: 'USD'
      })
    );
  if (field < 0) {
    return "-" + formatted
  } else {
    return formatted
  }
}

function stripFinalDollarFormatWithVal(val){
  var field = val
  field = Number(field.replace(/[^0-9-\.-]+/g,""));
  return field
}

function toFinalPercentFormat(){
  var field = $(this).val();
  var enteredNumber = '' + field;
    if (enteredNumber.indexOf("%") > -1) {
        // empty
    } else {
        enteredNumber = enteredNumber.replace(/[^0-9\.]+/g, '');
        $(this).val(Number(enteredNumber).toLocaleString('en-US', {
          style: 'percent',
          maximumFractionDigits : 2,
          minimumFractionDigits : 2
          })
        );
    }
}

function toFinalPercentFormatWithId(id){
  var field = $(id).val();
  var enteredNumber = '' + field;
    if (enteredNumber.indexOf("%") > -1) {
        // empty
    } else {
      enteredNumber = enteredNumber.replace(/[^0-9\.-]+/g, '');
      $(id).val(Number(enteredNumber).toLocaleString('en-US', {
          style: 'percent',
          maximumFractionDigits : 2,
          minimumFractionDigits : 2
        })
      );
    }
}


function toFinalPercentFormatWithVal(val){
  var field = val
  var enteredNumber = '' + field;
    if (enteredNumber.indexOf("%") > -1) {
        // empty
    } else {
        enteredNumber = enteredNumber.replace(/[^0-9\.]+/g, '');
        formatted = (Number(enteredNumber).toLocaleString('en-US', {
          style: 'percent',
          maximumFractionDigits : 2,
          minimumFractionDigits : 2
          })
        );
    }
  if (field < 0) {
    return "-" + formatted
  } else {
    return formatted
  }
}

function stripFinalPercentFormatWithVal(val){
  var field = val
  field = (parseFloat(field) / 100).toFixed(3);
  return field
}

function removeBizCaseRequiredFieldBorderWithId() {
  removeRequiredFieldBorderWithId('#id_name');
  removeRequiredFieldBorderWithId('#id_region');
  removeRequiredFieldBorderWithId('#id_state');
  removeRequiredFieldBorderWithId('#id_build_type');
  removeRequiredFieldBorderWithId('#id_transport_type');
}

function removeBuildingRequiredFieldBorderWithId() {
  removeRequiredFieldBorderWithId('#id_state');
  removeRequiredFieldBorderWithId('#id_building_type');
  removeRequiredFieldBorderWithId('#id_dwelling_type');
}

function removeBusinessRequiredFieldBorderWithId() {
  removeRequiredFieldBorderWithId('#id_segment_type_id');
}

function removeMduRequiredFieldBorderWithId() {
  removeRequiredFieldBorderWithId('#id_mdu_build_type');
  removeRequiredFieldBorderWithId('#id_current_service_type');
  removeRequiredFieldBorderWithId('#id_term_length');
}

function removeDataCentRequiredFieldBorderWithId() {
  removeRequiredFieldBorderWithId('#id_data_center_type');
  removeRequiredFieldBorderWithId('#id_data_center_equip_type');
}

function removeDealRequiredFieldBorderWithId() {
  removeRequiredFieldBorderWithId('#id_term_length');
  removeRequiredFieldBorderWithId('#id_segment_type');
}

function formatCalculatorDollarFieldsWithId() {
  toFinalDollarFormatWithId('#id_customer_contribution');
  toFinalDollarFormatWithId('#id_row_est_build_cost');
  toFinalDollarFormatWithId('#id_headend_cost');
  toFinalDollarFormatWithId('#id_transport_cost');
  toFinalDollarFormatWithId('#id_private_property_cost');
  toFinalDollarFormatWithId('#id_smb_arpu');
  toFinalDollarFormatWithId('#id_ent_arpu');
  toFinalDollarFormatWithId('#id_car_value');
  toFinalDollarFormatWithId('#id_business_max_actual_capital');
  toFinalDollarFormatWithId('#id_resi_max_actual_capital');
  toFinalDollarFormatWithId('#id_npv');
  toFinalDollarFormatWithId('#id_npv_less_he_trnsprt');
  toFinalDollarFormatWithId('#id_passing_cost_per');
  toFinalDollarFormatWithId('#id_additional_osp_lateral_cost_per_connect');
}

function formatCalculatorPercentFieldsWithId() {
  toFinalPercentFormatWithId('#id_smb_12mo_pen');
  toFinalPercentFormatWithId('#id_smb_36mo_pen');
  toFinalPercentFormatWithId('#id_ent_12mo_pen');
  toFinalPercentFormatWithId('#id_ent_36mo_pen');
  toFinalPercentFormatWithId('#id_lateral_construct_upfront_pct');
  toFinalPercentFormatWithId('#id_business_capital_pct');
  toFinalPercentFormatWithId('#id_resi_capital_pct');
  toFinalPercentFormatWithId('#id_irr_pct');
  toFinalPercentFormatWithId('#id_irr_pct_less_he_trnsprt');
}

function formatBizCaseDollarFieldsWithId() {
  toFinalDollarFormatWithId('#id_customer_contribution');
  toFinalDollarFormatWithId('#id_row_est_build_cost');
  toFinalDollarFormatWithId('#id_headend_cost');
  toFinalDollarFormatWithId('#id_transport_cost');
  toFinalDollarFormatWithId('#id_private_property_cost');
  toFinalDollarFormatWithId('#id_smb_arpu');
  toFinalDollarFormatWithId('#id_ent_arpu');
  toFinalDollarFormatWithId('#id_car_value');
  toFinalDollarFormatWithId('#id_business_max_actual_capital');
  toFinalDollarFormatWithId('#id_resi_max_actual_capital');
  toFinalDollarFormatWithId('#id_npv');
  toFinalDollarFormatWithId('#id_npv_less_he_trnsprt');
  toFinalDollarFormatWithId('#id_passing_cost_per');
  toFinalDollarFormatWithId('#id_additional_osp_lateral_cost_per_connect');
  toFinalDollarFormatWithId('#id_row_car_value');
  toFinalDollarFormatWithId('#id_lat_car_value');
  toFinalDollarFormatWithId('#id_total_car_value');
}

function formatBizCasePercentFieldsWithId() {
  toFinalPercentFormatWithId('#id_smb_12mo_pen');
  toFinalPercentFormatWithId('#id_smb_36mo_pen');
  toFinalPercentFormatWithId('#id_ent_12mo_pen');
  toFinalPercentFormatWithId('#id_ent_36mo_pen');
  toFinalPercentFormatWithId('#id_lateral_construct_upfront_pct');
  toFinalPercentFormatWithId('#id_business_capital_pct');
  toFinalPercentFormatWithId('#id_resi_capital_pct');
  toFinalPercentFormatWithId('#id_irr_pct');
  toFinalPercentFormatWithId('#id_irr_pct_less_he_trnsprt');
}

function formatMduDollarFieldsWithId() {
  toFinalDollarFormatWithId('#id_video_arpu');
  toFinalDollarFormatWithId('#id_data_arpu');
  toFinalDollarFormatWithId('#id_voice_arpu');
  toFinalDollarFormatWithId('#id_door_fees');
  toFinalDollarFormatWithId('#id_isp_per_unit');
  toFinalDollarFormatWithId('#id_converter');
  toFinalDollarFormatWithId('#id_modem');
  toFinalDollarFormatWithId('#id_emta');
  toFinalDollarFormatWithId('#id_commission');
}

function formatMduPercentFieldsWithId() {
  toFinalPercentFormatWithId('#id_video_penetration');
  toFinalPercentFormatWithId('#id_data_penetration');
  toFinalPercentFormatWithId('#id_voice_penetration');
  toFinalPercentFormatWithId('#id_video_rev_share');
  toFinalPercentFormatWithId('#id_data_rev_share');
  toFinalPercentFormatWithId('#id_voice_rev_share');
  toFinalPercentFormatWithId('#id_opex_load');
}

function formatDataCentDollarFieldsWithId() {
  toFinalDollarFormatWithId('#id_rack');
  toFinalDollarFormatWithId('#id_colo_fee');
  toFinalDollarFormatWithId('#id_connect_cost');
  toFinalDollarFormatWithId('#id_mrr_per_circ_avg');
  toFinalDollarFormatWithId('#id_equip_capex');
  toFinalDollarFormatWithId('#id_equip_opex');
}

function formatDataCentPercentFieldsWithId() {
  toFinalPercentFormatWithId('#id_opex_pct');
}

function formatDealDollarFieldsWithId() {
  toFinalDollarFormatWithId('#id_mrr');
}


function removeHelpText() {
  $('.helpText').remove();
}

function autofillState() {
  var region = $('#id_region').val();
  var state = $('#id_state').val();
  //var state_name = $('#id_state').find("option:selected").text();
  $.ajax({
    type: "GET",
    url: '/ajax/select_state/',
    data: {'region': region},
    dataType: 'json',
    success: function (list_states) {
      $('#id_state').empty()
      if (list_states.length > 1) {
        $('#id_state').append('<option value="" disabled selected>Please select a State</option>');
        for (var i = 0; i < list_states.length; ++i) {
            $('#id_state')
                .append($("<option></option>")
                  .attr("value", list_states[i].state_id)
                  .text(list_states[i].name));
        };
        $('#id_state').val(state);
      } else if (list_states.length == 1) {
        $('#id_state')
            .append($("<option></option>")
              .attr("value", list_states[0].state_id)
              .text(list_states[0].name));
        $('#id_state').val(list_states[0].state_id)
        $('#id_state').removeAttr('required');
      }
    }
  });
}

function addRegionAssumpsHelpText() {
  var region = $('#id_region').val();
  $.ajax({
    type: "GET",
    url: '/ajax/assumps_region/',
    data: {'region': region},
    dataType: 'json',
    success: function (assumps) {
      var smb_arpu = $("#id_smb_arpu").val();
      var ent_arpu = $("#id_ent_arpu").val();
      var smb_12mo_pen = $("#id_smb_12mo_pen").val();
      var smb_36mo_pen = $("#id_smb_36mo_pen").val();
      var ent_12mo_pen = $("#id_ent_12mo_pen").val();
      var ent_36mo_pen = $("#id_ent_36mo_pen").val();
      var smb_arpu_diff = (stripFinalDollarFormatWithVal(smb_arpu)
                          - assumps['smb_arpu'])
      var ent_arpu_diff = (stripFinalDollarFormatWithVal(ent_arpu)
                          - assumps['ent_arpu'])
      var smb_12mo_pen_diff = (stripFinalPercentFormatWithVal(smb_12mo_pen)
                          - assumps['smb_12mo_pen'])
      var smb_36mo_pen_diff = (stripFinalPercentFormatWithVal(smb_36mo_pen)
                          - assumps['smb_36mo_pen'])
      var ent_12mo_pen_diff = (stripFinalPercentFormatWithVal(ent_12mo_pen)
                          - assumps['ent_12mo_pen'])
      var ent_36mo_pen_diff = (stripFinalPercentFormatWithVal(ent_36mo_pen)
                          - assumps['ent_36mo_pen'])
      if (smb_arpu_diff == 0) {
        $('#id_smb_arpu').next('span').remove();
      } else {
        if (smb_arpu_diff > 0) {
          $('#id_smb_arpu').next('span').remove();
          $('#id_smb_arpu').after("<span class='helpTextRed'>"
            + toFinalDollarFormatWithVal(smb_arpu_diff) + "</span>");
        } else {
          $('#id_smb_arpu').next('span').remove();
          $('#id_smb_arpu').after("<span class='helpTextGreen'>"
            + toFinalDollarFormatWithVal(smb_arpu_diff) + "</span>");
        }
      }
      if (ent_arpu_diff == 0) {
        $('#id_ent_arpu').next('span').remove();
      } else {
        if (ent_arpu_diff > 0) {
          $('#id_ent_arpu').next('span').remove();
          $('#id_ent_arpu').after("<span class='helpTextRed'>"
            + toFinalDollarFormatWithVal(ent_arpu_diff) + "</span>");
        } else {
          $('#id_ent_arpu').next('span').remove();
          $('#id_ent_arpu').after("<span class='helpTextGreen'>"
            + toFinalDollarFormatWithVal(ent_arpu_diff) + "</span>");
        }
      }
      if (smb_12mo_pen_diff == 0) {
        $('#id_smb_12mo_pen').next('span').remove();
      } else {
        if (smb_12mo_pen_diff > 0) {
          $('#id_smb_12mo_pen').next('span').remove();
          $('#id_smb_12mo_pen').after("<span class='helpTextRed'>"
            + toFinalPercentFormatWithVal(smb_12mo_pen_diff) + "</span>");
        } else {
          $('#id_smb_12mo_pen').next('span').remove();
          $('#id_smb_12mo_pen').after("<span class='helpTextGreen'>"
            + toFinalPercentFormatWithVal(smb_12mo_pen_diff) + "</span>");
        }
      }
      if (smb_36mo_pen_diff == 0) {
        $('#id_smb_36mo_pen').next('span').remove();
      } else {
        if (smb_36mo_pen_diff > 0) {
          $('#id_smb_36mo_pen').next('span').remove();
          $('#id_smb_36mo_pen').after("<span class='helpTextRed'>"
            + toFinalPercentFormatWithVal(smb_36mo_pen_diff) + "</span>");
        } else {
          $('#id_smb_36mo_pen').next('span').remove();
          $('#id_smb_36mo_pen').after("<span class='helpTextGreen'>"
            + toFinalPercentFormatWithVal(smb_36mo_pen_diff) + "</span>");
        }
      }
      if (ent_12mo_pen_diff == 0) {
        $('#id_ent_12mo_pen').next('span').remove();
      } else {
        if (ent_12mo_pen_diff > 0) {
          $('#id_ent_12mo_pen').next('span').remove();
          $('#id_ent_12mo_pen').after("<span class='helpTextRed'>"
            + toFinalPercentFormatWithVal(ent_12mo_pen_diff) + "</span>");
        } else {
          $('#id_ent_12mo_pen').next('span').remove();
          $('#id_ent_12mo_pen').after("<span class='helpTextGreen'>"
            + toFinalPercentFormatWithVal(ent_12mo_pen_diff) + "</span>");
        }
      }
      if (ent_36mo_pen_diff == 0) {
        $('#id_ent_36mo_pen').next('span').remove();
      } else {
        if (ent_36mo_pen_diff > 0) {
          $('#id_ent_36mo_pen').next('span').remove();
          $('#id_ent_36mo_pen').after("<span class='helpTextRed'>"
            + toFinalPercentFormatWithVal(ent_36mo_pen_diff) + "</span>");
        } else {
          $('#id_ent_36mo_pen').next('span').remove();
          $('#id_ent_36mo_pen').after("<span class='helpTextGreen'>"
            + toFinalPercentFormatWithVal(ent_36mo_pen_diff) + "</span>");
        }
      }
    }
  });
}

function assumpsRegion() {
  var region = $('#id_region').val();
  $.ajax({
    type: "GET",
    url: '/ajax/assumps_region/',
    data: {'region': region},
    dataType: 'json',
    success: function (assumps) {
      $('#id_smb_arpu').val(assumps['smb_arpu']);
      document.getElementById('id_smb_arpu').setAttribute("max", assumps['smb_arpu']);
      $('#id_ent_arpu').val(assumps['ent_arpu']);
      $('#id_smb_12mo_pen').val(assumps['smb_12mo_pen']);
      $('#id_smb_36mo_pen').val(assumps['smb_36mo_pen']);
      $('#id_ent_12mo_pen').val(assumps['ent_12mo_pen']);
      $('#id_ent_36mo_pen').val(assumps['ent_36mo_pen']);  
    }
  }).done(addRegionAssumpsHelpText());
}

function addBizCaseCalculationsHelpText(calcs) {
  var roe_target = calcs['roe_target'];
  var roe_acquired = calcs['roe_acquired'];
  var roe_target_diff = $('#id_roe_target').val() - roe_target;

  /// add help text to show minimum
  $('#id_roe_target').next('span').remove();
  $('#id_roe_target').after("<span class='helpText'>"
      + "Minimum of " + roe_target + "</span>");

  if (roe_target_diff == 0) {
    document.getElementById('id_roe_target').style.backgroundColor = "#008000";
  } else {
    /// highlight field green or red based on requirement
    if (roe_target_diff > 0) {
      document.getElementById('id_roe_target').style.backgroundColor = "#008000";
    } else {
      document.getElementById('id_roe_target').style.backgroundColor = "#FF0000";
    }
  }

  /// set a minimum on the ROE field based on the target
  document.getElementById('id_roe_target').setAttribute("min", calcs['roe_target']);

  var lat_construct_upfront_pct = $('#id_lateral_construct_upfront_pct').val()
  var lat_construct_upfront_pct_diff = (
                      stripFinalPercentFormatWithVal(lat_construct_upfront_pct)
                      - calcs['exp_lat_construct_upfront_pct'])
  if (lat_construct_upfront_pct_diff == 0) {
    $('#id_lateral_construct_upfront_pct').next('span').remove();
  } else {
    if (lat_construct_upfront_pct_diff > 0) {
      $('#id_lateral_construct_upfront_pct').next('span').remove();
      $('#id_lateral_construct_upfront_pct').after("<span class='helpTextRed'>"
        + toFinalPercentFormatWithVal(lat_construct_upfront_pct_diff) + "</span>");
    } else {
    $('#id_lateral_construct_upfront_pct').next('span').remove();
    $('#id_lateral_construct_upfront_pct').after("<span class='helpTextGreen'>"
        + toFinalPercentFormatWithVal(lat_construct_upfront_pct_diff) + "</span>");
    }
  }
}

function highlightIrrPct(calcs) {
  var irr = calcs['IRR']
  var irr_less_he_trnsprt = calcs['IRR_Less_HE_Trnsprt']
  // format IRR backgroundColor based on value
  if (irr >= 0.15) {
    document.getElementById('id_irr_pct').style.backgroundColor = "#008000";
  } else {
    document.getElementById('id_irr_pct').style.backgroundColor = "#FF0000";
  }
  // format IRR_Less_HE_Trnsprt backgroundColor based on value
  if (irr_less_he_trnsprt >= 0.15) {
    document.getElementById('id_irr_pct_less_he_trnsprt').style.backgroundColor = "#008000";
  } else {
    document.getElementById('id_irr_pct_less_he_trnsprt').style.backgroundColor = "#FF0000";
  }
}

function highlightIrrPctApproved() {
  var irr = stripFinalPercentFormatWithVal($('#id_irr_pct').val());
  var irr_less_he_trnsprt = stripFinalPercentFormatWithVal($('#id_irr_pct_less_he_trnsprt').val());
  // format IRR backgroundColor based on value
  if (irr >= 0.15) {
    document.getElementById('id_irr_pct').style.backgroundColor = "#008000";
  } else {
    document.getElementById('id_irr_pct').style.backgroundColor = "#FF0000";
  }
  // format IRR_Less_HE_Trnsprt backgroundColor based on value
  if (irr_less_he_trnsprt >= 0.15) {
    document.getElementById('id_irr_pct_less_he_trnsprt').style.backgroundColor = "#008000";
  } else {
    document.getElementById('id_irr_pct_less_he_trnsprt').style.backgroundColor = "#FF0000";
  }
}

function autofillBizCaseCalculations(calcs) {
  $('#id_roe_acquired').val(calcs['roe_acquired']);
  $('#id_fund_bucket').val(calcs['fund_bucket']);
  $('#id_business_capital_pct').val(calcs['business_pct']);
  $('#id_resi_capital_pct').val(calcs['resi_pct']);
  $('#id_smb_qb_ct').val(calcs['smb_qb_ct']);
  $('#id_ent_qb_ct').val(calcs['ent_qb_ct']);
  $('#id_building_ct').val(calcs['building_ct']);
  $('#id_multi_tenant_building_ct').val(calcs['multi_tenant_building_ct']);
  $('#id_dealinhand_ct').val(calcs['dealinhand_ct']);
  $('#id_mdu_ct').val(calcs['mdu_ct']);
  $('#id_datacenter_ct').val(calcs['datacenter_ct']);
  $('#id_row_car_value').val(calcs['ROW_CAR']);
  $('#id_lat_car_value').val(calcs['Lat_CAR']);
  $('#id_total_car_value').val(calcs['Total_CAR']);
  $('#id_irr_pct').val(calcs['IRR']);
  $('#id_irr_pct_less_he_trnsprt').val(calcs['IRR_Less_HE_Trnsprt'])
  $('#id_npv').val(calcs['NPV']);
  $('#id_npv_less_he_trnsprt').val(calcs['NPV_Less_HE_Trnsprt']);
  $('#id_payback_mo').val(calcs['payback_mo']);
  $('#id_passing_cost_per').val(calcs['passing_cost_per']);
  $('#id_additional_osp_lateral_cost_per_connect').val(calcs['lat_cost_per_connect']);
  $('#id_business_max_actual_capital').val(calcs['business_NPV']);
  $('#id_resi_max_actual_capital').val(calcs['resi_NPV']);
  $('#id_roe_target').val(calcs['roe_target']);
  $('#id_roe_acquired').val(calcs['roe_acquired']);
  $('#id_roe_needed').val(calcs['roe_needed']);
}

function autofillROEfields(){
  var roe_target = $('#id_roe_target').val();
  var roe_acquired = $('#id_roe_acquired').val();
  var roe_needed = roe_target - roe_acquired
  if (roe_needed < 0) {
    $('#id_roe_needed').val('0');
  } else {
    $('#id_roe_needed').val(roe_needed);
  };
}

function getBizCaseCalculations(case_status_user_perm) {
  var probuild_id = $('#id_probuild_id').val();
  var approved = $('#id_approved').val();
  var customer_contribution = $("#id_customer_contribution").val();
  var access_fees_one_time = $("#id_access_fees_one_time").val();
  var access_fees_monthly = $("#id_access_fees_monthly").val();
  var row_est_build_cost = $("#id_row_est_build_cost").val();
  var headend_cost = $("#id_headend_cost").val();
  var transport_cost = $("#id_transport_cost").val();
  var private_property_cost = $("#id_private_property_cost").val();
  var lat_construct_upfront_pct = $('#id_lateral_construct_upfront_pct').val()
  var smb_arpu = $("#id_smb_arpu").val();
  var ent_arpu = $("#id_ent_arpu").val();
  var smb_12mo_pen = $("#id_smb_12mo_pen").val();
  var smb_36mo_pen = $("#id_smb_36mo_pen").val();
  var ent_12mo_pen = $("#id_ent_12mo_pen").val();
  var ent_36mo_pen = $("#id_ent_36mo_pen").val();
  $.ajax({
    type: "GET",
    url: '/ajax/calcs_child_business_case/',
    data: {'probuild_id': probuild_id, 'customer_contribution': customer_contribution,
        'access_fees_one_time': access_fees_one_time, 'access_fees_monthly': access_fees_monthly,
        'row_est_build_cost': row_est_build_cost, 'headend_cost': headend_cost,
        'transport_cost': transport_cost, 'private_property_cost': private_property_cost,
        'lat_construct_upfront_pct': lat_construct_upfront_pct,
        'smb_arpu': smb_arpu, 'ent_arpu': ent_arpu,
        'smb_12mo_pen': smb_12mo_pen, 'smb_36mo_pen': smb_36mo_pen,
        'ent_12mo_pen': ent_12mo_pen, 'ent_36mo_pen': ent_36mo_pen,
        },
    dataType: 'json',
    success: function (calcs) {
      if (approved == 1) {
        addBizCaseCalculationsHelpText(calcs);
        highlightIrrPctApproved();
      } else {
        autofillBizCaseCalculations(calcs);
        addBizCaseCalculationsHelpText(calcs);
        highlightIrrPct(calcs);
      }
    }
  });
}

function alertIsValidROE() {
  var roe_id = $('#id_roe_id').val();
  $.ajax({
    type: "GET",
    url: '/ajax/alert_invalid_roe_id/',
    data: {'roe_id': roe_id},
    dataType: 'json',
    success: function (flagged) {
      var isvalid = flagged[0]['IsValid']
      if (isvalid == 1) {
        // do nothing
      } else {
        alert("This record has an invalid Pramata ID.")
      }
    }
  });
}

function autofillBuildingFields() {
  var building_id = $(this).val();
  $.ajax({
    type: "GET",
    url: '/ajax/autofill_building/',
    data: {'building_id': building_id},
    dataType: 'json',
    success: function (autofill) {
      $('#id_address').val('');
      $('#id_city').val('');
      $('#id_state').val('');
      $('#id_zip').val('');
      $('#id_building_type').val('');
      $('#id_dwelling_type').val('');
      $('#id_sellability_color_coax').val('');
      $('#id_sellability_color_fiber').val('');
      $('#id_roe_status_id').val('');
      $('#id_roe_id').val('');
      $('#id_address').val(autofill[0]['address']);
      $('#id_city').val(autofill[0]['city']);
      $('#id_state').val(autofill[0]['state']);
      $('#id_zip').val(autofill[0]['zip']);
      $('#id_building_type').val(autofill[0]['building_type']);
      $('#id_dwelling_type').val(autofill[0]['dwelling_type']);
      $('#id_sellability_color_coax').val(autofill[0]['sellability_color_coax']);
      $('#id_sellability_color_fiber').val(autofill[0]['sellability_color_fiber']);
      $('#id_roe_status_id').val(autofill[0]['roe_status_id']);
      $('#id_roe_id').val(autofill[0]['roe_id']);
    }
  });
}


function highlightBuildingUnmatched() {
  var probuild_id = $('#id_probuild').val();
  $.ajax({
    type: "GET",
    url: '/ajax/highlight_building_unmatched/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function (unmatched) {
      var unmatchedList = []
      for (var i = 0; i < unmatched['Record_Id'].length; ++i) {
        unmatchedList.push(Number(unmatched['Record_Id'][i]))
      }
      var table = $('#id_building_add_detail_table').DataTable();
      var rows_selected = table.data().toArray();
      console.log(rows_selected)
      $('#id_building_add_detail_table tbody tr').each(function(){
        var record_id = Number($(this).attr('record_id'))
        console.log(record_id)
        if ($.inArray(record_id, unmatchedList) != -1) {
          $(this).removeClass("odd")
          $(this).removeClass("even")
          $(this).addClass("highlightRow")
        }
      });
    }
  });
}

function highlightBuildingInvalidROE() {
  var probuild_id = $('#id_probuild').val();
  $.ajax({
    type: "GET",
    url: '/ajax/highlight_building_invalid_roe_id/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function (flagged) {
      var flaggedList = []
      for (var i = 0; i < flagged['Record_Id'].length; ++i) {
        flaggedList.push(Number(flagged['Record_Id'][i]))
      }
      $('#id_building_add_detail_table tbody tr').each(function(){
        var record_id = Number($(this).attr('record_id'))
        if ($.inArray(record_id, flaggedList) != -1) {
          $(this).find("td.roe_id").css({backgroundColor: "red"})
        }
      });
    }
  });
}

function flagBuildingServiceability() {
  var probuild_id = $('#id_probuild').val();
  $.ajax({
    type: "GET",
    url: '/ajax/flag_building_serviceability/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function (flagged) {
      var flaggedList = []
      for (var i = 0; i < flagged['Record_Id'].length; ++i) {
        flaggedList.push(Number(flagged['Record_Id'][i]))
      }
      $('#id_building_add_detail_table tbody tr').each(function(){
        var record_id = Number($(this).attr('record_id'))
        if ($.inArray(record_id, flaggedList) != -1) {
          $(this).removeClass("odd")
          $(this).removeClass("even")
          $(this).addClass("flagRow")
        }
      });
    }
  });
}

function flagBuildingDwellingType() {
  var probuild_id = $('#id_probuild').val();
  $.ajax({
    type: "GET",
    url: '/ajax/flag_building_dwelling_type/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function (flagged) {
      var flaggedList = []
      for (var i = 0; i < flagged['Record_Id'].length; ++i) {
        flaggedList.push(Number(flagged['Record_Id'][i]))
      }
      $('#id_building_add_detail_table tbody tr').each(function(){
        var record_id = Number($(this).attr('record_id'))
        if ($.inArray(record_id, flaggedList) != -1) {
          $(this).find("td.dwelling_type").css({backgroundColor: "orange"})
        }
      });
    }
  });
}

//function deleteBuilding() {
  //var record_id = $(this).closest('tr').attr('record_id');
  //var building_id = $(this).closest('tr').find('.building_id').text();
  //var message = confirm("Are you sure you want to delete Building: " + building_id + "?");
  //if (message == true) {
    //$.ajax({
      //type: "GET",
      //url: '/ajax/delete_building/',
      //data: {'record_id': record_id, 'building_id': building_id},
      //dataType: 'json',
      //success: function (deleted) {
        //var building_id = deleted['building_id'];
        //alert("You succesfully deleted " + building_id + "!");
        //window.location.reload();
      //}
    //});
  //}
  //else {
  //}
//}

function deleteBuilding(record_id, building_id) {
  var message = confirm("Are you sure you want to delete Building: " + building_id + "?");
  if (message == true) {
    $.ajax({
      type: "GET",
      url: '/ajax/delete_building/',
      data: {'record_id': record_id, 'building_id': building_id},
      dataType: 'json',
      success: function (deleted) {
        var building_id = deleted['building_id'];
        alert("You succesfully deleted " + building_id + "!");
        window.location.reload();
      }
    });
  }
  else {
  }
}

//function deleteBuildingSelection() {
  //var message = confirm("Are you sure you want to delete these buildings?")
  //if (message == true){
    //var rcdNotChecked = [], rcdChecked = [];
    //var bldNotChecked = [], bldChecked = [];
      //$(":checkbox").each(function() {
        //if(this.checked){
            //rcdChecked.push($(this).closest('tr').attr('record_id'));
            //bldChecked.push($(this).closest('tr').find('.building_id').text());
        //}
      //});
    //var dlbMessage = confirm("You are about to delete Building Id(s): " + bldChecked);
    //if (dlbMessage == true){
      //var jsonText = JSON.stringify(rcdChecked)
      //$.ajax({
        //type: "GET",
        //url: '/ajax/delete_building_selection/',
        //data: {'record_id_list': rcdChecked},
        //traditional: true,
        //dataType: 'html',
        //success: function (deleted) {
          //alert("You succesfully deleted " + bldChecked + "!");
          //window.location.reload();
        //}
      //});
    //} else {
      //alert("You have decided not to delete these buildings.")
    //}
  //} else {
    //alert("You have decided not to delete these buildings.")
  //}
//}

function deleteBuildingSelection(rcdChecked, bldChecked) {
  var message = confirm("Are you sure you want to delete these buildings?")
  if (message == true){
    var dlbMessage = confirm("You are about to delete Building Id(s): " + bldChecked);
    if (dlbMessage == true){
      var jsonText = JSON.stringify(rcdChecked)
      $.ajax({
        type: "GET",
        url: '/ajax/delete_building_selection/',
        data: {'record_id_list': rcdChecked},
        traditional: true,
        dataType: 'html',
        success: function (deleted) {
          alert("You succesfully deleted " + bldChecked + "!");
          window.location.reload();
        }
      });
    } else {
      alert("You have decided not to delete these buildings.")
    }
  } else {
    alert("You have decided not to delete these buildings.")
  }
}


function autofillBusinessFields() {
  var business_id = $(this).val();

  $.ajax({
    type: "GET",
    url: '/ajax/autofill_business/',
    data: {'business_id': business_id},
    dataType: 'json',
    success: function (autofill) {
      $('#id_building_id').val('');
      $('#id_business_name').val('');
      $('#id_address_1').val('');
      $('#id_address_2').val('');
      $('#id_sellability_color_coax').val('');
      $('#id_sellability_color_fiber').val('');
      $('#id_segment_type_id').val('');
      $('#id_building_id').val(autofill[0]['building_id']);
      $('#id_business_name').val(autofill[0]['business_name']);
      $('#id_address_1').val(autofill[0]['address_1']);
      $('#id_address_2').val(autofill[0]['address_2']);
      $('#id_sellability_color_coax').val(autofill[0]['sellability_color_coax']);
      $('#id_sellability_color_fiber').val(autofill[0]['sellability_color_fiber']);
      $('#id_segment_type_id').val(autofill[0]['segment_type_id']);
    }
  });
}

function highlightBusiness() {
  var probuild_id = $('#id_probuild').val();
  $.ajax({
    type: "GET",
    url: '/ajax/highlight_business_unmatched/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function (unmatched) {
      var unmatchedList = []
      for (var i = 0; i < unmatched['Record_Id'].length; ++i) {
        unmatchedList.push(Number(unmatched['Record_Id'][i]))
      }
      $('#id_business_table tbody tr').each(function(){
        var record_id = Number($(this).attr('record_id'))
        if ($.inArray(record_id, unmatchedList) != -1) {
          $(this).removeClass("odd")
          $(this).removeClass("even")
          $(this).addClass("highlightRow")
        }
      });
    }
  });
}

function highlightBusinessInvalidROE() {
  var probuild_id = $('#id_probuild').val();
  $.ajax({
    type: "GET",
    url: '/ajax/highlight_business_invalid_roe_id/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function (flagged) {
      var flaggedList = []
      for (var i = 0; i < flagged['Record_Id'].length; ++i) {
        flaggedList.push(Number(flagged['Record_Id'][i]))
      }
      $('#id_business_table tbody tr').each(function(){
        var record_id = Number($(this).attr('record_id'))
        if ($.inArray(record_id, flaggedList) != -1) {
          $(this).find("td.roe_id").css({backgroundColor: "red"})
        }
      });
    }
  });
}


//function deleteBusiness() {
  //var record_id = $(this).closest('tr').attr('record_id');
  //var business_id = $(this).closest('tr').find('.business_id').text();
  //var message = confirm("Are you sure you want to delete Business: " + business_id + "?");
  //if (message == true) {
    //$.ajax({
      //type: "GET",
      //url: '/ajax/delete_business/',
      //data: {'record_id': record_id, 'business_id': business_id},
      //dataType: 'json',
      //success: function (deleted) {
        //var business_id = deleted['business_id'];
        //alert("You succesfully deleted " + business_id + "!");
        //window.location.reload();
      //}
    //});
  //}
  //else {
  //}
//}

function deleteBusiness(record_id, business_id) {
  var message = confirm("Are you sure you want to delete Business: " + business_id + "?");
  if (message == true) {
    $.ajax({
      type: "GET",
      url: '/ajax/delete_business/',
      data: {'record_id': record_id, 'business_id': business_id},
      dataType: 'json',
      success: function (deleted) {
        var business_id = deleted['business_id'];
        alert("You succesfully deleted " + business_id + "!");
        window.location.reload();
      }
    });
  }
  else {
  }
}

//function deleteBusinessSelection() {
  //var message = confirm("Are you sure you want to delete these businesses?")
  //if (message == true){
    //var rcdNotChecked = [], rcdChecked = [];
    //var bizNotChecked = [], bizChecked = [];
      //$(":checkbox").each(function() {
        //if(this.checked){
            //rcdChecked.push($(this).closest('tr').attr('record_id'));
            //bizChecked.push($(this).closest('tr').find('.business_id').text());
        //}
      //});
    //var dlbMessage = confirm("You are about to delete Business Id(s): " + bizChecked);
    //if (dlbMessage == true){
      //var jsonText = JSON.stringify(rcdChecked)
      //$.ajax({
        //type: "GET",
        //url: '/ajax/delete_business_selection/',
        //data: {'record_id_list': rcdChecked},
        //traditional: true,
        //dataType: 'html',
        //success: function (deleted) {
          //alert("You succesfully deleted " + bizChecked + "!");
          //window.location.reload();
        //}
      //});
    //} else {
      //alert("You have decided not to delete these businesses.")
    //}
  //} else {
    //alert("You have decided not to delete these businesses.")
  //}
//}

function deleteBusinessSelection(rcdChecked, bizChecked) {
  var message = confirm("Are you sure you want to delete these businesses?")
  if (message == true){
    var dlbMessage = confirm("You are about to delete Business Id(s): " + bizChecked);
    if (dlbMessage == true){
      var jsonText = JSON.stringify(rcdChecked)
      $.ajax({
        type: "GET",
        url: '/ajax/delete_business_selection/',
        data: {'record_id_list': rcdChecked},
        traditional: true,
        dataType: 'html',
        success: function (deleted) {
          alert("You succesfully deleted " + bizChecked + "!");
          window.location.reload();
        }
      });
    } else {
      alert("You have decided not to delete these businesses.")
    }
  } else {
    alert("You have decided not to delete these businesses.")
  }
}

function emailProbuildNote() {
  var probuild_note_id = $(this).closest('tr').attr('probuild_note_id');
  var addedby = $(this).closest('tr').find('.addedby').text();
  var note = $(this).closest('tr').find('.note').text();
  var note_type = $(this).closest('tr').find('.note_type').text();
  var message = confirm("Are you sure you want to email this note?");
  if (message == true) {
    $.ajax({
      type: "GET",
      url: '/ajax/email_business_case_note/',
      data: {'probuild_note_id': probuild_note_id,
          'addedby': addedby, 'note': note, 'note_type': note_type},
      dataType: 'text',
      success: function () {
        alert("You succesfully emailed this note!");
      }
    });
  }
  else {
  }
}

function assumpsDataCenterType() {
  var data_center_type = $('#id_data_center_type').val();
  $.ajax({
    type: "GET",
    url: '/ajax/assumps_data_center_type/',
    data: {'data_center_type': data_center_type},
    dataType: 'json',
    success: function (assumps) {
      $('#id_rack').val(assumps[0]['rack']);
      $('#id_equip_opex').val(assumps[1]['opex']);
      $('#id_colo_fee').val(assumps[0]['colo_fee']);
      $('#id_connect_cost').val(assumps[0]['connect_cost']);
      $('#id_data_center_equip_type').val(assumps[0]['data_center_equip_type']);
      $('#id_equip_capex').val(assumps[1]['capex']);
      $('#id_mrr_per_circ_avg').val(assumps[0]['mrr_per_circ_avg']);
      $('#id_opex_pct').val(assumps[0]['opex_pct']);
      $('#id_yr1_circuit_ct').val(assumps[2]['1']);
      $('#id_yr2_circuit_ct').val(assumps[2]['2']);
      $('#id_yr3_circuit_ct').val(assumps[2]['3']);
      $('#id_yr4_circuit_ct').val(assumps[2]['4']);
      $('#id_yr5_circuit_ct').val(assumps[2]['5']);
    }
  });
}

function assumpsDataCenterEquipType() {
  var data_center_equip_type = $('#id_data_center_equip_type').val();
  $.ajax({
    type: "GET",
    url: '/ajax/assumps_data_center_equip/',
    data: {'data_center_equip_type': data_center_equip_type},
    dataType: 'json',
    success: function (assumps) {
      $('#id_equip_capex').val(assumps['capex']);
      $('#id_equip_opex').val(assumps['opex']);
    }
  });
}

function deleteDataCenter() {
  var datacenter_id = $(this).closest('tr').attr('datacenter_id');
  var datacenter_name = $(this).closest('tr').find('.name').text();
  var message = confirm("Are you sure you want to delete Data Center: " + datacenter_name + "?");
  if (message == true) {
    $.ajax({
      type: "GET",
      url: '/ajax/delete_data_center/',
      data: {'datacenter_id': datacenter_id, 'datacenter_name': datacenter_name},
      dataType: 'json',
      success: function (deleted) {
        var datacenter_name = deleted['datacenter_name'];
        alert("You succesfully deleted " + datacenter_name + "!");
        window.location.reload();
      }
    });
  }
  else {
  }
}

function autofillDealInHand() {
  var opportunity_id = $(this).val();

  $.ajax({
    type: "GET",
    url: '/ajax/autofill_deal_in_hand/',
    data: {'opportunity_id': opportunity_id},
    dataType: 'json',
    success: function (autofill) {
      $('#id_customer_name').val('');
      $('#id_term_length').val('');
      $('#id_segment_type').val('');
      $('#id_mrr').val('');
      $('#id_customer_name').val(autofill[0]['customer_name']);
      $('#id_term_length').val(autofill[0]['term_length_id']);
      $('#id_segment_type').val(autofill[0]['segment_type_id']);
      $('#id_mrr').val(autofill[0]['mrr']);
    }
  });
}

function deleteDealInHand() {
  var sf_dealinhand_id = $(this).closest('tr').attr('sf_dealinhand_id');
  var sf_dealinhand_name = $(this).closest('tr').find('.customer_name').text();
  var message = confirm("Are you sure you want to delete Deal: " + sf_dealinhand_name + "?");
  if (message == true) {
    $.ajax({
      type: "GET",
      url: '/ajax/delete_deal_in_hand/',
      data: {'sf_dealinhand_id': sf_dealinhand_id},
      success: function(deleted) {
        alert("You succesfully deleted " + sf_dealinhand_name + "!");
        window.location.reload();
      }
    });
  }
  else {
  }
}

function viewFile() {
    var url = $(this).val();
    window.open(url, '_blank');
}

function viewFileSelection() {
  $(":checkbox").each(function() {
    if(this.checked){
      url = $(this).closest('tr').find('#id_view_record').val();
      window.open(url, '_blank');
    }
  });
}

function deleteFile() {
  var probuild_id = $("#id_probuild_id").text();
  var file_id = $(this).closest('tr').attr('file_id');
  var file_name = $(this).closest('tr').find('.name').text();
  var message = confirm("Are you sure you want to delete File: " + file_name + "?");
  if (message == true) {
    $.ajax({
      type: "GET",
      url: '/ajax/delete_file/',
      data: {'file_id': file_id},
      success: function(deleted) {
        alert("You succesfully deleted " + file_name + "!");
        window.location.reload();
      }
    });
  }
  else {
  }
}

function emptyMDUAssumptions() {
    $('#id_mdu_build_assump').val('');
    $("#id_video_penetration").val('');
    $("#id_data_penetration").val('');
    $("#id_voice_penetration").val('');
    $('#id_video_penetration').val('');
    $('#id_data_penetration').val('');
    $('#id_voice_penetration').val('');
    $('#id_video_arpu').val('');
    $('#id_data_arpu').val('');
    $('#id_voice_arpu').val('');
    $('#id_video_rev_share').val('');
    $('#id_data_rev_share').val('');
    $('#id_voice_rev_share').val('');
    $('#id_opex_load').val('');
    $('#id_door_fees').val('');
    $('#id_isp_per_unit').val('');
    $('#id_converter').val('');
    $('#id_modem').val('');
    $('#id_emta').val('');
}

function assumpsMDU() {
  var probuild = $("#id_probuild").val();
  var mdu_build_type = $("#id_mdu_build_type").val();
  var current_service_type = $(this).val();

  emptyMDUAssumptions();

  $.ajax({
    type: "GET",
    url: '/ajax/assumps_mdu/',
    data: {'probuild': probuild, 'mdu_build_type': mdu_build_type, 'current_service_type': current_service_type},
    dataType: 'json',
    success: function (assumps) {
      if(mdu_build_type == 3 && current_service_type == 4) {
        $('#id_video_penetration').val(assumps[0]['video_penetration']);
        $('#id_data_penetration').val(assumps[0]['data_penetration']);
        $('#id_voice_penetration').val(assumps[0]['voice_penetration']);
        $('#id_video_arpu').val(assumps[0]['video_arpu']);
        $('#id_data_arpu').val(assumps[0]['data_arpu']);
        $('#id_voice_arpu').val(assumps[0]['voice_arpu']);
        $('#id_video_rev_share').val(assumps[1]['video_rev_share']);
        $('#id_data_rev_share').val(assumps[1]['data_rev_share']);
        $('#id_voice_rev_share').val(assumps[1]['voice_rev_share']);
        $('#id_opex_load').val(assumps[1]['opex_load']);
        $('#id_door_fees').val(assumps[1]['door_fees']);
        $('#id_isp_per_unit').val(assumps[1]['isp_per_unit']);
        $('#id_converter').val(assumps[1]['converter']);
        $('#id_modem').val(assumps[1]['modem']);
        $('#id_emta').val(assumps[1]['emta']);
        $('#id_penetration_ramp').val(assumps['penetration_ramp']);
      } else {
        $('#id_video_penetration').val(assumps['video_penetration']);
        $('#id_data_penetration').val(assumps['data_penetration']);
        $('#id_voice_penetration').val(assumps['voice_penetration']);
        $('#id_video_arpu').val(assumps['video_arpu']);
        $('#id_data_arpu').val(assumps['data_arpu']);
        $('#id_voice_arpu').val(assumps['voice_arpu']);
        $('#id_video_rev_share').val(assumps['video_rev_share']);
        $('#id_data_rev_share').val(assumps['data_rev_share']);
        $('#id_voice_rev_share').val(assumps['voice_rev_share']);
        $('#id_opex_load').val(assumps['opex_load']);
        $('#id_door_fees').val(assumps['door_fees']);
        $('#id_isp_per_unit').val(assumps['isp_per_unit']);
        $('#id_converter').val(assumps['converter']);
        $('#id_modem').val(assumps['modem']);
        $('#id_emta').val(assumps['emta']);
        $('#id_penetration_ramp').val(assumps['penetration_ramp']);
      }
    }
  });

  subscriberMDU();
}

function subscriberMDU() {
  var unit_ct = $("#id_unit_ct").val();
  var video_pen = $("#id_video_penetration").val();
  var data_pen = $("#id_data_penetration").val();
  var voice_pen = $("#id_voice_penetration").val();
  var video_target = unit_ct * stripFinalPercentFormatWithVal(video_pen)
  var data_target = unit_ct * stripFinalPercentFormatWithVal(data_pen)
  var voice_target = unit_ct * stripFinalPercentFormatWithVal(voice_pen)
  $("#id_video_subscr_target").val(Math.round(video_target));
  $("#id_data_subscr_target").val(Math.round(data_target));
  $("#id_voice_subscr_target").val(Math.round(voice_target));
}

function deleteMDU() {
  var mdu_id = $(this).closest('tr').attr('mdu_id');
  var mdu_name = $(this).closest('tr').find('.property_name').text();
  var message = confirm("Are you sure you want to delete MDU: " + mdu_name + "?");
  if (message == true) {
    $.ajax({
      type: "GET",
      url: '/ajax/delete_mdu/',
      data: {'mdu_id': mdu_id, 'mdu_name': mdu_name},
      dataType: 'json',
      success: function (deleted) {
        var mdu_name = deleted['mdu_name'];
        alert("You succesfully deleted " + mdu_name + "!");
        window.location.reload();
      }
    });
  }
  else {
  }
}
