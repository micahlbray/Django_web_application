function autofillParentBizCaseCalculations(calcs) {
  $('#id_roe_target').val(calcs['roe_target']);
  $('#id_roe_acquired').val(calcs['roe_acquired']);
  $('#id_roe_needed').val(calcs['roe_needed']);
  $('#id_customer_contribution').val(calcs['customer_contribution'])
  $('#id_access_fees_one_time').val(calcs['access_fees_one_time'])
  $('#id_access_fees_monthly').val(calcs['access_fees_monthly'])
  $('#id_row_est_build_cost').val(calcs['row_est_build_cost']);
  $('#id_headend_cost').val(calcs['headend_cost']);
  $('#id_transport_cost').val(calcs['transport_cost']);
  $('#id_private_property_cost').val(calcs['private_property_cost']);
  $('#id_lateral_construct_upfront_pct').val(calcs['lat_construct_upfront_pct']);
  $('#id_smb_arpu').val(calcs['smb_arpu']);
  $('#id_ent_arpu').val(calcs['ent_arpu']);
  $('#id_smb_12mo_pen').val(calcs['smb_12mo_pen']);
  $('#id_smb_36mo_pen').val(calcs['smb_36mo_pen']);
  $('#id_ent_12mo_pen').val(calcs['ent_12mo_pen']);
  $('#id_ent_36mo_pen').val(calcs['ent_36mo_pen']);
  $('#id_fund_bucket').val(calcs['fund_bucket']);
  $('#id_business_capital_pct').val(calcs['business_pct']);
  $('#id_resi_capital_pct').val(calcs['resi_pct']);
  $('#id_smb_qb_ct').val(calcs['smb_qb_ct']);
  $('#id_ent_qb_ct').val(calcs['ent_qb_ct']);
  $('#id_building_ct').val(calcs['building_ct']);
  $('#id_multi_tenant_building_ct').val(calcs['multi_tenant_building_ct']);
  $('#id_dealinhand_ct').val(calcs['dealinhand_ct']);
  $('#id_mdu_ct').val(calcs['mdu_ct']);
  $('#id_datacenter_ct').val(calcs['datacenter_ct']);
  $('#id_row_car_value').val(calcs['ROW_CAR']);
  $('#id_lat_car_value').val(calcs['Lat_CAR']);
  $('#id_total_car_value').val(calcs['Total_CAR']);
  $('#id_irr_pct').val(calcs['IRR']);
  $('#id_irr_pct_less_he_trnsprt').val(calcs['IRR_Less_HE_Trnsprt'])
  $('#id_npv').val(calcs['NPV']);
  $('#id_npv_less_he_trnsprt').val(calcs['NPV_Less_HE_Trnsprt']);
  $('#id_payback_mo').val(calcs['payback_mo']);
  $('#id_passing_cost_per').val(calcs['passing_cost_per']);
  $('#id_additional_osp_lateral_cost_per_connect').val(calcs['lat_cost_per_connect']);
  $('#id_business_max_actual_capital').val(calcs['business_NPV']);
  $('#id_resi_max_actual_capital').val(calcs['resi_NPV']);
}

function getParentBizCaseCalculations(case_status_user_perm) {
  var probuild_id = $('#id_probuild_id').val();
  var approved = $('#id_approved').val();
  var customer_contribution = $("#id_customer_contribution").val();
  var access_fees_one_time = $("#id_access_fees_one_time").val();
  var access_fees_monthly = $("#id_access_fees_monthly").val();
  var row_est_build_cost = $("#id_row_est_build_cost").val();
  var headend_cost = $("#id_headend_cost").val();
  var transport_cost = $("#id_transport_cost").val();
  var private_property_cost = $("#id_private_property_cost").val();
  var lat_construct_upfront_pct = $('#id_lateral_construct_upfront_pct').val()
  var smb_arpu = $("#id_smb_arpu").val();
  var ent_arpu = $("#id_ent_arpu").val();
  var smb_12mo_pen = $("#id_smb_12mo_pen").val();
  var smb_36mo_pen = $("#id_smb_36mo_pen").val();
  var ent_12mo_pen = $("#id_ent_12mo_pen").val();
  var ent_36mo_pen = $("#id_ent_36mo_pen").val();
  $.ajax({
    type: "GET",
    url: '/ajax/calcs_parent_business_case/',
    data: {'probuild_id': probuild_id, 'customer_contribution': customer_contribution,
        'access_fees_one_time': access_fees_one_time, 'access_fees_monthly': access_fees_monthly,
        'row_est_build_cost': row_est_build_cost, 'headend_cost': headend_cost,
        'transport_cost': transport_cost, 'private_property_cost': private_property_cost,
        'lat_construct_upfront_pct': lat_construct_upfront_pct,
        'smb_arpu': smb_arpu, 'ent_arpu': ent_arpu,
        'smb_12mo_pen': smb_12mo_pen, 'smb_36mo_pen': smb_36mo_pen,
        'ent_12mo_pen': ent_12mo_pen, 'ent_36mo_pen': ent_36mo_pen,
        },
    dataType: 'json',
    success: function (calcs) {
      if (approved == 1) {
        addBizCaseCalculationsHelpText(calcs);
        highlightIrrPctApproved();
      } else {
        autofillParentBizCaseCalculations(calcs);
        addBizCaseCalculationsHelpText(calcs);
        highlightIrrPct(calcs);
      }
    }
  });
}
