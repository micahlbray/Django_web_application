////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
///// Building Add Detail
////////////////////////////////////////////////////////////////////////////////
function styleBuildingAddDetail(){
  var lblSearch = $('#id_building_add_detail_table_filter.dataTables_filter');
  lblSearch[0].innerHTML = '<label>Table Search:<input type="search" class=""' +
                        'placeholder="" aria-controls="id_building_add_detail_table">' +
                        '</label>';
}


function getBuildingAddDetail() {
  var probuild_id = $('#id_probuild').val();
  var table = $('#id_building_add_detail_table').DataTable({
      retrieve: true,
      responsive: true,
      paging: true,
      stripeClasses: [],
      lengthChange: true,
      lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
      select: true,
      dom: 'Blfrtip',
      buttons: [
        {
          extend: 'selectAll',
          text: 'Select All Buildings(s)'
        },
        {
          extend: 'selectNone',
          text: 'Deselect All Building(s)'
        }
      ],
      ajax: {
        type: 'GET',
        url: '/ajax/get_building_add_detail/',
        data: {'probuild_id': probuild_id},
        dataType: 'json',
        dataSrc: ''
      },
      rowId: 'data.Record_Id',
      columns: [
          { data: 'Building_Id'},
          { data: 'ParentBuilding_Id' },
          { data: 'Address' },
          { data: 'City' },
          { data: 'State' },
          { data: 'Zip' },
          { data: 'Coax_Color' },
          { data: 'Fiber_Color' },
          { data: 'Building_Type' },
          { data: 'Dwelling_Type' },
          { data: 'ROE_Id' },
          { data: 'ROE_Status' },
          {
            data: 'UnmatchedFlag',
            orderable: false,
            searchable: false,
            visible: false,
          },
          {
            data: 'ServiceableFlag',
            orderable: false,
            searchable: false,
            visible: false,
          },
          {
            data: 'DwellingFlag',
            orderable: false,
            searchable: false,
            visible: false,
          },
          {
            data: 'RoeFlag',
            orderable: false,
            searchable: false,
            visible: false,
          },
          {
            label: 'Edit',
            name: 'edit',
            data: null,
            orderable: false,
            render: function(data, type, full, meta) {
              var link = "location.href='/miBuilds/building/" + data.Record_Id + "/edit/'";
              return '<button id="id_btn_edit_record" class="navBtn" onClick="' + link + '">Edit</button>'
            }
          },
          {
            data: null,
            orderable: false,
            defaultContent: '<button id="id_btn_delete_record" class="delBtn">Delete</button>'
          },
          {
            data: null,
            defaultContent: '',
            orderable: false,
            className: 'select-checkbox',
          },
      ],
      select: {
        style: 'multi',
      },
      createdRow: function(row, data, index) {
        if (data['ServiceableFlag'] == 1) {
          $(row).addClass('flagRow');
        };
        if (data['UnmatchedFlag'] == 1) {
          $(row).addClass('highlightRow');
        }
        if (data['DwellingFlag'] == 1) {
          $('td', row).eq(9).css('backgroundColor', 'orange');
        }
        if (data['RoeFlag'] == 1) {
          $('td', row).eq(10).css('backgroundColor', 'red');
        }
      }
  });

  var table = document.getElementById('id_building_add_detail_table');
  table.style.display = 'block';
  table.style.width = '100%';

}

function loadBuildingAddDetail() {
  getBuildingAddDetail();
  //stylePendingBizCaseDetail();
}

/****************************************************************
--- The below was scrapped for the "createdRow" feature in DataTables
--- I added flags to the stored procedure to key off of
****************************************************************/
function flagBuildingAddDetail() {
  var probuild_id = $('#id_probuild').val();
  //Highlight row without matching Business
  $.ajax({
    type: "GET",
    url: '/ajax/highlight_building_unmatched/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function (unmatched) {
      var unmatchedList = []
      for (var i = 0; i < unmatched['Record_Id'].length; ++i) {
        unmatchedList.push(Number(unmatched['Record_Id'][i]))
      }
      var table = $('#id_building_add_detail_table').DataTable();
      table.rows().every( function() {
        data = this.data();
        record_id = data['Record_Id']
        if ($.inArray(record_id, unmatchedList) != -1) {
          console.log(record_id)
          this.nodes().to$().removeClass("odd")
          this.nodes().to$().removeClass("even")
          this.nodes().to$().addClass("highlightRow")
        }
        console.log(this.node().className);
      });
    }
  });

  //Highlight row with already serviceable building
  $.ajax({
    type: "GET",
    url: '/ajax/flag_building_serviceability/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function (unmatched) {
      var unmatchedList = []
      for (var i = 0; i < unmatched['Record_Id'].length; ++i) {
        unmatchedList.push(Number(unmatched['Record_Id'][i]))
      }
      var table = $('#id_building_add_detail_table').DataTable();
      table.rows().every( function() {
        data = this.data();
        record_id = data['Record_Id']
        if ($.inArray(record_id, unmatchedList) != -1) {
          console.log(record_id)
          this.nodes().to$().removeClass("odd")
          this.nodes().to$().removeClass("even")
          this.nodes().to$().addClass("flagRow")
        }
        console.log(this.node().className);
      });
    }
  });

  //Highlight row with already serviceable building
  $.ajax({
    type: "GET",
    url: '/ajax/flag_building_dwelling_type/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function (unmatched) {
      var unmatchedList = []
      for (var i = 0; i < unmatched['Record_Id'].length; ++i) {
        unmatchedList.push(Number(unmatched['Record_Id'][i]))
      }
      var table = $('#id_building_add_detail_table').DataTable();
      table.cells().every( function() {
        data = this.data();
        console.log(data)
        record_id = data['Record_Id']
        //if ($.inArray(record_id, unmatchedList) != -1) {
          //console.log(record_id)
          //this.nodes().to$().removeClass("odd")
          //this.nodes().to$().removeClass("even")
          //this.nodes().to$().addClass("flagRow")
        //}
        //console.log(this.node().className);
      });
    }
  });
}

