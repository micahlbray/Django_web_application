////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
///// Business Add Detail
////////////////////////////////////////////////////////////////////////////////
function styleBusinessAddDetail(){
  var lblSearch = $('#id_business_add_detail_table_filter.dataTables_filter');
  lblSearch[0].innerHTML = '<label>Table Search:<input type="search" class=""' +
                        'placeholder="" aria-controls="id_business_add_detail_table">' +
                        '</label>';
}


function getBusinessAddDetail() {
  var probuild_id = $('#id_probuild').val();
  var table = $('#id_business_add_detail_table').DataTable({
      retrieve: true,
      responsive: true,
      paging: true,
      lengthChange: true,
      lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
      select: true,
      dom: 'Blfrtip',
      buttons: [
        {
          extend: 'selectAll',
          text: 'Select All Buildings(s)'
        },
        {
          extend: 'selectNone',
          text: 'Deselect All Building(s)'
        }
      ],
      ajax: {
        type: 'GET',
        url: '/ajax/get_business_add_detail/',
        data: {'probuild_id': probuild_id},
        dataType: 'json',
        dataSrc: ''
      },
      rowId: 'data.Record_Id',
      columns: [
          { data: 'Business_Id'},
          { data: 'Building_Id' },
          { data: 'Business_Name' },
          { data: 'Address_1' },
          { data: 'Address_2' },
          { data: 'City' },
          { data: 'State' },
          { data: 'Zip' },
          { data: 'Coax_Color' },
          { data: 'Fiber_Color' },
          { data: 'In_Or_Out' },
          { data: 'Segment' },
          { data: 'Revised_Segment' },
          { data: 'Revised_Segment_Notes' },
          { data: 'ROE_Id' },
          {
            data: 'UnmatchedFlag',
            orderable: false,
            searchable: false,
            visible: false,
          },
          {
            data: 'RoeFlag',
            orderable: false,
            searchable: false,
            visible: false,
          },
          {
            label: 'Edit',
            name: 'edit',
            data: null,
            orderable: false,
            render: function(data, type, full, meta) {
              var link = "location.href='/miBuilds/business/" + data.Record_Id + "/edit/'";
              return '<button id="id_btn_edit_record" class="navBtn" onClick="' + link + '">Edit</button>'
            }
          },
          {
            data: null,
            orderable: false,
            defaultContent: '<button id="id_btn_delete_record" class="delBtn">Delete</button>'
          },
          {
            data: null,
            defaultContent: '',
            orderable: false,
            className: 'select-checkbox',
          },
      ],
      select: {
        style: 'multi',
      },
      createdRow: function(row, data, index) {
        if (data['UnmatchedFlag'] == 1) {
          $(row).addClass('highlightRow');
        }
        if (data['RoeFlag'] == 1) {
          $('td', row).eq(14).css('backgroundColor', 'red');
        }
      }
  });

  var table = document.getElementById('id_business_add_detail_table');
  table.style.display = 'block';
  table.style.width = '100%';

}

function loadBusinessAddDetail() {
  getBusinessAddDetail();
  //stylePendingBizCaseDetail();
}

