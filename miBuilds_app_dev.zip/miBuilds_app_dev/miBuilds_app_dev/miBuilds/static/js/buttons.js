function btnsBizCaseAdd() {
  var form = "id_business_case_add_form"
  var btnType = "submit"
  var saveStyle = "save-button"

  var saveBtn = document.getElementById("id_save_btn")
  saveBtn.type = btnType;
  saveBtn.setAttribute('form', form);
  saveBtn.setAttribute('class', saveStyle);
  saveBtn.name = 'btnSaveBizCase';
  saveBtn.value = 'Save Business Case';
  saveBtn.innerHTML = 'Save Business Case';
}

function btnsBizCaseEdit() {
  var form = "id_business_case_edit_form"
  var btnType = "submit"

  var saveStyle = "save-button"
  var saveBtn = document.getElementById("id_save_btn")
  saveBtn.type = btnType;
  saveBtn.setAttribute('form', form);
  saveBtn.setAttribute('class', saveStyle);
  saveBtn.name = 'btnSaveBizCase';
  saveBtn.value = 'Save Business Case';
  saveBtn.innerHTML = 'Save Business Case';

  var subStyle = "submit-button"
  var subBtn = document.getElementById("id_submit_btn")
  subBtn.type = btnType;
  subBtn.setAttribute('form', form);
  subBtn.setAttribute('class', subStyle);
  subBtn.name = 'btnSubBizCase';
  subBtn.value = 'Submit Business Case';
  subBtn.innerHTML = 'Submit Business Case';

  var apprvStyle = "approve-button"
  var apprvBtn = document.getElementById("id_approve_btn")
  apprvBtn.type = btnType;
  apprvBtn.setAttribute('form', form);
  apprvBtn.setAttribute('class', apprvStyle);
  apprvBtn.name = 'btnApprvBizCase';
  apprvBtn.value = 'Approve Business Case';
  apprvBtn.innerHTML = 'Approve Business Case';

  var cloneStyle = "clone-button"
  var cloneBtn = document.getElementById("id_clone_btn")
  cloneBtn.type = btnType;
  cloneBtn.setAttribute('form', form);
  cloneBtn.setAttribute('class', cloneStyle);
  cloneBtn.name = 'btnCloneBizCase';
  cloneBtn.value = 'Clone Business Case';
  cloneBtn.innerHTML = 'Clone Business Case';

  var childStyle = "child-button"
  var childBtn = document.getElementById("id_child_btn")
  childBtn.type = btnType;
  childBtn.setAttribute('form', form);
  childBtn.setAttribute('class', childStyle);
  childBtn.name = 'btnChildBizCase';
  childBtn.value = 'Create Phased Business Case';
  childBtn.innerHTML = 'Create Phased Business Case';

  var relatedStyle = "related-button"
  var relatedBtn = document.getElementById("id_related_btn")
  // childBtn.type = btnType;
  //childBtn.setAttribute('form', form);
  relatedBtn.setAttribute('class', relatedStyle);
  relatedBtn.name = 'btnRelatedBizCase';
  relatedBtn.value = 'Related Business Case';
  relatedBtn.innerHTML = 'Related Business Case';

  var checkStyle = "check-button"
  var checkBtn = document.getElementById("id_check_btn")
  checkBtn.type = btnType;
  checkBtn.setAttribute('form', form);
  checkBtn.setAttribute('class', checkStyle);
  checkBtn.name = 'btnCheckBizCase';
  checkBtn.value = 'Check Business Case';
  checkBtn.innerHTML = 'Check Business Case';

  var statusStyle = "status-button"
  var statusBtn = document.getElementById("id_status_btn")
  var submitted = $("#id_submitted").val()
  var approved = $("#id_approved").val()

  if (submitted == 1 && approved == '') {
    statusBtn.type = btnType;
    statusBtn.setAttribute('form', form);
    statusBtn.setAttribute('class', statusStyle);
    statusBtn.name = 'btnStatusBizCase';
    statusBtn.value = 'Move To Pending';
    statusBtn.innerHTML = 'Move To Pending';
  } else if (approved == 1) {
    statusBtn.type = btnType;
    statusBtn.setAttribute('form', form);
    statusBtn.setAttribute('class', statusStyle);
    statusBtn.name = 'btnStatusBizCase';
    statusBtn.value = 'Move To Submitted';
    statusBtn.innerHTML = 'Move To Submitted';
  }
}

function buildingAddUpload() {
  var form = "id_building_add_upload_form"
  var saveStyle = "save-button"

  var saveBtn = document.getElementById("id_save_btn")
  saveBtn.type = 'submit';
  saveBtn.setAttribute('form', form);
  saveBtn.setAttribute('class', saveStyle);
  saveBtn.name = 'btnAddBldng';
  saveBtn.value = 'Add Building(s)';
  saveBtn.innerHTML = 'Add Building(s)';
}
