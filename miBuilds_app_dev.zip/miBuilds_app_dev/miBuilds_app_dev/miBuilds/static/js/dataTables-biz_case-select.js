////////////////////////////////////////////////////////////////////////////////
///// Search Business Case Detail
////////////////////////////////////////////////////////////////////////////////
function styleSearchBizCaseDetail(){
  var lblSearch = $('#id_search_business_case_detail_table_filter.dataTables_filter');
  lblSearch[0].innerHTML = '<label>Table Search:<input type="search" class=""' +
                        'placeholder="" aria-controls="id_search_business_case_detail_table">' +
                        '</label>';
}

function getSearchBizCaseDetail(region_id, search_type_id, search_value) {
  var table = $('#id_search_business_case_detail_table').DataTable();
  table.destroy();
  table.clear().draw();

  var table = $('#id_search_business_case_detail_table').DataTable({
      retrieve: true,
      paging: true,
      responsive: true,
      deferRender: true,
      ajax: {
        type: 'GET',
        url: '/ajax/get_search_results_business_case_detail/',
        data: { 
                'region_id': region_id, 
                'search_type_id': search_type_id,
                'search_value': search_value
              },
        dataType: 'json',
        dataSrc: ''
      },
      rowId: 'data.Probuild_Id',
      columns: [
          {
            className: 'details-control',
            width: "20px",
            orderable: false,
            data: null,
            defaultContent: '<button class="plus" id="id_expand_btn">+</button>'
          },
          { data: 'Name'},
          { data: 'Region' },
          { data: 'Status' },
          { data: 'Fund_Bucket' },
          { data: 'CAR_Value' },
          { data: 'Build_Type' },
          { data: 'Transport_Type' },
          { data: 'BDR' },
          { data: 'AddedBy' },
          {
            data: 'AddedOn',
            render: function(data, type, row){
                if(type === "sort" || type === "type"){
                    return data;
                }
                return moment(data).format("MM/DD/YYYY HH:mm A");
            }
          },
          {
            label: 'View',
            name: 'view',
            data: null,
            orderable: false,
            render: function(data, type, full, meta) {
              var link = "location.href='/miBuilds/business_case/" + data.Probuild_Id + "/edit/'";
              return '<button id="id_btn_view_record" class="navBtn" onClick="' + link + '">View</button>'
            }
          },
          {
            data: null,
            orderable: false,
            defaultContent: '<button id="id_btn_delete_record" class="delBtn">Delete</button>'
          },
          {
            label: 'Summary',
            name: 'summary',
            data: null,
            orderable: false,
            render: function(data, type, full, meta) {
              var link = "location.href='/miBuilds/business_case/" + data.Probuild_Id + "/export/construction_business_case_summary/xlsx/'";
              return '<button id="id_btn_summary_record" class="navBtn" onClick="' + link + '">Summary</button>'
            } 
          },
      ],
      order: [[10, 'desc']],
  });

  table.ajax.reload();

}

function loadSearchBizCaseDetail() {
  getSearchBizCaseDetail();
  //stylePendingBizCaseDetail();
}


function addSearchBizCaseChildRows(row, probuild_id) {
  $.ajax({
    type: "GET",
    url: '/ajax/get_related_business_case_detail/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    complete: function (data) {
      var data = JSON.parse(data.responseText);
      var thead = '',  tbody = '';
        thead += '<th>View</th>' + '<th>Name</th>' + '<th>Relationship</th>';
        $.each(data, function (i, d) {
            var link = "location.href='/miBuilds/business_case/" + d.Probuild_Id + "/edit/'";
            var view = '<button id="id_btn_view_record" class="navBtn" onClick="' + link + '">View</button>'
            tbody += '<tr><td>' + view + '</td><td>' +  d.Name + '</td><td>' + d.Relationship + '</td></tr>';
        });
      result = '<table>' + thead + tbody + '</table>';
      row.child( $(result) ).show();
    },
    error: function () {
      $('#output').html('Bummer: there was an error!');
    }
  });
}

////////////////////////////////////////////////////////////////////////////////
///// Pending Business Case Detail
////////////////////////////////////////////////////////////////////////////////
function stylePendingBizCaseDetail(){
  var lblSearch = $('#id_pending_business_case_detail_table_filter.dataTables_filter');
  lblSearch[0].innerHTML = '<label>Table Search:<input type="search" class=""' +
                        'placeholder="" aria-controls="id_pending_business_case_detail_table">' +
                        '</label>';
}

function getPendingBizCaseDetail() {
  var region_id = $('#id_user_region_id').val()
  var table = $('#id_pending_business_case_detail_table').DataTable({
      retrieve: true,
      paging: true,
      responsive: true,
      deferRender: true,
      ajax: {
        type: 'GET',
        url: '/ajax/get_pending_business_case_detail/',
        data: {'region_id': region_id},
        dataType: 'json',
        dataSrc: ''
      },
      rowId: 'data.Probuild_Id',
      buttons: [
        'selectAll',
        'selectNone'
      ],
      language: {
        buttons: {
            selectAll: "Select all items",
            selectNone: "Select none"
        }
      },
      columns: [
          {
            className: 'details-control',
            width: "20px",
            orderable: false,
            data: null,
            defaultContent: '<button class="plus" id="id_expand_btn">+</button>'
          },
          { data: 'Name'},
          { data: 'Region' },
          { data: 'Fund_Bucket' },
          { data: 'CAR_Value' },
          { 
            data: null, 
            render: function(data, type, row){
              if (row.IRR_Pct_Less_HE_Trnsprt) {
                return (row.IRR_Pct_Less_HE_Trnsprt * 100).toFixed(2) + '%';
              } else {
                return '';
              };
            },
          },
          { data: 'Build_Type' },
          { data: 'Transport_Type' },
          { data: 'BDR' },
          { data: 'AddedBy' },
          {
            data: 'AddedOn',
            render: function(data, type, row){
                if(type === "sort" || type === "type"){
                    return data;
                }
                return moment(data).format("MM/DD/YYYY HH:mm A");
            }
          },
          {
            label: 'View',
            name: 'view',
            data: null,
            orderable: false,
            render: function(data, type, full, meta) {
              var link = "location.href='/miBuilds/business_case/" + data.Probuild_Id + "/edit/'";
              return '<button id="id_btn_view_record" class="navBtn" onClick="' + link + '">View</button>'
            }
          },
          {
            data: null,
            orderable: false,
            defaultContent: '<button id="id_btn_delete_record" class="delBtn">Delete</button>'
          },
          {
            label: 'Summary',
            name: 'summary',
            data: null,
            orderable: false,
            render: function(data, type, full, meta) {
              var link = "location.href='/miBuilds/business_case/" + data.Probuild_Id + "/export/construction_business_case_summary/xlsx/'";
              return '<button id="id_btn_summary_record" class="navBtn" onClick="' + link + '">Summary</button>'
            }
          },
      ],
      select: {
            style:    'os',
            selector: 'td:first-child'
        },
      order: [[10, 'desc']],
      createdRow: function(row, data, index) {
        if (data['IRR_Pct_Less_HE_Trnsprt'] == '') {
          // do nothing
        } else if (data['IRR_Pct_Less_HE_Trnsprt'] >= 0.15) {
          $('td', row).eq(5).css({'color': 'white', 'backgroundColor': 'green'});
        } else if (data['IRR_Pct_Less_HE_Trnsprt'] < 0.15) {
          $('td', row).eq(5).css({'color': 'white', 'backgroundColor': 'red'});
        } else {
          // do nothing
        };
      },
  });

  //var table = document.getElementById('id_pending_business_case_detail_table');
  //table.style.display = 'block';
  //table.style.width = '100%';

}

function loadPendingBizCaseDetail() {
  getPendingBizCaseDetail();
  //stylePendingBizCaseDetail();
}


function addPendingBizCaseChildRows(row, probuild_id) {
  $.ajax({
    type: "GET",
    url: '/ajax/get_related_business_case_detail/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    complete: function (data) {
      var data = JSON.parse(data.responseText);
      var thead = '',  tbody = '';
        //for (var key in data[0]) {
        //    thead += '<th>' + key + '</th>';
        //}
        thead += '<th>View</th>' + '<th>Name</th>' + '<th>Relationship</th>';
        $.each(data, function (i, d) {
            var link = "location.href='/miBuilds/business_case/" + d.Probuild_Id + "/edit/'";
            var view = '<button id="id_btn_view_record" class="navBtn" onClick="' + link + '">View</button>'
            tbody += '<tr><td>' + view + '</td><td>' +  d.Name + '</td><td>' + d.Relationship + '</td></tr>';
        });
      result = '<table>' + thead + tbody + '</table>';
      row.child( $(result) ).show();
    },
    error: function () {
      $('#output').html('Bummer: there was an error!');
    }
  });
}

////////////////////////////////////////////////////////////////////////////////
///// Submitted Business Case Detail
////////////////////////////////////////////////////////////////////////////////
function styleSubmittedBizCaseDetail(){
  var lblSearch = $('#id_submitted_business_case_detail_table_filter.dataTables_filter');
  lblSearch[0].innerHTML = '<label>Table Search:<input type="search" class=""' +
                        'placeholder="" aria-controls="id_submitted_business_case_detail_table">' +
                        '</label>';
}


function getSubmittedBizCaseDetail() {
  var region_id = $('#id_user_region_id').val()
  var table = $('#id_submitted_business_case_detail_table').DataTable({
      retrieve: true,
      paging: true,
      responsive: true,
      ajax: {
        type: 'GET',
        url: '/ajax/get_submitted_business_case_detail/',
        data: {'region_id': region_id},
        dataType: 'json',
        dataSrc: ''
      },
      rowId: 'data.Probuild_Id',
      columns: [
          {
            className: 'details-control',
            width: "20px",
            orderable: false,
            data: null,
            defaultContent: '<button class="plus" id="id_expand_btn">+</button>'
          },
          { data: 'Name'},
          { data: 'Region' },
          { data: 'Fund_Bucket' },
          { data: 'CAR_Value' },
          { 
            data: null, 
            render: function(data, type, row){
              if (row.IRR_Pct_Less_HE_Trnsprt) {
                return (row.IRR_Pct_Less_HE_Trnsprt * 100).toFixed(2) + '%';
              } else {
                return '';
              };
            },
          },
          { data: 'Build_Type' },
          { data: 'Transport_Type' },
          { data: 'BDR' },
          { data: 'SubmittedBy' },
          {
            data: 'SubmittedOn',
            render: function(data, type, row){
                if(type === "sort" || type === "type"){
                    return data;
                }
                return moment(data).format("MM/DD/YYYY HH:mm A");
            }
          },
          {
            label: 'View',
            name: 'view',
            data: null,
            orderable: false,
            render: function(data, type, full, meta) {
              var link = "location.href='/miBuilds/business_case/" + data.Probuild_Id + "/edit/'";
              return '<button id="id_btn_view_record" class="navBtn" onClick="' + link + '">View</button>'
            }
          },
          {
            orderable: false,
            data: null,
            defaultContent: '<button id="id_btn_delete_record" class="delBtn">Delete</button>'
          },
          {
            label: 'Summary',
            name: 'summary',
            data: null,
            orderable: false,
            render: function(data, type, full, meta) {
              var link = "location.href='/miBuilds/business_case/" + data.Probuild_Id + "/export/construction_business_case_summary/xlsx/'";
              return '<button id="id_btn_summary_record" class="navBtn" onClick="' + link + '">Summary</button>'
            }
          },
      ],
      order: [[9, 'desc']],
      createdRow: function(row, data, index) {
        if (data['IRR_Pct_Less_HE_Trnsprt'] == '') {
          // do nothing
        } else if (data['IRR_Pct_Less_HE_Trnsprt'] >= 0.15) {
          $('td', row).eq(5).css({'color': 'white', 'backgroundColor': 'green'});
        } else if (data['IRR_Pct_Less_HE_Trnsprt'] < 0.15) {
          $('td', row).eq(5).css({'color': 'white', 'backgroundColor': 'red'});
        } else {
          // do nothing
        };
      },
  });

  //var table = document.getElementById('id_submitted_business_case_detail_table');
  //table.style.display = 'block';
  //table.style.width = '100%';

}

function loadSubmittedBizCaseDetail() {
  getSubmittedBizCaseDetail();
  //styleSubmittedBizCaseDetail();
}

function addSubmittedBizCaseChildRows(row, account_number) {
  $.ajax({
    type: "GET",
    url: '/ajax/get_adm_account_detail_child/',
    data: {'account_number': account_number},
    dataType: 'json',
    complete: function (data) {
      var data = JSON.parse(data.responseText);
      var thead = '',  tbody = '';
        for (var key in data[0]) {
            thead += '<th>' + key + '</th>';
        }
        $.each(data, function (i, d) {
            tbody += '<tr><td>' + d.DATA_MRC + '</td><td>' + d.VIDEO_MRC + '</td></tr>';
        });
      result = '<table>' + thead + tbody + '</table>';
      row.child( $(result) ).show();
    },
    error: function () {
      $('#output').html('Bummer: there was an error!');
    }
  });
}
////////////////////////////////////////////////////////////////////////////////
///// Approved Business Case Detail
////////////////////////////////////////////////////////////////////////////////
function styleApprovedBizCaseDetail(){
  var lblSearch = $('#id_approved_business_case_detail_table_filter.dataTables_filter');
  lblSearch[0].innerHTML = '<label>Table Search:<input type="search" class=""' +
                        'placeholder="" aria-controls="id_adm_account_detail_table">' +
                        '</label>';
}


function getApprovedBizCaseDetail() {
  var region_id = $('#id_user_region_id').val()
  var table = $('#id_approved_business_case_detail_table').DataTable({
      retrieve: true,
      paging: true,
      responsive: true,
      deferRender: true,
      ajax: {
        type: 'GET',
        url: '/ajax/get_approved_business_case_detail/',
        data: {'region_id': region_id},
        dataType: 'json',
        dataSrc: ''
      },
      rowId: 'data.Probuild_Id',
      columns: [
          {
            className:'details-control',
            width: "20px",
            orderable: false,
            data: null,
            defaultContent: '<button class="plus" id="id_expand_btn">+</button>'
          },
          { data: 'Name'},
          { data: 'Region' },
          { data: 'Fund_Bucket' },
          { data: 'CAR_Value' },
          { 
            data: null, 
            render: function(data, type, row){
              if (row.IRR_Pct_Less_HE_Trnsprt) {
                return (row.IRR_Pct_Less_HE_Trnsprt * 100).toFixed(2) + '%';
              } else {
                return '';
              };
            },
          },
          { data: 'Build_Type' },
          { data: 'Transport_Type' },
          { data: 'BDR' },
          { data: 'ApprovedBy' },
          {
            data: 'ApprovedOn',
            render: function(data, type, row){
                if(type === "sort" || type === "type"){
                    return data;
                }
                return moment(data).format("MM/DD/YYYY HH:mm A");
            }
          },
          {
            label: 'View',
            name: 'view',
            data: null,
            orderable: false,
            render: function(data, type, full, meta) {
              var link = "location.href='/miBuilds/business_case/" + data.Probuild_Id + "/edit/'";
              return '<button id="id_btn_view_record" class="navBtn" onClick="' + link + '">View</button>'
            }
          },
          {
            orderable: false,
            data: null,
            defaultContent: '<button id="id_btn_delete_record" class="delBtn">Delete</button>'
          },
          {
            label: 'Summary',
            name: 'summary',
            data: null,
            orderable: false,
            render: function(data, type, full, meta) {
              var link = "location.href='/miBuilds/business_case/" + data.Probuild_Id + "/export/construction_business_case_summary/xlsx/'";
              return '<button id="id_btn_summary_record" class="navBtn" onClick="' + link + '">Summary</button>'
            }
          },
      ],
      order: [[9, 'desc']],
      createdRow: function(row, data, index) {
        if (data['IRR_Pct_Less_HE_Trnsprt'] == '') {
          // do nothing
        } else if (data['IRR_Pct_Less_HE_Trnsprt'] >= 0.15) {
          $('td', row).eq(5).css({'color': 'white', 'backgroundColor': 'green'});
        } else if (data['IRR_Pct_Less_HE_Trnsprt'] < 0.15) {
          $('td', row).eq(5).css({'color': 'white', 'backgroundColor': 'red'});
        } else {
          // do nothing
        };
      },
  });

  //var table = document.getElementById('id_approved_business_case_detail_table');
  //table.style.display = 'block';
  //table.style.width = '100%';
  
}

function loadApprovedBizCaseDetail() {
  getApprovedBizCaseDetail();
  //styleApprovedBizCaseDetail();
}

function addApprovedBizCaseChildRows(row, probuild_id) {
  $.ajax({
    type: "GET",
    url: '/ajax/get_related_business_case_detail/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    complete: function (data) {
      var data = JSON.parse(data.responseText);
      var thead = '',  tbody = '';
        for (var key in data[0]) {
            thead += '<th>' + key + '</th>';
        }
        $.each(data, function (i, d) {
            tbody += '<tr><td>' + d.Name + '</td><td>' + d.Relationship  + '</td></tr>';
        });
      result = '<table>' + thead + tbody + '</table>';
      row.child( $(result) ).show();
    },
    error: function () {
      $('#output').html('Bummer: there was an error!');
    }
  });
}

