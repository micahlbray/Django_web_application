var btnView = document.getElementById('id_related_btn');
var modalRelated = document.getElementById('id_related_business_case_table_wrapper');
var btnClose = document.getElementById('id_related_modal_close_btn');

// When the user clicks on the button, open the modal
btnView.onclick = function() {
  var id = $('#id_probuild_id').val()
  if (id) {
    modalRelated.style.display = "block";
    getRelatedBizCaseDetail();
  } else {
    alert("Something isn't quite right.")
  }
}

// When the user clicks on close (x), close the modal
btnClose.onclick = function() {
  modalRelated.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modalRelated) {
      modalRelated.style.display = "none";
  }
}

////////////////////////////////////////////////////////////////////////////////
///// Related Business Case Detail
////////////////////////////////////////////////////////////////////////////////
function styleRelatedBizCaseDetail(){
  var lblSearch = $('#id_related_business_case_detail_table.dataTables_filter');
  lblSearch[0].innerHTML = '<label>Table Search:<input type="search" class=""' +
                        'placeholder="" aria-controls="id_pending_business_case_detail_table">' +
                        '</label>';
}

function getRelatedBizCaseDetail() {
  var probuild_id = $('#id_probuild_id').val()
  var table = $('#id_related_business_case_table_detail').DataTable({
      retrieve: true,
      paging: true,
      responsive: true,
      lengthChange: false,
      searching: false,
      info: false,
      ajax: {
        type: 'GET',
        url: '/ajax/get_related_business_case_detail/',
        data: {'probuild_id': probuild_id},
        dataType: 'json',
        dataSrc: ''
      },
      rowId: 'data.Probuild_Id',
      columns: [
          {
            label: 'View',
            name: 'view',
            data: null,
            orderable: false,
            render: function(data, type, full, meta) {
              var link = "location.href='/miBuilds/business_case/" + data.Probuild_Id + "/edit/'";
              return '<button id="id_btn_view_record" class="navBtn" onClick="' + link + '">View</button>'
            }
          },
          { data: 'Name'},
          { data: 'Relationship' },
      ],
  });

  var table = document.getElementById('id_related_business_case_table_detail');
  table.style.display = 'block';

}