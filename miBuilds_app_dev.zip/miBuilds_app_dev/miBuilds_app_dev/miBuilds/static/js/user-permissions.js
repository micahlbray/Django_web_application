function getBizCaseDeleteUserPermissionsOLD(probuild_id, probuild_name) {
  //var addedby = $(this).closest("tr").attr('addedby')
  var probuild_id = $(this).closest("tr").attr('probuild_id')
  var probuild_name = $(this).closest("tr").find('.name').text()
  var message = confirm("Are you sure you want to delete " + probuild_name + "?");
  if (message == true) {
    $.ajax({
      type: "GET",
      url: '/ajax/get_business_case_status_and_user_group_permission/',
      data: {'probuild_id': probuild_id},
      dataType: 'json',
      success: function (case_status_user_perm) {
        checkBizCaseDeletePermissions(case_status_user_perm,
                                      probuild_id, probuild_name);
      }
    });
  } else {
    alert("You have decided not to delete " + probuild_name + ".")
  }
}

function getBizCaseDeleteUserPermissions(probuild_id, probuild_name) {
  //var addedby = $(this).closest("tr").attr('addedby')
  //var probuild_id = $(this).closest("tr").attr('probuild_id')
  //var probuild_name = $(this).closest("tr").find('.name').text()
  var message = confirm("Are you sure you want to delete " + probuild_name + "?");
  if (message == true) {
    $.ajax({
      type: "GET",
      url: '/ajax/get_business_case_status_and_user_group_permission/',
      data: {'probuild_id': probuild_id},
      dataType: 'json',
      success: function (case_status_user_perm) {
        checkBizCaseDeletePermissions(case_status_user_perm,
                                      probuild_id, probuild_name);
      }
    });
  } else {
    alert("You have decided not to delete " + probuild_name + ".")
  }
}

function checkBizCaseDeletePermissions(case_status_user_perm,
                                        probuild_id, probuild_name) {
  var addedby = case_status_user_perm['AddedBy']
  var username = case_status_user_perm['NT_Login']
  var approved = case_status_user_perm['Approved']
  var canDeleteOnlyCreated = case_status_user_perm['CanDeleteOnlyCreated']
  var canDeleteAllRegion = case_status_user_perm['CanDeleteAllRegion']
  var canDeleteAllDivision = case_status_user_perm['CanDeleteAllDivision']
  // if approved then need additional criteria
  // else allow delete unless can only delete created
  // then make sure the user created the case
  if (approved == 1) {
    // if approved then need to be able to delete within entire Division
    // else give them an authorization alert
    if (canDeleteAllDivision == 1) {
      deleteBizCase(probuild_id, probuild_name)
    } else {
      alert("You are unable to delete an 'Approved' build.")
    }
  } else {
    if (canDeleteAllDivision == 1 || canDeleteAllRegion == 1) {
      deleteBizCase(probuild_id, probuild_name)
    } else if (canDeleteOnlyCreated == 1) {
      if (username == addedby) {
        deleteBizCase(probuild_id, probuild_name)
      } else {
        alert("You are unable to delete a build you did not add.")
      }
    }
  }
}

function deleteBizCase(probuild_id, probuild_name) {
  $.ajax({
    type: "GET",
    url: '/ajax/delete_business_case/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function () {
      alert("You succesfully deleted " + probuild_name + "!");
      window.location.reload();
    }
  });
}

function getBizCaseUserPermissions() {
  var probuild_id = $('#id_probuild').val();
  $.ajax({
    type: "GET",
    url: '/ajax/get_business_case_status_and_user_group_permission/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function (case_status_user_perm) {
      showBizCaseButtons(case_status_user_perm);
      var parent = case_status_user_perm['Parent']
      if( parent == 1 ) {
        getParentBizCaseCalculations(case_status_user_perm);
      } else {
        getBizCaseCalculations(case_status_user_perm);
      }

    }
  });
}

function showBizCaseButtons(case_status_user_perm) {
  var buttons = document.getElementsByClassName("content__tab-nav-buttons-wrapper")
  var submitted = case_status_user_perm['Submitted']
  var approved = case_status_user_perm['Approved']
  var parent = case_status_user_perm['Parent']
  var cloned = case_status_user_perm['Cloned']
  var child = case_status_user_perm['Child']
  var canSubmit = case_status_user_perm['CanSubmit']
  var canApprove = case_status_user_perm['CanApprove']
  var canViewOnly = case_status_user_perm['CanViewOnly']
  var canEditSubmitted = case_status_user_perm['CanEditSubmitted']
  var canEditApproved = case_status_user_perm['CanEditApproved']
  var carMax = case_status_user_perm['CAR_MaxApproval']
  var carValue = case_status_user_perm['CAR_Value']
  //var carValue = stripFinalDollarFormatWithVal($('#id_total_car_value').val())

  if(canEditSubmitted == 0 && canEditApproved == 0) {
    ///
  } else if (approved == 1) {
    if (canEditApproved == 1) {
      if (carValue < carMax) {
        document.getElementById('id_save_btn').style.display='inline';
        document.getElementById('id_related_btn').style.display='inline';
        document.getElementById('id_status_btn').style.display='inline';
      } else {
        document.getElementById('id_save_btn').style.display='inline';
        document.getElementById('id_related_btn').style.display='inline';
      }
    }
  } else if (approved == 0) {
    // handle cases that aren't approved
    if(submitted == 1) {
      if (canApprove == 1) {
        if (carValue < carMax) {
          document.getElementById('id_save_btn').style.display='inline';
          document.getElementById('id_related_btn').style.display='inline';
          document.getElementById('id_check_btn').style.display='inline';
          document.getElementById('id_status_btn').style.display='inline';
          if (parent != 1) {
            document.getElementById('id_approve_btn').style.display='inline';
          } else {
            /// do nothing
          }
        } else {
          document.getElementById('id_save_btn').style.display='inline';
          document.getElementById('id_related_btn').style.display='inline';
          document.getElementById('id_check_btn').style.display='inline';
          document.getElementById('id_status_btn').style.display='inline';
          //document.getElementById('id_approve_btn').style.visibility = 'hidden';
        }
      } else {
        document.getElementById('id_save_btn').style.display='inline';
        document.getElementById('id_related_btn').style.display='inline';
        document.getElementById('id_check_btn').style.display='inline';
        document.getElementById('id_status_btn').style.display='inline';
      }
    } else if (submitted == 0) {
      document.getElementById('id_save_btn').style.display='inline';
      document.getElementById('id_submit_btn').style.display='inline';
      document.getElementById('id_related_btn').style.display='inline';
      document.getElementById('id_clone_btn').style.display='inline';
      document.getElementById('id_check_btn').style.display='inline';
      if (parent > 0) {
        document.getElementById('id_related_btn').style.display='inline';
        document.getElementById('id_child_btn').style.display='inline';
      } else {
        /// do not display
      }
    }
  }
}

function getBuildingAddUserPermissions() {
  var probuild_id = $('#id_probuild').val();
  $.ajax({
    type: "GET",
    url: '/ajax/get_business_case_status_and_user_group_permission/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function (case_status_user_perm) {
      showBuildingAddButtons(case_status_user_perm);
    }
  });
}

function showBuildingAddButtons(case_status_user_perm) {
  var submitted = case_status_user_perm['Submitted']
  var approved = case_status_user_perm['Approved']
  var canSubmit = case_status_user_perm['CanSubmit']
  var canApprove = case_status_user_perm['CanApprove']
  var canViewOnly = case_status_user_perm['CanViewOnly']
  var canEditSubmitted = case_status_user_perm['CanEditSubmitted']
  var canEditApproved = case_status_user_perm['CanEditApproved']
  if ($('#id_building_add_detail_table').length >=1) {
    var navBtns = document.getElementById('id_building_add_detail_table').getElementsByClassName('navBtn')
  } else if ($('#id_business_add_detail_table'.length >=1)) {
    var navBtns = document.getElementById('id_business_add_detail_table').getElementsByClassName('navBtn')
  }
  var delBtns = document.getElementsByClassName('delBtn')
  var chkBoxes = document.getElementsByClassName('chkBox')
  if (canViewOnly == 1) {
    //document.getElementById('id_biz_case_edit_btn').style.display = 'inline-block';
  }
  else if (approved == 1) {
    //document.getElementById('id_biz_case_edit_btn').style.display = 'inline-block';
    if (canEditApproved == 1) {
      document.getElementById('id_submit_btn').style.display = 'inline-block';
      document.getElementById('id_upload_bldg_btn').style.display = 'inline-block';
      document.getElementById('id_upload_greenfld_btn').style.display = 'inline-block';
      //document.getElementById('id_biz_case_edit_btn').style.display = 'inline-block';
      document.getElementById('id_delete_selection_btn').style.visibility='visible';
      for (var i = 0; i < navBtns.length; i++){
        navBtns[i].style.visibility='visible';
      }
      for (var i = 0; i < delBtns.length; i++){
        delBtns[i].style.visibility='visible';
      }
      for (var i = 0; i < chkBoxes.length; i++){
        chkBoxes[i].style.visibility='visible';
      }
    }
  } else if (approved == 0) {
    //document.getElementById('id_biz_case_edit_btn').style.display = 'inline-block';
    if(submitted == 1) {
      if (canEditSubmitted == 1) {
        document.getElementById('id_submit_btn').style.display = 'inline-block';
        document.getElementById('id_upload_bldg_btn').style.display = 'inline-block';
        document.getElementById('id_upload_greenfld_btn').style.display = 'inline-block';
        //document.getElementById('id_biz_case_edit_btn').style.display = 'inline-block';
        document.getElementById('id_delete_selection_btn').style.visibility='visible';
        for (var i = 0; i < navBtns.length; i++){
          navBtns[i].style.visibility='visible';
        }
        for (var i = 0; i < delBtns.length; i++){
          delBtns[i].style.visibility='visible';
        }
        for (var i = 0; i < chkBoxes.length; i++){
          chkBoxes[i].style.visibility='visible';
        }
      } else {
        document.getElementById('id_biz_case_edit_btn').style.display = 'inline-block';
      }
    } else if (submitted == 0) {
      document.getElementById('id_submit_btn').style.display = 'inline-block';
      document.getElementById('id_upload_bldg_btn').style.display = 'inline-block';
      document.getElementById('id_upload_greenfld_btn').style.display = 'inline-block';
      //document.getElementById('id_biz_case_edit_btn').style.display = 'inline-block';
      document.getElementById('id_delete_selection_btn').style.visibility='visible';
      for (var i = 0; i < navBtns.length; i++){
        navBtns[i].style.visibility='visible';
      }
      for (var i = 0; i < delBtns.length; i++){
        delBtns[i].style.visibility='visible';
      }
      for (var i = 0; i < chkBoxes.length; i++){
        chkBoxes[i].style.visibility='visible';
      }
    }
  }
}

function getBusinessAddUserPermissions() {
  var probuild_id = $('#id_probuild').val();
  $.ajax({
    type: "GET",
    url: '/ajax/get_business_case_status_and_user_group_permission/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function (case_status_user_perm) {
      showBusinessAddButtons(case_status_user_perm);
    }
  });
}

function showBusinessAddButtons(case_status_user_perm) {
  var submitted = case_status_user_perm['Submitted']
  var approved = case_status_user_perm['Approved']
  var canSubmit = case_status_user_perm['CanSubmit']
  var canApprove = case_status_user_perm['CanApprove']
  var canViewOnly = case_status_user_perm['CanViewOnly']
  var canEditSubmitted = case_status_user_perm['CanEditSubmitted']
  var canEditApproved = case_status_user_perm['CanEditApproved']
  if ($('#id_business_add_detail_table').length >=1) {
    var navBtns = document.getElementById('id_business_add_detail_table').getElementsByClassName('navBtn')
  } else if ($('#id_business_add_detail_table'.length >=1)) {
    var navBtns = document.getElementById('id_business_add_detail_table').getElementsByClassName('navBtn')
  }
  var delBtns = document.getElementsByClassName('delBtn')
  var chkBoxes = document.getElementsByClassName('chkBox')
  if (canViewOnly == 1) {
    document.getElementById('id_biz_case_edit_btn').style.display = 'inline-block';
  }
  else if (approved == 1) {
    document.getElementById('id_biz_case_edit_btn').style.display = 'inline-block';
    if (canEditApproved == 1) {
      document.getElementById('id_submit_btn').style.display = 'inline-block';
      document.getElementById('id_upload_biz_btn').style.display = 'inline-block';
      document.getElementById('id_upload_greenfld_btn').style.display = 'inline-block';
      document.getElementById('id_biz_case_edit_btn').style.display = 'inline-block';
      document.getElementById('id_delete_selection_btn').style.visibility='visible';
      for (var i = 0; i < navBtns.length; i++){
        navBtns[i].style.visibility='visible';
      }
      for (var i = 0; i < delBtns.length; i++){
        delBtns[i].style.visibility='visible';
      }
      for (var i = 0; i < chkBoxes.length; i++){
        chkBoxes[i].style.visibility='visible';
      }
    }
  } else if (approved == 0) {
    document.getElementById('id_biz_case_edit_btn').style.display = 'inline-block';
    if(submitted == 1) {
      if (canEditSubmitted == 1) {
        document.getElementById('id_submit_btn').style.display = 'inline-block';
        document.getElementById('id_upload_biz_btn').style.display = 'inline-block';
        document.getElementById('id_upload_greenfld_btn').style.display = 'inline-block';
        document.getElementById('id_biz_case_edit_btn').style.display = 'inline-block';
        document.getElementById('id_delete_selection_btn').style.visibility='visible';
        for (var i = 0; i < navBtns.length; i++){
          navBtns[i].style.visibility='visible';
        }
        for (var i = 0; i < delBtns.length; i++){
          delBtns[i].style.visibility='visible';
        }
        for (var i = 0; i < chkBoxes.length; i++){
          chkBoxes[i].style.visibility='visible';
        }
      } else {
        document.getElementById('id_biz_case_edit_btn').style.display = 'inline-block';
      }
    } else if (submitted == 0) {
      document.getElementById('id_submit_btn').style.display = 'inline-block';
      document.getElementById('id_upload_biz_btn').style.display = 'inline-block';
      document.getElementById('id_upload_greenfld_btn').style.display = 'inline-block';
      document.getElementById('id_biz_case_edit_btn').style.display = 'inline-block';
      document.getElementById('id_delete_selection_btn').style.visibility='visible';
      for (var i = 0; i < navBtns.length; i++){
        navBtns[i].style.visibility='visible';
      }
      for (var i = 0; i < delBtns.length; i++){
        delBtns[i].style.visibility='visible';
      }
      for (var i = 0; i < chkBoxes.length; i++){
        chkBoxes[i].style.visibility='visible';
      }
    }
  }
}

function getBuildingBusinessEditUserPermissions() {
  var probuild_id = $('#id_probuild').val();
  $.ajax({
    type: "GET",
    url: '/ajax/get_business_case_status_and_user_group_permission/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function (case_status_user_perm) {
      showBuildingBusinessEditButtons(case_status_user_perm);
    }
  });
}

function showBuildingBusinessEditButtons(case_status_user_perm) {
  var submitted = case_status_user_perm['Submitted']
  var approved = case_status_user_perm['Approved']
  var canSubmit = case_status_user_perm['CanSubmit']
  var canApprove = case_status_user_perm['CanApprove']
  var canViewOnly = case_status_user_perm['CanViewOnly']
  var canEditSubmitted = case_status_user_perm['CanEditSubmitted']
  var canEditApproved = case_status_user_perm['CanEditApproved']
  var navBtns = document.getElementsByClassName('navBtn')
  if (canViewOnly == 1) {
    //document.getElementById('id_biz_case_edit_btn').style.display = 'inline';
  }
  else if (approved == 1) {
    //document.getElementById('id_biz_case_edit_btn').style.display = 'inline';
    if (canEditApproved == 1) {
      document.getElementById('id_submit_btn').style.display = 'block';
      for (var i = 0; i < navBtns.length; i++){
        navBtns[i].style.visibility='visible';
      }
    }
  } else if (approved == 0) {
    for (var i = 0; i < navBtns.length; i++){
      navBtns[i].style.visibility='visible';
    }
    if(submitted == 1) {
      if (canEditSubmitted == 1) {
        document.getElementById('id_submit_btn').style.display = 'block';
        for (var i = 0; i < navBtns.length; i++){
          navBtns[i].style.visibility='visible';
        }
      } else {
        for (var i = 0; i < navBtns.length; i++){
          navBtns[i].style.visibility='visible';
        }
      }
    } else if (submitted == 0) {
      document.getElementById('id_submit_btn').style.display = 'block';
      for (var i = 0; i < navBtns.length; i++){
        navBtns[i].style.visibility='visible';
      }
    }
  }
}

function getOtherAddUserPermissions() {
  var probuild_id = $('#id_probuild').val();
  $.ajax({
    type: "GET",
    url: '/ajax/get_business_case_status_and_user_group_permission/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function (case_status_user_perm) {
      showOtherAddButtons(case_status_user_perm);
    }
  });
}

function showOtherAddButtons(case_status_user_perm) {
  var submitted = case_status_user_perm['Submitted']
  var approved = case_status_user_perm['Approved']
  var canSubmit = case_status_user_perm['CanSubmit']
  var canApprove = case_status_user_perm['CanApprove']
  var canViewOnly = case_status_user_perm['CanViewOnly']
  var canEditSubmitted = case_status_user_perm['CanEditSubmitted']
  var canEditApproved = case_status_user_perm['CanEditApproved']
  var navBtns = document.getElementsByClassName('navBtn')
  var delBtns = document.getElementsByClassName('delBtn')
  if (canViewOnly == 1) {
    document.getElementById('id_biz_case_edit_btn').style.visibility = 'visible';
  }
  else if (approved == 1) {
    document.getElementById('id_biz_case_edit_btn').style.visibility = 'visible';
    if (canEditApproved == 1) {
      document.getElementById('id_submit_btn').style.display = 'block';
      for (var i = 0; i < navBtns.length; i++){
        navBtns[i].style.visibility='visible';
      }
      for (var i = 0; i < delBtns.length; i++){
        delBtns[i].style.visibility='visible';
      }
    }
  } else if (approved == 0) {
    for (var i = 0; i < navBtns.length; i++){
      navBtns[i].style.visibility='visible';
    }
    if(submitted == 1) {
      if (canEditSubmitted == 1) {
        document.getElementById('id_submit_btn').style.display = 'block';
        for (var i = 0; i < navBtns.length; i++){
          navBtns[i].style.visibility='visible';
        }
        for (var i = 0; i < delBtns.length; i++){
          delBtns[i].style.visibility='visible';
        }
      } else {
        document.getElementById('id_biz_case_edit_btn').style.visibility = 'visible';
      }
    } else if (submitted == 0) {
      document.getElementById('id_submit_btn').style.display = 'block';
      for (var i = 0; i < navBtns.length; i++){
        navBtns[i].style.visibility='visible';
      }
      for (var i = 0; i < delBtns.length; i++){
        delBtns[i].style.visibility='visible';
      }
    }
  }
}

function getOtherEditUserPermissions() {
  var probuild_id = $('#id_probuild').val();
  $.ajax({
    type: "GET",
    url: '/ajax/get_business_case_status_and_user_group_permission/',
    data: {'probuild_id': probuild_id},
    dataType: 'json',
    success: function (case_status_user_perm) {
      showOtherEditButtons(case_status_user_perm);
    }
  });
}

function showOtherEditButtons(case_status_user_perm) {
  var submitted = case_status_user_perm['Submitted']
  var approved = case_status_user_perm['Approved']
  var canSubmit = case_status_user_perm['CanSubmit']
  var canApprove = case_status_user_perm['CanApprove']
  var canViewOnly = case_status_user_perm['CanViewOnly']
  var canEditSubmitted = case_status_user_perm['CanEditSubmitted']
  var canEditApproved = case_status_user_perm['CanEditApproved']
  var navBtns = document.getElementsByClassName('navBtn')
  var delBtns = document.getElementsByClassName('delBtn')
  console.log(submitted, approved, canSubmit, canApprove, canEditSubmitted, canEditApproved)
  if (canViewOnly == 1) {
    document.getElementById('id_biz_case_edit_btn').style.visibility = 'visible';
    document.getElementById('id_add_btn').style.visibility = 'visible';
  }
  else if (approved == 1) {
    document.getElementById('id_biz_case_edit_btn').style.visibility = 'visible';
    document.getElementById('id_add_btn').style.visibility = 'visible';
    if (canEditApproved == 1) {
      document.getElementById('id_submit_btn').style.display = 'block';
      for (var i = 0; i < navBtns.length; i++){
        navBtns[i].style.visibility='visible';
      }
      for (var i = 0; i < delBtns.length; i++){
        delBtns[i].style.visibility='visible';
      }
    }
  } else if (approved == 0) {
    for (var i = 0; i < navBtns.length; i++){
      navBtns[i].style.visibility='visible';
    }
    if(submitted == 1) {
      if (canEditSubmitted == 1) {
        document.getElementById('id_submit_btn').style.display = 'block';
        for (var i = 0; i < navBtns.length; i++){
          navBtns[i].style.visibility='visible';
        }
        for (var i = 0; i < delBtns.length; i++){
          delBtns[i].style.visibility='visible';
        }
      } else {
        document.getElementById('id_biz_case_edit_btn').style.visibility = 'visible';
      }
    } else if (submitted == 0) {
      document.getElementById('id_submit_btn').style.display = 'block';
      for (var i = 0; i < navBtns.length; i++){
        navBtns[i].style.visibility='visible';
      }
      for (var i = 0; i < delBtns.length; i++){
        delBtns[i].style.visibility='visible';
      }
    }
  }
}
