function disableEnter(e) {
  var keyCode = e.keyCode || e.which;
  if (keyCode === 13) {
    e.preventDefault();
    return false;
  }
}

function removeRequiredFieldBorder() {
  field = $(this).val();
  if (field == null) {
    $(this).attr('required', true)
  } else if(field.length > 0) {
    $(this).removeAttr('required')
  } else {
    $(this).attr('required', true)
  }
}

function removeRequiredFieldBorderWithId(id) {
  field = $(id).val();
  if (field == null) {
    $(id).attr('required', true)
  } else if(field.length > 0) {
    $(id).removeAttr('required')
  } else {
    $(id).attr('required', true)
  }
}

function toFinalDollarFormat(){
  var field = $(this).val();
  var enteredNumber = '' + field;
  enteredNumber = enteredNumber.replace(/[^0-9\.]+/g, '');
  $(this).val(Number(enteredNumber).toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD'
    })
  );
}

function toFinalDollarFormatWithId(id){
  var field = $(id).val();
  var enteredNumber = '' + field;
  enteredNumber = enteredNumber.replace(/[^0-9\.]+/g, '');
  formatted = Number(enteredNumber).toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD'
  })
  if (field < 0) {
    $(id).val("-" + formatted);
  } else {
    $(id).val(formatted);
  }
}

function toFinalDollarFormatWithVal(val){
  var field = val
  var enteredNumber = '' + field;
  enteredNumber = enteredNumber.replace(/[^0-9\.]+/g, '');
  formatted = (Number(enteredNumber).toLocaleString('en-US', {
        style: 'currency',
        currency: 'USD'
      })
    );
  if (field < 0) {
    return "-" + formatted
  } else {
    return formatted
  }
}

function stripFinalDollarFormatWithVal(val){
  var field = val
  field = Number(field.replace(/[^0-9-\.-]+/g,""));
  return field
}

function toFinalPercentFormat(){
  var field = $(this).val();
  var enteredNumber = '' + field;
    if (enteredNumber.indexOf("%") > -1) {
        // empty
    } else {
        enteredNumber = enteredNumber.replace(/[^0-9\.]+/g, '');
        $(this).val(Number(enteredNumber).toLocaleString('en-US', {
          style: 'percent',
          maximumFractionDigits : 2,
          minimumFractionDigits : 2
          })
        );
    }
}

function toFinalPercentFormatWithId(id){
  var field = $(id).val();
  var enteredNumber = '' + field;
    if (enteredNumber.indexOf("%") > -1) {
        // empty
    } else {
      enteredNumber = enteredNumber.replace(/[^0-9\.-]+/g, '');
      $(id).val(Number(enteredNumber).toLocaleString('en-US', {
          style: 'percent',
          maximumFractionDigits : 2,
          minimumFractionDigits : 2
        })
      );
    }
}


function toFinalPercentFormatWithVal(val){
  var field = val
  var enteredNumber = '' + field;
    if (enteredNumber.indexOf("%") > -1) {
        // empty
    } else {
        enteredNumber = enteredNumber.replace(/[^0-9\.]+/g, '');
        formatted = (Number(enteredNumber).toLocaleString('en-US', {
          style: 'percent',
          maximumFractionDigits : 2,
          minimumFractionDigits : 2
          })
        );
    }
  if (field < 0) {
    return "-" + formatted
  } else {
    return formatted
  }
}

function stripFinalPercentFormatWithVal(val){
  var field = val
  field = (parseFloat(field) / 100).toFixed(3);
  return field
}

function formatCalculatorDollarFieldsWithId() {
  toFinalDollarFormatWithId('#id_customer_contribution');
  toFinalDollarFormatWithId('#id_row_est_build_cost');
  toFinalDollarFormatWithId('#id_headend_cost');
  toFinalDollarFormatWithId('#id_transport_cost');
  toFinalDollarFormatWithId('#id_private_property_cost');
  toFinalDollarFormatWithId('#id_smb_arpu');
  toFinalDollarFormatWithId('#id_ent_arpu');
  toFinalDollarFormatWithId('#id_car_value');
  toFinalDollarFormatWithId('#id_business_max_actual_capital');
  toFinalDollarFormatWithId('#id_resi_max_actual_capital');
  toFinalDollarFormatWithId('#id_npv');
  toFinalDollarFormatWithId('#id_npv_less_he_trnsprt');
  toFinalDollarFormatWithId('#id_passing_cost_per');
  toFinalDollarFormatWithId('#id_additional_osp_lateral_cost_per_connect');
}

function formatCalculatorPercentFieldsWithId() {
  toFinalPercentFormatWithId('#id_smb_12mo_pen');
  toFinalPercentFormatWithId('#id_smb_36mo_pen');
  toFinalPercentFormatWithId('#id_ent_12mo_pen');
  toFinalPercentFormatWithId('#id_ent_36mo_pen');
  toFinalPercentFormatWithId('#id_lateral_construct_upfront_pct');
  toFinalPercentFormatWithId('#id_business_capital_pct');
  toFinalPercentFormatWithId('#id_resi_capital_pct');
  toFinalPercentFormatWithId('#id_irr_pct');
  toFinalPercentFormatWithId('#id_irr_pct_less_he_trnsprt');
}

function removeHelpText() {
  $('.helpText').remove();
}

function autofillState() {
  var region = $('#id_region').val();
  var state = $('#id_state').val();
  //var state_name = $('#id_state').find("option:selected").text();
  $.ajax({
    type: "GET",
    url: '/ajax/select_state/',
    data: {'region': region},
    dataType: 'json',
    success: function (list_states) {
      $('#id_state').empty()
      if (list_states.length > 1) {
        $('#id_state').append('<option value="" disabled selected>Please select a State</option>');
        for (var i = 0; i < list_states.length; ++i) {
            $('#id_state')
                .append($("<option></option>")
                  .attr("value", list_states[i].state_id)
                  .text(list_states[i].name));
        };
        $('#id_state').val(state);
      } else if (list_states.length == 1) {
        $('#id_state')
            .append($("<option></option>")
              .attr("value", list_states[0].state_id)
              .text(list_states[0].name));
        $('#id_state').val(list_states[0].state_id)
        $('#id_state').removeAttr('required');
      }
    }
  });
}

function addRegionAssumpsHelpText() {
  var region = $('#id_region').val();
  $.ajax({
    type: "GET",
    url: '/ajax/assumps_region/',
    data: {'region': region},
    dataType: 'json',
    success: function (assumps) {
      var smb_arpu = $("#id_smb_arpu").val();
      var ent_arpu = $("#id_ent_arpu").val();
      var smb_12mo_pen = $("#id_smb_12mo_pen").val();
      var smb_36mo_pen = $("#id_smb_36mo_pen").val();
      var ent_12mo_pen = $("#id_ent_12mo_pen").val();
      var ent_36mo_pen = $("#id_ent_36mo_pen").val();
      var smb_arpu_diff = (stripFinalDollarFormatWithVal(smb_arpu)
                          - assumps['smb_arpu'])
      var ent_arpu_diff = (stripFinalDollarFormatWithVal(ent_arpu)
                          - assumps['ent_arpu'])
      var smb_12mo_pen_diff = (stripFinalPercentFormatWithVal(smb_12mo_pen)
                          - assumps['smb_12mo_pen'])
      var smb_36mo_pen_diff = (stripFinalPercentFormatWithVal(smb_36mo_pen)
                          - assumps['smb_36mo_pen'])
      var ent_12mo_pen_diff = (stripFinalPercentFormatWithVal(ent_12mo_pen)
                          - assumps['ent_12mo_pen'])
      var ent_36mo_pen_diff = (stripFinalPercentFormatWithVal(ent_36mo_pen)
                          - assumps['ent_36mo_pen'])
      if (smb_arpu_diff == 0) {
        $('#id_smb_arpu').next('span').remove();
      } else {
        if (smb_arpu_diff > 0) {
          $('#id_smb_arpu').next('span').remove();
          $('#id_smb_arpu').after("<span class='helpTextRed'>"
            + toFinalDollarFormatWithVal(smb_arpu_diff) + "</span>");
        } else {
          $('#id_smb_arpu').next('span').remove();
          $('#id_smb_arpu').after("<span class='helpTextGreen'>"
            + toFinalDollarFormatWithVal(smb_arpu_diff) + "</span>");
        }
      }
      if (ent_arpu_diff == 0) {
        $('#id_ent_arpu').next('span').remove();
      } else {
        if (ent_arpu_diff > 0) {
          $('#id_ent_arpu').next('span').remove();
          $('#id_ent_arpu').after("<span class='helpTextRed'>"
            + toFinalDollarFormatWithVal(ent_arpu_diff) + "</span>");
        } else {
          $('#id_ent_arpu').next('span').remove();
          $('#id_ent_arpu').after("<span class='helpTextGreen'>"
            + toFinalDollarFormatWithVal(ent_arpu_diff) + "</span>");
        }
      }
      if (smb_12mo_pen_diff == 0) {
        $('#id_smb_12mo_pen').next('span').remove();
      } else {
        if (smb_12mo_pen_diff > 0) {
          $('#id_smb_12mo_pen').next('span').remove();
          $('#id_smb_12mo_pen').after("<span class='helpTextRed'>"
            + toFinalPercentFormatWithVal(smb_12mo_pen_diff) + "</span>");
        } else {
          $('#id_smb_12mo_pen').next('span').remove();
          $('#id_smb_12mo_pen').after("<span class='helpTextGreen'>"
            + toFinalPercentFormatWithVal(smb_12mo_pen_diff) + "</span>");
        }
      }
      if (smb_36mo_pen_diff == 0) {
        $('#id_smb_36mo_pen').next('span').remove();
      } else {
        if (smb_36mo_pen_diff > 0) {
          $('#id_smb_36mo_pen').next('span').remove();
          $('#id_smb_36mo_pen').after("<span class='helpTextRed'>"
            + toFinalPercentFormatWithVal(smb_36mo_pen_diff) + "</span>");
        } else {
          $('#id_smb_36mo_pen').next('span').remove();
          $('#id_smb_36mo_pen').after("<span class='helpTextGreen'>"
            + toFinalPercentFormatWithVal(smb_36mo_pen_diff) + "</span>");
        }
      }
      if (ent_12mo_pen_diff == 0) {
        $('#id_ent_12mo_pen').next('span').remove();
      } else {
        if (ent_12mo_pen_diff > 0) {
          $('#id_ent_12mo_pen').next('span').remove();
          $('#id_ent_12mo_pen').after("<span class='helpTextRed'>"
            + toFinalPercentFormatWithVal(ent_12mo_pen_diff) + "</span>");
        } else {
          $('#id_ent_12mo_pen').next('span').remove();
          $('#id_ent_12mo_pen').after("<span class='helpTextGreen'>"
            + toFinalPercentFormatWithVal(ent_12mo_pen_diff) + "</span>");
        }
      }
      if (ent_36mo_pen_diff == 0) {
        $('#id_ent_36mo_pen').next('span').remove();
      } else {
        if (ent_36mo_pen_diff > 0) {
          $('#id_ent_36mo_pen').next('span').remove();
          $('#id_ent_36mo_pen').after("<span class='helpTextRed'>"
            + toFinalPercentFormatWithVal(ent_36mo_pen_diff) + "</span>");
        } else {
          $('#id_ent_36mo_pen').next('span').remove();
          $('#id_ent_36mo_pen').after("<span class='helpTextGreen'>"
            + toFinalPercentFormatWithVal(ent_36mo_pen_diff) + "</span>");
        }
      }
    }
  });
}

function assumpsRegion() {
  var region = $('#id_region').val();
  $.ajax({
    type: "GET",
    url: '/ajax/assumps_region/',
    data: {'region': region},
    dataType: 'json',
    success: function (assumps) {
      $('#id_smb_arpu').val(assumps['smb_arpu']);
      $('#id_ent_arpu').val(assumps['ent_arpu']);
      $('#id_smb_12mo_pen').val(assumps['smb_12mo_pen']);
      $('#id_smb_36mo_pen').val(assumps['smb_36mo_pen']);
      $('#id_ent_12mo_pen').val(assumps['ent_12mo_pen']);
      $('#id_ent_36mo_pen').val(assumps['ent_36mo_pen']);
    }
  }).done(addRegionAssumpsHelpText());
}

function addCalculatorCalculationsHelpText(calcs) {
  var roe_gate = $('#id_roe_gate').val();
  var lat_construct_upfront_pct = $('#id_lateral_construct_upfront_pct').val()
  var roe_gate_diff = roe_gate - calcs['roe_gate']
  var lat_construct_upfront_pct_diff = (
                      stripFinalPercentFormatWithVal(lat_construct_upfront_pct)
                      - calcs['exp_lat_construct_upfront_pct'])
  if (roe_gate_diff == 0) {
    $('#id_roe_gate').next('span').remove();
  } else {
    if (roe_gate_diff > 0) {
      $('#id_roe_gate').next('span').remove();
      $('#id_roe_gate').after("<span class='helpTextRed'>"
        + roe_gate_diff + "</span>");
    } else {
    $('#id_roe_gate').next('span').remove();
    $('#id_roe_gate').after("<span class='helpTextGreen'>"
        + roe_gate_diff + "</span>");
    }
  }
  if (lat_construct_upfront_pct_diff == 0) {
    $('#id_lateral_construct_upfront_pct').next('span').remove();
  } else {
    if (lat_construct_upfront_pct_diff > 0) {
      $('#id_lateral_construct_upfront_pct').next('span').remove();
      $('#id_lateral_construct_upfront_pct').after("<span class='helpTextRed'>"
        + toFinalPercentFormatWithVal(lat_construct_upfront_pct_diff) + "</span>");
    } else {
    $('#id_lateral_construct_upfront_pct').next('span').remove();
    $('#id_lateral_construct_upfront_pct').after("<span class='helpTextGreen'>"
        + toFinalPercentFormatWithVal(lat_construct_upfront_pct_diff) + "</span>");
    }
  }
}

function highlightIrrPct(calcs) {
  var irr = calcs['IRR']
  var irr_less_he_trnsprt = calcs['IRR_Less_HE_Trnsprt']
  // format IRR backgroundColor based on value
  if (irr >= 0.1) {
    document.getElementById('id_irr_pct').style.backgroundColor = "#008000";
  } else {
    document.getElementById('id_irr_pct').style.backgroundColor = "#FF0000";
  }
  // format IRR_Less_HE_Trnsprt backgroundColor based on value
  if (irr_less_he_trnsprt >= 0.1) {
    document.getElementById('id_irr_pct_less_he_trnsprt').style.backgroundColor = "#008000";
  } else {
    document.getElementById('id_irr_pct_less_he_trnsprt').style.backgroundColor = "#FF0000";
  }
}

function autofillCalculatorCalculations() {
  var probuild_id = $('#id_probuild_id').val();
  var customer_contribution = $("#id_customer_contribution").val();
  var row_est_build_cost = $("#id_row_est_build_cost").val();
  var headend_cost = $("#id_headend_cost").val();
  var transport_cost = $("#id_transport_cost").val();
  var private_property_cost = $("#id_private_property_cost").val();
  var lat_construct_upfront_pct = $('#id_lateral_construct_upfront_pct').val()
  var smb_arpu = $("#id_smb_arpu").val();
  var ent_arpu = $("#id_ent_arpu").val();
  var smb_12mo_pen = $("#id_smb_12mo_pen").val();
  var smb_36mo_pen = $("#id_smb_36mo_pen").val();
  var ent_12mo_pen = $("#id_ent_12mo_pen").val();
  var ent_36mo_pen = $("#id_ent_36mo_pen").val();
  var building_ct = $("#id_building_ct").val();
  var multi_tenant_building_ct = $("#id_multi_tenant_building_ct").val();
  var mdu_ct = $("#id_mdu_ct").val();
  var smb_qb_ct = $("#id_smb_qb_ct").val();
  var ent_qb_ct = $("#id_ent_qb_ct").val();
  var smb_dealinhand_ct = $("#id_smb_dealinhand_ct").val();
  var smb_dealinhand_mrc = $("#id_smb_dealinhand_mrc").val();
  var ent_dealinhand_ct = $("#id_ent_dealinhand_ct").val();
  var ent_dealinhand_mrc = $("#id_ent_dealinhand_mrc").val();
  console.log(smb_dealinhand_mrc)
  $.ajax({
    type: "GET",
    url: '/ajax/calcs_calculator/',
    data: {'customer_contribution': customer_contribution,
        'row_est_build_cost': row_est_build_cost, 'headend_cost': headend_cost,
        'transport_cost': transport_cost, 'private_property_cost': private_property_cost,
        'lat_construct_upfront_pct': lat_construct_upfront_pct, 
        'smb_arpu': smb_arpu, 'ent_arpu': ent_arpu,
        'smb_12mo_pen': smb_12mo_pen, 'smb_36mo_pen': smb_36mo_pen, 
        'ent_12mo_pen': ent_12mo_pen, 'ent_36mo_pen': ent_36mo_pen,
        'building_ct': building_ct, 'multi_tenant_building_ct': multi_tenant_building_ct,
        'mdu_ct': mdu_ct, 'smb_qb_ct': smb_qb_ct, 'ent_qb_ct': ent_qb_ct,
        'smb_dealinhand_ct': smb_dealinhand_ct, 'smb_dealinhand_mrc': smb_dealinhand_mrc, 
        'ent_dealinhand_ct': ent_dealinhand_ct, 'ent_dealinhand_mrc': ent_dealinhand_mrc,
        },
    dataType: 'json',
    success: function (calcs) {
      $('#id_fund_bucket').val(calcs['fund_bucket']);
      $('#id_building_ct').val(calcs['building_ct']);
      $('#id_car_value').val(calcs['CAR']);
      $('#id_irr_pct').val(calcs['IRR']);
      $('#id_irr_pct_less_he_trnsprt').val(calcs['IRR_Less_HE_Trnsprt'])
      $('#id_npv').val(calcs['NPV']);
      $('#id_npv_less_he_trnsprt').val(calcs['NPV_Less_HE_Trnsprt']);
      $('#id_payback_mo').val(calcs['payback_mo']);
      $('#id_passing_cost_per').val(calcs['passing_cost_per']);
      $('#id_additional_osp_lateral_cost_per_connect').val(calcs['lat_cost_per_connect']);
      $('#id_business_max_actual_capital').val(calcs['business_NPV']);
      $('#id_resi_max_actual_capital').val(calcs['resi_NPV']);
      addCalculatorCalculationsHelpText(calcs);
      highlightIrrPct(calcs);
    }
  });
}
