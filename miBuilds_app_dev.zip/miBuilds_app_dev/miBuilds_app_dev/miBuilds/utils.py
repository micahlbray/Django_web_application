from decimal import Decimal
import re, os

######################################################################
# Helper functions
######################################################################
def ifnull(var, val):
  if var in (None,'', 'None', [], False):
    return val
  return var

def strDollarToDecimal(val):
    if val in (None,'', [], False):
        return val
    elif "$" not in str(val):
        return float(Decimal(val))
    value = float(Decimal(re.sub(r'[^\d\-.]', '', val)))
    return value

def strPercentToDecimal(val):
    if val in (None,'', [], False):
        return val
    elif "%" not in str(val):
        return float(Decimal(val))
    value = round((float(Decimal(re.sub(r'[^\d\-.]', '', val))) / 100) , 3)
    return value

def cashflowTableHTMLstyle(df):
    df = df.replace('border="1"', 'border="0"')
    df = df.replace('class="dataframe "', 'class="cashflowTable"')
    return df

def highlight_MOS(s):
    is_mos = s.index.get_level_values(1) == 'Estimated SMB Penetration'
    return ['color: darkorange' if v else 'color: darkblue' for v in is_mos]

def get_col_widths(dataframe):
    # First we find the maximum length of the index column
    idx_max = max([len(str(s)) for s in dataframe.index.values]
                    + [len(str(dataframe.index.name))])
    # Then, we concatenate this to the max of the lengths of column name and
    # its values for each column, left to right
    return [idx_max] + [max([len(str(s)) for s in dataframe[col].values]
                    + [len(col)]) for col in dataframe.columns]

def set_col_widths(dataframe, worksheet, workbook_format):
    for i, width in enumerate(get_col_widths(dataframe)):
        worksheet.set_column(i, i - 1, width + 3, workbook_format)
