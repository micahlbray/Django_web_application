from django.db import models
from miBuilds.validators import (validate_date_past,
                                  validate_date_future,
                                  validate_id_not_zero,
                                  validate_number_greather_than_zero,
                                  validate_sf_opp_id_start_with,
                                  validate_alphanumeric,
                                  validate_csv,
                                  )
import os

class AppBuilding(models.Model):
    record_id = models.AutoField(db_column='record_id', primary_key=True)
    building_id = models.BigIntegerField(db_column='Building_Id', blank=True, null=True, verbose_name='Building ID', validators = [validate_id_not_zero])  # Field name made lowercase.
    probuild = models.ForeignKey('AppProbuild', models.DO_NOTHING, db_column='Probuild_Id')  # Field name made lowercase.
    parentbuilding_id = models.IntegerField(db_column='ParentBuilding_Id', blank=True, null=True, verbose_name='Parent Building ID')  # Field name made lowercase.
    address = models.CharField(db_column='Address', max_length=255, blank=True, null=True, verbose_name='Address')  # Field name made lowercase.
    city = models.CharField(db_column='City', max_length=150, blank=True, null=True, verbose_name='City')  # Field name made lowercase.
    state = models.ForeignKey('LkState', models.DO_NOTHING, db_column='State_Id', verbose_name='State')  # Field name made lowercase.
    zip = models.CharField(db_column='Zip', max_length=50, blank=True, null=True, verbose_name='Zip Code')  # Field name made lowercase.
    sellability_color_coax = models.CharField(db_column='sellability_Color_Coax', max_length=20, blank=True, null=True, verbose_name='Coax Color')  # Field name made lowercase.
    sellability_color_fiber = models.CharField(db_column='sellability_Color_Fiber', max_length=20, blank=True, null=True, verbose_name='Fiber Color')  # Field name made lowercase.
    building_type = models.ForeignKey('LkBuildingType', models.DO_NOTHING, db_column='Building_Type_Id', verbose_name='Building Type')  # Field name made lowercase.
    dwelling_type = models.ForeignKey('LkDwellingType', models.DO_NOTHING, db_column='Dwelling_Type_Id', verbose_name='Dwelling Type')  # Field name made lowercase.
    roe_status_id = models.ForeignKey('LkRoeStatus', models.DO_NOTHING, db_column='ROE_Status_Id', blank=True, null=True, verbose_name="ROE Status")  # Field name made lowercase.
    roe_id = models.IntegerField(db_column='ROE_Id', blank=True, null=True, verbose_name="ROE ID")  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True, verbose_name="Added On")  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True, verbose_name="Added By")  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True, verbose_name="Edited By")  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True, verbose_name="Edited On")  # Field name made lowercase.
    deleted = models.IntegerField(db_column='Deleted', blank=True, null=True)  # Field name made lowercase.
    deletedon = models.DateTimeField(db_column='DeletedOn', blank=True, null=True)  # Field name made lowercase.
    deletedby = models.CharField(db_column='DeletedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'app_Building'

class AppBuildingPostApproval(models.Model):
    record_id = models.AutoField(db_column='Record_Id', primary_key=True)
    building_id = models.IntegerField(db_column='Building_Id', blank=True, null=True)  # Field name made lowercase
    probuild = models.IntegerField(db_column='Probuild_Id', blank=True, null=True)  # Field name made lowercase.
    probuild_name = models.CharField(db_column='Probuild_Name', max_length=255, blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'app_Building_Post_Approval'

class AppBuildingUpload(models.Model):
    building_upload_id = models.AutoField(db_column='building_upload_id', primary_key=True)  # Field name made lowercase.
    probuild = models.ForeignKey('AppProbuild', models.DO_NOTHING, db_column='Probuild_Id')
    name = models.CharField(db_column='Name', max_length=255, blank=True, null=True)  # Field name made lowercase.
    path = models.FileField(upload_to='building_upload/', verbose_name='File')# validators=[validate_csv])  # Field name made lowercase.
    root = models.CharField(db_column='Root', max_length=255, blank=True, null=True)
    upload_type = models.ForeignKey('LkUploadType', models.DO_NOTHING, db_column='Upload_Type_Id', blank=True, null=True, verbose_name='Upload Type')  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    deleted = models.IntegerField(db_column='Deleted', blank=True, null=True)  # Field name made lowercase.
    deletedon = models.DateTimeField(db_column='DeletedOn', blank=True, null=True)  # Field name made lowercase.
    deletedby = models.CharField(db_column='DeletedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    greenfield = models.IntegerField(db_column='Greenfield', blank=True, null=True)
    post_approval = models.IntegerField(db_column='Post_Approval', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'app_Building_Upload'

    def extension(self):
        name, extension = os.path.splitext(self.path.name)
        return extension

class AppBuildingUploadPostApproval(models.Model):
    building_upload_id = models.AutoField(db_column='building_upload_id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=255, blank=True, null=True)  # Field name made lowercase.
    path = models.FileField(upload_to='building_upload/', verbose_name='File')# validators=[validate_csv])  # Field name made lowercase.
    root = models.CharField(db_column='Root', max_length=255, blank=True, null=True)
    upload_type = models.ForeignKey('LkUploadType', models.DO_NOTHING, db_column='Upload_Type_Id', blank=True, null=True, verbose_name='Upload Type')  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    deleted = models.IntegerField(db_column='Deleted', blank=True, null=True)  # Field name made lowercase.
    deletedon = models.DateTimeField(db_column='DeletedOn', blank=True, null=True)  # Field name made lowercase.
    deletedby = models.CharField(db_column='DeletedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'app_Building_Upload_Post_Approval'

class AppBusiness(models.Model):
    record_id = models.AutoField(db_column='Record_Id', primary_key=True)
    business_id = models.IntegerField(db_column='Business_Id', blank=True, null=True, verbose_name='Business ID', validators = [validate_id_not_zero])  # Field name made lowercase.
    building_id = models.BigIntegerField(db_column='Building_Id', blank=True, null=True, verbose_name='Building ID', validators = [validate_id_not_zero])  # Field name made lowercase.
    probuild = models.ForeignKey('AppProbuild', models.DO_NOTHING, db_column='ProBuild_Id')  # Field name made lowercase.
    business_name = models.CharField(db_column='Business_Name', max_length=255, blank=True, null=True, verbose_name='Business Name')  # Field name made lowercase.
    address_id = models.IntegerField(db_column='Address_Id', blank=True, null=True, verbose_name='Address ID')
    address_1 = models.CharField(db_column='Address_1', max_length=255, blank=True, null=True, verbose_name='Address 1')  # Field name made lowercase.
    address_2 = models.CharField(db_column='Address_2', max_length=255, blank=True, null=True, verbose_name='Address 2')  # Field name made lowercase.
    city = models.CharField(db_column='City', max_length=150, blank=True, null=True, verbose_name='City')  # Field name made lowercase.
    state = models.ForeignKey('LkState', models.DO_NOTHING, db_column='State_Id', blank=True, null=True, verbose_name='State')  # Field name made lowercase.
    zip = models.CharField(db_column='Zip', max_length=50, blank=True, null=True, verbose_name='Zip Code')  # Field name made lowercase.
    sellability_color_coax = models.CharField(db_column='sellability_Color_Coax', max_length=20, blank=True, null=True, verbose_name='Coax Color')  # Field name made lowercase.
    sellability_color_fiber = models.CharField(db_column='sellability_Color_Fiber', max_length=20, blank=True, null=True, verbose_name='Fiber Color')  # Field name made lowercase.
    mip_in_or_out = models.CharField(db_column='MIP_In_Or_Out', max_length=3, blank=True, null=True, verbose_name='IN or OUT')  # Field name made lowercase.
    segment_type_id = models.ForeignKey('LkSegmentType', models.DO_NOTHING, db_column='Segment_Type_Id', verbose_name='Segment Type')  # Field name made lowercase.
    segment_assump = models.ForeignKey('AssumpSegment', models.DO_NOTHING, db_column='Segment_Assump_Id')  # Field name made lowercase.
    revised_segment_type_id = models.ForeignKey('LkSegmentType', models.DO_NOTHING, db_column='Revised_Segment_Type_Id', blank=True, null=True, related_name='revised_segment_type_id', verbose_name='Revised Segment Type')  # Field name made lowercase.
    revised_segment_notes = models.CharField(db_column='Revised_Segment_Notes', max_length=255, blank=True, null=True, verbose_name='Revised Segment Notes')  # Field name made lowercase.
    roe_id = models.IntegerField(db_column='ROE_Id', blank=True, null=True, verbose_name='ROE ID')
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    deleted = models.IntegerField(db_column='Deleted', blank=True, null=True)  # Field name made lowercase.
    deletedon = models.DateTimeField(db_column='DeletedOn', blank=True, null=True)  # Field name made lowercase.
    deletedby = models.CharField(db_column='DeletedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    

    class Meta:
        managed = False
        db_table = 'app_Business'


class AppBusinessUpload(models.Model):
    business_upload_id = models.AutoField(db_column='business_upload_id', primary_key=True)  # Field name made lowercase.
    probuild = models.ForeignKey('AppProbuild', models.DO_NOTHING, db_column='Probuild_Id')
    name = models.CharField(db_column='Name', max_length=255, blank=True, null=True)  # Field name made lowercase.
    path = models.FileField(upload_to='business_upload/', verbose_name='File')# validators=[validate_csv])  # Field name made lowercase.
    root = models.CharField(db_column='Root', max_length=255, blank=True, null=True)
    upload_type = models.ForeignKey('LkUploadType', models.DO_NOTHING, db_column='Upload_Type_Id', blank=True, null=True, verbose_name='Upload Type')  # Field name made lowercase.
    isdeleted = models.IntegerField(db_column='IsDeleted', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    deleted = models.IntegerField(db_column='Deleted', blank=True, null=True)  # Field name made lowercase.
    deletedon = models.DateTimeField(db_column='DeletedOn', blank=True, null=True)  # Field name made lowercase.
    deletedby = models.CharField(db_column='DeletedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    greenfield = models.IntegerField(db_column='Greenfield', blank=True, null=True)
    post_approval = models.IntegerField(db_column='Post_Approval', blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'app_Business_Upload'


class AppCashflow(models.Model):
    cashflow_id = models.AutoField(db_column='CashFlow_Id', primary_key=True)  # Field name made lowercase.
    probuild = models.ForeignKey('AppProbuild', models.DO_NOTHING, db_column='Probuild_Id')  # Field name made lowercase.
    category = models.CharField(db_column='Category', max_length=255, blank=True, null=True)  # Field name made lowercase.
    mnth = models.IntegerField(db_column='Mnth', blank=True, null=True)  # Field name made lowercase.
    value = models.DecimalField(db_column='Value', max_digits=22, decimal_places=6, blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    deleted = models.IntegerField(db_column='Deleted', blank=True, null=True)  # Field name made lowercase.
    deletedon = models.DateTimeField(db_column='DeletedOn', blank=True, null=True)  # Field name made lowercase.
    deletedby = models.CharField(db_column='DeletedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'app_CashFlow'


class AppDatacenter(models.Model):
    datacenter_id = models.AutoField(db_column='DataCenter_Id', primary_key=True)  # Field name made lowercase.
    probuild = models.ForeignKey('AppProbuild', models.DO_NOTHING, db_column='Probuild_Id')  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=255, blank=True, null=True, verbose_name='Data Center Name')  # Field name made lowercase.
    data_center_type = models.ForeignKey('LkDataCenterType', models.DO_NOTHING, db_column='Data_Center_Type_Id', verbose_name='Size')  # Field name made lowercase.
    data_center_equip_type = models.ForeignKey('LkDataCenterEquipType', models.DO_NOTHING, db_column='Data_Center_Equip_Type_Id', verbose_name='Equipment Type')  # Field name made lowercase.
    data_center_type_assump = models.ForeignKey('AssumpDataCenterType', models.DO_NOTHING, db_column='Data_Center_Type_Assump_Id', blank=True, null=True)  # Field name made lowercase.
    data_center_equip_type_assump = models.ForeignKey('AssumpDataCenterEquipType', models.DO_NOTHING, db_column='Data_Center_Equip_Type_Assump_Id', blank=True, null=True)  # Field name made lowercase.
    data_center_circuit_eoy_assump = models.IntegerField(db_column='Data_Center_Circuit_EOY_Assump_Id', blank=True, null=True)  # Field name made lowercase.
    comments = models.CharField(db_column='Comments', max_length=255, blank=True, null=True, verbose_name='Write In')  # Field name made lowercase.
    isconnected = models.IntegerField(db_column='IsConnected', blank=True, null=True, verbose_name='Already Connected')  # Field name made lowercase.
    dc_circuit_ct = models.IntegerField(db_column='DC_Circuit_Ct', blank=True, null=True, verbose_name='Total DC Circuits')  # Field name made lowercase.
    rack = models.DecimalField(db_column='Rack', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Rack')  # Field name made lowercase.
    colo_fee = models.DecimalField(db_column='Colo_Fee', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Colo Fee')  # Field name made lowercase.
    connect_cost = models.DecimalField(db_column='Connect_Cost', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Connect Costs')  # Field name made lowercase.
    mrr_per_circ_avg = models.DecimalField(db_column='MRR_Per_Circ_Avg', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='MRR/Circuit')  # Field name made lowercase.
    equip_capex = models.DecimalField(db_column='Equip_Capex', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Equipment Cost')  # Field name made lowercase.
    equip_opex = models.DecimalField(db_column='Equip_Opex', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Power')  # Field name made lowercase.
    opex_pct = models.DecimalField(db_column='Opex_Pct', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='Tech Opex Load')  # Field name made lowercase.
    yr1_circuit_ct = models.IntegerField(db_column='Yr1_Circuit_Ct', blank=True, null=True, verbose_name='Year 1')  # Field name made lowercase.
    yr2_circuit_ct = models.IntegerField(db_column='Yr2_Circuit_Ct', blank=True, null=True, verbose_name='Year 2')  # Field name made lowercase.
    yr3_circuit_ct = models.IntegerField(db_column='Yr3_Circuit_Ct', blank=True, null=True, verbose_name='Year 3')  # Field name made lowercase.
    yr4_circuit_ct = models.IntegerField(db_column='Yr4_Circuit_Ct', blank=True, null=True, verbose_name='Year 4')  # Field name made lowercase.
    yr5_circuit_ct = models.IntegerField(db_column='Yr5_Circuit_Ct', blank=True, null=True, verbose_name='Year 5')  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    deleted = models.IntegerField(db_column='Deleted', blank=True, null=True)  # Field name made lowercase.
    deletedon = models.DateTimeField(db_column='DeletedOn', blank=True, null=True)  # Field name made lowercase.
    deletedby = models.CharField(db_column='DeletedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'app_DataCenter'

class AppDatacenterCircuitEoy(models.Model):
    datacenter_id = models.IntegerField(db_column='DataCenter_Id', blank=False, null=False)  # Field name made lowercase.
    yr = models.IntegerField(db_column='Yr', blank=True, null=True)  # Field name made lowercase.
    circuit_ct = models.IntegerField(db_column='Circuit_Ct', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    deleted = models.IntegerField(db_column='Deleted', blank=True, null=True)  # Field name made lowercase.
    deletedon = models.DateTimeField(db_column='DeletedOn', blank=True, null=True)  # Field name made lowercase.
    deletedby = models.CharField(db_column='DeletedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Data_Center_Type'

    def __str__(self):
        return self.name

class AppFile(models.Model):
    file_id = models.AutoField(db_column='File_Id', primary_key=True)  # Field name made lowercase.
    probuild = models.ForeignKey('AppProbuild', models.DO_NOTHING, db_column='Probuild_Id')
    name = models.CharField(db_column='Name', max_length=255, blank=True, null=True)  # Field name made lowercase.
    path = models.FileField(upload_to='file_upload/', verbose_name='File')  # Field name made lowercase.
    root = models.CharField(db_column='Root', max_length=255, blank=True, null=True)
    file_type = models.ForeignKey('LkFileType', models.DO_NOTHING, db_column='File_Type_Id', verbose_name='File Type')  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    deleted = models.IntegerField(db_column='Deleted', blank=True, null=True)  # Field name made lowercase.
    deletedon = models.DateTimeField(db_column='DeletedOn', blank=True, null=True)  # Field name made lowercase.
    deletedby = models.CharField(db_column='DeletedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    image = models.ImageField(db_column='Image', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'app_File'

    def __str__(self):
        return self.name


class AppMdu(models.Model):
    mdu_id = models.AutoField(db_column='MDU_Id', primary_key=True)  # Field name made lowercase.
    probuild = models.ForeignKey('AppProbuild', models.DO_NOTHING, db_column='Probuild_Id')  # Field name made lowercase.
    property_name = models.CharField(db_column='Property_Name', max_length=255, blank=True, null=True, verbose_name='Property Name')  # Field name made lowercase.
    system_name = models.CharField(db_column='System_Name', max_length=255, blank=True, null=True, verbose_name='System')  # Field name made lowercase.
    property_owner = models.CharField(db_column='Property_Owner', max_length=255, blank=True, null=True, verbose_name='Property Owner/Mgmt Co.')  # Field name made lowercase.
    est_compl_dt = models.DateField(db_column='Est_Compl_Dt', blank=True, null=True, verbose_name='Estimated Completion Date')  # Field name made lowercase.
    mdu_build_type = models.ForeignKey('LkMduBuildType', models.DO_NOTHING, db_column='Mdu_Build_Type_Id', verbose_name='Build Type')  # Field name made lowercase.
    current_service_type = models.ForeignKey('LkCurrentServiceType', models.DO_NOTHING, db_column='Current_Service_Type_Id', verbose_name='Current Service')  # Field name made lowercase.
    term_length = models.ForeignKey('LkTermLength', models.DO_NOTHING, db_column='Term_Length_Id', verbose_name='Contract Term')  # Field name made lowercase.
    mdu_build_assump = models.ForeignKey('AssumpMduBuild', models.DO_NOTHING, db_column='MDU_Build_Assump_Id', blank=True, null=True)  # Field name made lowercase.
    mdu_build_region_assump = models.ForeignKey('AssumpMduBuildRegion', models.DO_NOTHING, db_column='MDU_Build_Region_Assump_Id', blank=True, null=True)  # Field name made lowercase.
    building_ct = models.IntegerField(db_column='Building_Ct', blank=True, null=True, verbose_name='Total Buildings')  # Field name made lowercase.
    unit_ct = models.IntegerField(db_column='Unit_Ct', blank=True, null=True, verbose_name='Total Units')  # Field name made lowercase.
    video_subscr_target = models.IntegerField(db_column='Video_Subscr_Target', blank=True, null=True, verbose_name='Video Subscribers Target')  # Field name made lowercase.
    data_subscr_target = models.IntegerField(db_column='Data_Subscr_Target', blank=True, null=True, verbose_name='Data Subscribers Target')  # Field name made lowercase.
    voice_subscr_target = models.IntegerField(db_column='Voice_Subscr_Target', blank=True, null=True, verbose_name='Voice Subscribers Target')  # Field name made lowercase.
    video_penetration = models.DecimalField(db_column='Video_Penetration', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='Video Penetration')  # Field name made lowercase.
    data_penetration = models.DecimalField(db_column='Data_Penetration', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='Data Penetration')  # Field name made lowercase.
    voice_penetration = models.DecimalField(db_column='Voice_Penetration', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='Voice Penetration')  # Field name made lowercase.
    video_arpu = models.DecimalField(db_column='Video_ARPU', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Video ARPU')  # Field name made lowercase.
    data_arpu = models.DecimalField(db_column='Data_ARPU', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Data ARPU')  # Field name made lowercase.
    voice_arpu = models.DecimalField(db_column='Voice_ARPU', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Voice ARPU')  # Field name made lowercase.
    video_rev_share = models.DecimalField(db_column='Video_Rev_Share', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='Video Rev Share')  # Field name made lowercase.
    data_rev_share = models.DecimalField(db_column='Data_Rev_Share', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='Data Rev Share')  # Field name made lowercase.
    voice_rev_share = models.DecimalField(db_column='Voice_Rev_Share', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='Voice Rev Share')  # Field name made lowercase.
    opex_load = models.DecimalField(db_column='Opex_Load', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='Opex Load')  # Field name made lowercase.
    door_fees = models.DecimalField(db_column='Door_Fees', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Upfront Per Door Fee')  # Field name made lowercase.
    isp_per_unit = models.DecimalField(db_column='ISP_Per_Unit', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Inside Wiring')  # Field name made lowercase.
    converter = models.DecimalField(db_column='Converter', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Converter')  # Field name made lowercase.
    modem = models.DecimalField(db_column='Modem', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Modem')  # Field name made lowercase.
    emta = models.DecimalField(db_column='eMTA', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='eMTA')  # Field name made lowercase.
    commission = models.DecimalField(db_column='Commission', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Commission')  # Field name made lowercase.
    penetration_ramp = models.IntegerField(db_column='Penetration_Ramp', blank=True, null=True, verbose_name='Penetration Ramp')  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    deleted = models.IntegerField(db_column='Deleted', blank=True, null=True)  # Field name made lowercase.
    deletedon = models.DateTimeField(db_column='DeletedOn', blank=True, null=True)  # Field name made lowercase.
    deletedby = models.CharField(db_column='DeletedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'app_MDU'


class AppProbuild(models.Model):
    probuild_id = models.AutoField(db_column='Probuild_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=255, blank=False, null=False, unique=True, verbose_name='Project Name', error_messages={'unique':'This name is already in use.'}, validators=[validate_alphanumeric])  # Field name made lowercase.
    spectrum_job_id = models.CharField(db_column='Spectrum_Job_Id', max_length=150, blank=True, null=True, verbose_name='Spectrum Job Id')  # Field name made lowercase.
    region = models.ForeignKey('LkRegion', models.DO_NOTHING, db_column='Region_Id', blank=False, null=False)  # Field name made lowercase.
    probuild_city = models.CharField(db_column='Probuild_City', max_length=255, blank=True, null=True, verbose_name='City')  # Field name made lowercase.
    state = models.ForeignKey('LkState', models.DO_NOTHING, db_column='State_Id', blank=False, null=False)  # Field name made lowercase.
    build_type = models.ForeignKey('LkBuildType', models.DO_NOTHING, db_column='Build_Type_Id', blank=False, null=False, verbose_name='Build Type' )  # Field name made lowercase.
    transport_type = models.ForeignKey('LkTransportType', models.DO_NOTHING, db_column='Transport_Type_Id', verbose_name='Transport Type')  # Field name made lowercase.
    survey_type = models.ForeignKey('LkSurveyType', models.DO_NOTHING, db_column='Survey_Type_Id', blank=True, null=True, verbose_name='Survey Type')  # Field name made lowercase.
    cross_functional_review_on = models.DateField(db_column='Cross_Functional_Review_On', blank=True, null=True, verbose_name='Cross-functional Review Date')  # Field name made lowercase.
    historical_opportunities = models.IntegerField(db_column='Historical_Opportunities', blank=True, null=True, verbose_name='Historical Opportunities')  # Field name made lowercase.
    jt_id = models.BigIntegerField(db_column='JT_Id', blank=True, null=True, verbose_name='JT ID')  # Field name made lowercase.
    est_compl_dt = models.DateField(db_column='Est_Compl_Dt', blank=True, null=True, verbose_name='Estimated Completion Date')  # Field name made lowercase.
    roe_gate = models.IntegerField(db_column='ROE_Gate', blank=True, null=True, verbose_name='ROE Gate (Passings)')  # Field name made lowercase.
    roe_gate_dt = models.DateField(db_column='ROE_Gate_Dt', blank=True, null=True, verbose_name='ROE Gate Date')  # Field name made lowercase.
    permitting_gate_dt = models.DateField(db_column='Permitting_Gate_Dt', blank=True, null=True, verbose_name='Permitting Gate Date')  # Field name made lowercase.
    region_assump = models.ForeignKey('AssumpRegion', models.DO_NOTHING, db_column='Region_Assump_Id', blank=True, null=True)  # Field name made lowercase.
    mdu_build_region_assump = models.ForeignKey('AssumpMduBuildRegion', models.DO_NOTHING, db_column='MDU_Build_Region_Assump_Id', blank=True, null=True)  # Field name made lowercase.
    row_est_build_cost = models.DecimalField(db_column='ROW_Est_Build_Cost', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Estimated Build Cost ROW')  # Field name made lowercase.
    headend_cost = models.DecimalField(db_column='HeadEnd_Cost', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Head End / Node / V-Hub Cost')  # Field name made lowercase.
    transport_cost = models.DecimalField(db_column='Transport_Cost', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Transportation / Distribution Cost')  # Field name made lowercase.
    private_property_cost = models.DecimalField(db_column='Private_Property_Cost', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Private Property Cost (including material)')
    smb_arpu = models.DecimalField(db_column='SMB_ARPU', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='SMB ARPU')  # Field name made lowercase.
    ent_arpu = models.DecimalField(db_column='ENT_ARPU', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='ENT ARPU')  # Field name made lowercase.
    smb_12mo_pen = models.DecimalField(db_column='SMB_12mo_Pen', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='SMB Penetration 12 Mo', validators=[validate_number_greather_than_zero])  # Field name made lowercase.
    smb_36mo_pen = models.DecimalField(db_column='SMB_36mo_Pen', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='SMB Penetration 36 Mo')  # Field name made lowercase.
    ent_12mo_pen = models.DecimalField(db_column='ENT_12mo_Pen', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='ENT Penetration 12 Mo')  # Field name made lowercase.
    ent_36mo_pen = models.DecimalField(db_column='ENT_36mo_Pen', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='ENT Penetration 36 Mo')  # Field name made lowercase.
    fiber_competitors_ct = models.IntegerField(db_column='Fiber_Competitors_Ct', blank=True, null=True, verbose_name='# of Fiber Competitors')  # Field name made lowercase.
    fiber_competitors = models.TextField(db_column='Fiber_Competitors', blank=True, null=True, verbose_name='Fiber Competitors')  # Field name made lowercase.
    download_speed_id = models.ForeignKey('LkDownloadSpeed', models.DO_NOTHING, db_column='Download_Speed_Id', blank=True, null=True, verbose_name='Max Available DSL Speed')  # Field name made lowercase.
    term_length = models.ForeignKey('LkTermLength', models.DO_NOTHING, db_column='Term_Length_Id', blank=True, null=True, verbose_name='Term')  # Field name made lowercase.
    access_fees_one_time = models.DecimalField(db_column='Access_Fees_One_Time', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Access Fees (One Time)')  # Field name made lowercase.
    access_fees_monthly = models.DecimalField(db_column='Access_Fees_Monthly', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Access Fees (Monthly)')  # Field name made lowercase.
    comments = models.TextField(db_column='Comments', blank=True, null=True, verbose_name='Business Justification')  # Field name made lowercase.
    considerations = models.TextField(db_column='Considerations', blank=True, null=True)  # Field name made lowercase.
    investment_committee_takeaway = models.TextField(db_column='Investment_Committee_Takeaway', blank=True, null=True, verbose_name='Investment Committee Takeaway')  # Field name made lowercase.
    added = models.IntegerField(db_column='Added', blank=True, null=True, verbose_name='Added')  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True, verbose_name='Case Created On')  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True, verbose_name='Case Created By')  # Field name made lowercase.
    edited = models.IntegerField(db_column='Edited', blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True, verbose_name='Case Last Edited On')  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True, verbose_name='Case Last Edited By')  # Field name made lowercase.
    submitted = models.IntegerField(db_column='Submitted', blank=True, null=True)  # Field name made lowercase.
    submittedon = models.DateTimeField(db_column='SubmittedOn', blank=True, null=True, verbose_name='Case Submitted On')  # Field name made lowercase.
    submittedby = models.CharField(db_column='SubmittedBy', max_length=100, blank=True, null=True, verbose_name='Case Submitted By')  # Field name made lowercase.
    approved = models.IntegerField(db_column='Approved', blank=True, null=True)  # Field name made lowercase.
    approvedon = models.DateTimeField(db_column='ApprovedOn', blank=True, null=True, verbose_name='Case Approved On')  # Field name made lowercase.
    approvedby = models.CharField(db_column='ApprovedBy', max_length=100, blank=True, null=True, verbose_name='Case Approved By')  # Field name made lowercase.
    todelete = models.IntegerField(db_column='ToDelete', blank=True, null=True)  # Field name made lowercase.
    todeleteon = models.DateTimeField(db_column='ToDeleteOn', blank=True, null=True)  # Field name made lowercase.
    todeleteby = models.CharField(db_column='ToDeleteBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    deleted = models.IntegerField(db_column='Deleted', blank=True, null=True)  # Field name made lowercase.
    deletedon = models.DateTimeField(db_column='DeletedOn', blank=True, null=True)  # Field name made lowercase.
    deletedby = models.CharField(db_column='DeletedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    customer_contribution = models.DecimalField(db_column='Customer_Contribution', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Customer Contribution', validators=[validate_number_greather_than_zero])
    bdr = models.ForeignKey('LkBdr', models.DO_NOTHING, db_column='BDR_Id', blank=True, null=True, verbose_name='BDR')  # Field name made lowercase.
    disposition_type = models.ForeignKey('LkDispositionType', models.DO_NOTHING, db_column='Disposition_Type_Id', blank=True, null=True, verbose_name='Disposition Type')  # Field name made lowercase.
    parent_probuild_id = models.IntegerField(db_column='Parent_Probuild_Id', blank=True, null=True)  # Field name made lowercase.
    cloned = models.IntegerField(db_column='Cloned', blank=True, null=True)  # Field name made lowercase.
    clonedon = models.DateTimeField(db_column='ClonedOn', blank=True, null=True)  # Field name made lowercase.
    clonedby = models.CharField(db_column='ClonedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    child = models.IntegerField(db_column='Child', blank=True, null=True)  # Field name made lowercase.
    childon = models.DateTimeField(db_column='ChildOn', blank=True, null=True)  # Field name made lowercase.
    childby = models.CharField(db_column='ChildBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    legacy = models.IntegerField(db_column='Legacy', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'app_Probuild'
        verbose_name = 'Probuild'
        verbose_name_plural = 'Probuilds'

    def __str__(self):
        return str(self.name)

    def status(self):
        if self.approved == 1:
            status = 'Approved'
        elif self.submitted == 1:
            status = 'Submitted'
        else:
            status = 'Added'
        return status

class AppProbuildNote(models.Model):
    probuild_note_id = models.AutoField(db_column='Probuild_Note_Id', primary_key=True)
    probuild = models.ForeignKey('AppProbuild', models.DO_NOTHING, db_column='Probuild_Id')  # Field name made lowercase.
    note = models.TextField(db_column='Note', blank=True, null=True, verbose_name='Note')
    note_type = models.ForeignKey('LkNoteType', models.DO_NOTHING, db_column='Note_Type_Id', blank=True, null=True, verbose_name='Note Type')
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True, verbose_name='Note Added On')  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True, verbose_name='Note Added By')  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True, verbose_name='Note Last Edited On')  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True, verbose_name='Note Last Edited By')  # Field name made lowercase.
    deleted = models.IntegerField(db_column='Deleted', blank=True, null=True)  # Field name made lowercase.
    deletedon = models.DateTimeField(db_column='DeletedOn', blank=True, null=True)  # Field name made lowercase.
    deletedby = models.CharField(db_column='DeletedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'app_Probuild_Note'

class AppSfDealinhand(models.Model):
    sf_dealinhand_id = models.AutoField(db_column='SF_DealInHand_Id', primary_key=True)  # Field name made lowercase.
    probuild = models.ForeignKey(AppProbuild, models.DO_NOTHING, db_column='Probuild_Id')  # Field name made lowercase.
    opportunity_id = models.CharField(db_column='Opportunity_Id', max_length=150, blank=True, null=True, verbose_name='Sales Force Opportunity ID', validators = [validate_sf_opp_id_start_with])  # Field name made lowercase.
    customer_name = models.CharField(db_column='Customer_Name', max_length=255, blank=True, null=True, verbose_name='Customer Name')  # Field name made lowercase.
    term_length = models.ForeignKey('LkTermLength', models.DO_NOTHING, db_column='Term_Length_Id', verbose_name='Term')  # Field name made lowercase.
    segment_type = models.ForeignKey('LkSegmentType', models.DO_NOTHING, db_column='Segment_Type_Id', verbose_name='Opportunity Type')  # Field name made lowercase.
    mrr = models.DecimalField(db_column='MRR', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='MRR')  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    deleted = models.IntegerField(db_column='Deleted', blank=True, null=True)  # Field name made lowercase.
    deletedon = models.DateTimeField(db_column='DeletedOn', blank=True, null=True)  # Field name made lowercase.
    deletedby = models.CharField(db_column='DeletedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'app_SF_DealInHand'


class AppUserFeedback(models.Model):
    user_feedback_id = models.AutoField(db_column='User_Feedback_Id', primary_key=True)
    auth_user_id = models.ForeignKey('AuthUser', models.DO_NOTHING, db_column='Auth_User_Id')  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=255, blank=True, null=True)  # Field name made lowercase.
    comments = models.TextField(db_column='Comments', blank=True, null=True)  # Field name made lowercase.
    path = models.FileField(upload_to='feedback_upload/', blank=True, null=True, verbose_name='File (where necessary)')  # Field name made lowercase.
    root = models.CharField(db_column='Root', max_length=255, blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'app_User_Feedback'


class AppUserGroupPermission(models.Model):
    user_group_permission_id = models.AutoField(db_column='User_Group_Permission_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    user_group = models.ForeignKey('LkUserGroup', models.DO_NOTHING, db_column='User_Group_Id')  # Field name made lowercase.
    cansubmit = models.IntegerField(db_column='CanSubmit', blank=True, null=True)  # Field name made lowercase.
    canapprove = models.IntegerField(db_column='CanApprove', blank=True, null=True)  # Field name made lowercase.
    caneditsubmitted = models.IntegerField(db_column='CanEditSubmitted', blank=True, null=True)  # Field name made lowercase.
    caneditapproved = models.IntegerField(db_column='CanEditApproved', blank=True, null=True)  # Field name made lowercase.
    car_maxapproval = models.DecimalField(db_column='CAR_MaxApproval', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    car_minapproval = models.DecimalField(db_column='CAR_MinApproval', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    irr_maxapproval = models.DecimalField(db_column='IRR_MaxApproval', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    irr_minapproval = models.DecimalField(db_column='IRR_MinApproval', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'app_User_Group_Permission'


class AppUserProfile(models.Model):
    user_profile_id = models.AutoField(db_column='User_Profile_Id', primary_key=True)
    auth_user_id = models.ForeignKey('AuthUser', models.DO_NOTHING, db_column='Auth_User_Id')  # Field name made lowercase. #models.IntegerField(db_column='Auth_User_Id', blank=True, null=True)
    name = models.CharField(db_column='Name', max_length=255, blank=True, null=True)  # Field name made lowercase.
    region = models.ForeignKey('LkRegion', models.DO_NOTHING, db_column='Region_Id')  # Field name made lowercase.
    user_group = models.ForeignKey('LkUserGroup', models.DO_NOTHING, db_column='User_Group_Id')  # Field name made lowercase.
    user_group_permission = models.ForeignKey(AppUserGroupPermission, models.DO_NOTHING, db_column='User_Group_Permission_Id')  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'app_User_Profile'


class AssumpDataCenterCircuitEoy(models.Model):
    record_id = models.AutoField(db_column='Record_Id', primary_key=True)
    data_center_circuit_eoy_assump_id = models.IntegerField(db_column='Data_Center_Circuit_EOY_Assump_Id', blank=False, null=False)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    data_center_type = models.ForeignKey('LkDataCenterType', models.DO_NOTHING, db_column='Data_Center_Type_Id')  # Field name made lowercase.
    yr = models.IntegerField(db_column='Yr', blank=True, null=True)  # Field name made lowercase.
    circuit_ct = models.IntegerField(db_column='Circuit_Ct', blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'assump_Data_Center_Circuit_EOY'

class AssumpDataCenterEquipType(models.Model):
    data_center_equip_type_assump_id = models.AutoField(db_column='Data_Center_Equip_Type_Assump_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    data_center_equip_type = models.ForeignKey('LkDataCenterEquipType', models.DO_NOTHING, db_column='Data_Center_Equip_Type_Id')  # Field name made lowercase.
    capex = models.DecimalField(db_column='Capex', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    amp_per_ac = models.DecimalField(db_column='Amp_Per_AC', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    amps = models.IntegerField(db_column='AMPS', blank=True, null=True)  # Field name made lowercase.
    opex = models.DecimalField(db_column='Opex', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'assump_Data_Center_Equip_Type'

class AssumpDataCenterType(models.Model):
    data_center_type_assump_id = models.AutoField(db_column='Data_Center_Type_Assump_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    data_center_type = models.ForeignKey('LkDataCenterType', models.DO_NOTHING, db_column='Data_Center_Type_Id')  # Field name made lowercase.
    data_center_equip_type = models.ForeignKey('LkDataCenterEquipType', models.DO_NOTHING, db_column='Data_Center_Equip_Type_Id')  # Field name made lowercase.
    rack = models.DecimalField(db_column='Rack', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    mrr_per_circ_avg = models.DecimalField(db_column='MRR_Per_Circ_Avg', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    colo_fee = models.DecimalField(db_column='Colo_Fee', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    connect_cost = models.DecimalField(db_column='Connect_Cost', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    opex_pct = models.DecimalField(db_column='Opex_Pct', max_digits=5, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'assump_Data_Center_Type'


class AssumpMduBuild(models.Model):
    mdu_build_assump_id = models.AutoField(db_column='MDU_Build_Assump_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=255, blank=True, null=True)  # Field name made lowercase.
    mdu_build_type = models.ForeignKey('LkMduBuildType', models.DO_NOTHING, db_column='MDU_Build_Type_Id')  # Field name made lowercase.
    current_service_type = models.ForeignKey('LkCurrentServiceType', models.DO_NOTHING, db_column='Current_Service_Type_Id')  # Field name made lowercase.
    mdu_build_region_assump = models.ForeignKey('AssumpMduBuildRegion', models.DO_NOTHING, db_column='MDU_Build_Region_Assump_Id', blank=True, null=True)  # Field name made lowercase.
    video_penetration = models.DecimalField(db_column='Video_Penetration', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    data_penetration = models.DecimalField(db_column='Data_Penetration', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    voice_penetration = models.DecimalField(db_column='Voice_Penetration', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    video_arpu = models.DecimalField(db_column='Video_ARPU', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    data_arpu = models.DecimalField(db_column='Data_ARPU', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    voice_arpu = models.DecimalField(db_column='Voice_ARPU', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    video_rev_share = models.DecimalField(db_column='Video_Rev_Share', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    data_rev_share = models.DecimalField(db_column='Data_Rev_Share', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    voice_rev_share = models.DecimalField(db_column='Voice_Rev_Share', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    isp_per_unit = models.DecimalField(db_column='ISP_Per_Unit', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    door_fees = models.DecimalField(db_column='Door_Fees', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    min_passings = models.DecimalField(db_column='Min_Passings', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    opex_load = models.DecimalField(db_column='Opex_Load', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    converter = models.DecimalField(db_column='Converter', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    modem = models.DecimalField(db_column='Modem', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    emta = models.DecimalField(db_column='eMTA', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    penetration_ramp = models.IntegerField(db_column='Penetration_Ramp', blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'assump_MDU_Build'

    def __str__(self):
        return self.name


class AssumpMduBuildRegion(models.Model):
    mdu_build_region_assump_id = models.AutoField(db_column='MDU_Build_Region_Assump_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=255, blank=True, null=True)  # Field name made lowercase.
    region = models.ForeignKey('LkRegion', models.DO_NOTHING, db_column='Region_Id')  # Field name made lowercase.
    video_penetration = models.DecimalField(db_column='Video_Penetration', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    data_penetration = models.DecimalField(db_column='Data_Penetration', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    voice_penetration = models.DecimalField(db_column='Voice_Penetration', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    video_arpu = models.DecimalField(db_column='Video_ARPU', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    data_arpu = models.DecimalField(db_column='Data_ARPU', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    voice_arpu = models.DecimalField(db_column='Voice_ARPU', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'assump_MDU_Build_Region'


class AssumpRegion(models.Model):
    region_assump_id = models.AutoField(db_column='Region_Assump_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    region = models.ForeignKey('LkRegion', models.DO_NOTHING, db_column='Region_Id')  # Field name made lowercase.
    smb_arpu = models.DecimalField(db_column='SMB_ARPU', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    ent_arpu = models.DecimalField(db_column='ENT_ARPU', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    smb_12mo_pen = models.DecimalField(db_column='SMB_12mo_Pen', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    smb_36mo_pen = models.DecimalField(db_column='SMB_36mo_Pen', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    ent_12mo_pen = models.DecimalField(db_column='ENT_12mo_Pen', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    ent_36mo_pen = models.DecimalField(db_column='ENT_36mo_Pen', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=50, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'assump_Region'

    def id(self):
        return self.region_assump_id

class AssumpSegment(models.Model):
    segment_assump_id = models.AutoField(db_column='Segment_Assump_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    segment_type = models.ForeignKey('LkSegmentType', models.DO_NOTHING, db_column='Segment_Type_Id')  # Field name made lowercase.
    capex = models.DecimalField(db_column='Capex', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    capex_data_and_install = models.DecimalField(db_column='Capex_Data_and_Install', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    capex_voice_and_install = models.DecimalField(db_column='Capex_Voice_and_Install', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    capex_video_and_install = models.DecimalField(db_column='Capex_Video_and_Install', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    maint_opex = models.DecimalField(db_column='Maint_Opex', max_digits=20, decimal_places=2, blank=True, null=True)  # Field name made lowercase.
    opex_load = models.DecimalField(db_column='Opex_Load', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    churn = models.DecimalField(db_column='Churn', max_digits=5, decimal_places=3, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=50, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'assump_Segment'


class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=80)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)
    permission = models.ForeignKey('AuthPermission', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group', 'permission'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255)
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING)
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type', 'codename'),)


class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.BooleanField()
    username = models.CharField(unique=True, max_length=150)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    email = models.CharField(max_length=254)
    is_staff = models.BooleanField()
    is_active = models.BooleanField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        unique_together = (('user', 'group'),)


class AuthUserUserPermissions(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    permission = models.ForeignKey(AuthPermission, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user', 'permission'),)


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.SmallIntegerField()
    change_message = models.TextField()
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING, blank=True, null=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'

class LkBdr(models.Model):
    bdr_id = models.AutoField(db_column='BDR_Id', primary_key=True)  # Field name made lowercase.
    region_id = models.IntegerField(db_column='Region_Id', blank=True, null=True)  # Field name made lowercase.
    bdr_pernr = models.CharField(db_column='BDR_Pernr', max_length=50, blank=True, null=True)  # Field name made lowercase.
    bdr_ntlogin = models.CharField(db_column='BDR_NTLogin', max_length=50, blank=True, null=True)  # Field name made lowercase.
    bdr_firstname = models.CharField(db_column='BDR_FirstName', max_length=150, blank=True, null=True)  # Field name made lowercase.
    bdr_lastname = models.CharField(db_column='BDR_LastName', max_length=150, blank=True, null=True)  # Field name made lowercase.
    manager_pernr = models.CharField(db_column='Manager_Pernr', max_length=50, blank=True, null=True)  # Field name made lowercase.
    manager_ntlogin = models.CharField(db_column='Manager_NTLogin', max_length=50, blank=True, null=True)  # Field name made lowercase.
    manager_firstname = models.CharField(db_column='Manager_FirstName', max_length=150, blank=True, null=True)  # Field name made lowercase.
    manager_lastname = models.CharField(db_column='Manager_LastName', max_length=150, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_BDR'

    def __str__(self):
        return str(self.bdr_firstname) + ' ' + str(self.bdr_lastname)

class LkBuildType(models.Model):
    build_type_id = models.AutoField(db_column='Build_Type_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Build_Type'

    def __str__(self):
        return str(self.name)


class LkBuildingType(models.Model):
    building_type_id = models.AutoField(db_column='Building_Type_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Building_Type'

    def __str__(self):
        return str(self.name)


class LkConduitType(models.Model):
    conduit_type_id = models.AutoField(db_column='Conduit_Type_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Conduit_Type'

    def __str__(self):
        return str(self.name)


class LkCurrentServiceType(models.Model):
    current_service_type_id = models.AutoField(db_column='Current_Service_Type_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Current_Service_Type'

    def __str__(self):
        return str(self.name)


class LkDataCenterEquipType(models.Model):
    data_center_equip_type_id = models.AutoField(db_column='Data_Center_Equip_Type_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Data_Center_Equip_Type'

    def __str__(self):
        return str(self.name)


class LkDataCenterType(models.Model):
    data_center_type_id = models.AutoField(db_column='Data_Center_Type_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Data_Center_Type'

    def __str__(self):
        return str(self.name)


class LkDownloadSpeed(models.Model):
    download_speed_id = models.AutoField(db_column='Download_Speed_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Download_Speed'

    def __str__(self):
        return str(self.name)


class LkDwellingType(models.Model):
    dwelling_type_id = models.AutoField(db_column='Dwelling_Type_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Dwelling_Type'

    def __str__(self):
        return str(self.name)

class LkDispositionType(models.Model):
    disposition_type_id = models.AutoField(db_column='Disposition_Type_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Disposition_Type'

    def __str__(self):
        return str(self.name)

class LkFileType(models.Model):
    file_type_id = models.AutoField(db_column='File_Type_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_File_Type'

    def __str__(self):
        return str(self.name)

class LkMduBuildType(models.Model):
    mdu_build_type_id = models.AutoField(db_column='MDU_Build_Type_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_MDU_Build_Type'

    def __str__(self):
        return str(self.name)


class LkNoteType(models.Model):
    note_type_id = models.AutoField(db_column='Note_Type_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Note_Type'

    def __str__(self):
        return str(self.name)


class LkRegion(models.Model):
    region_id = models.AutoField(db_column='Region_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    lead_email = models.CharField(db_column='Lead_Email', max_length=150, blank=True, null=True)  # Field name made lowercase.
    lead_backup_email = models.CharField(db_column='Lead_Backup_Email', max_length=150, blank=True, null=True)  # Field name made lowercase.
    invest_committ_email_distro = models.CharField(db_column='Invest_Committ_Email_Distro', max_length=150, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=50, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    review_email = models.CharField(db_column='Review_Email', max_length=150, blank=True, null=True)  # Field name made lowercase.
    construction_email = models.CharField(db_column='Construction_Email', max_length=150, blank=True, null=True)  # Field name made lowercase.
    other_email = models.CharField(db_column='Other_Email', max_length=150, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Region'
        verbose_name = 'Region'
        verbose_name_plural = 'Regions'

    def __str__(self):
        return str(self.name)

    def id(self):
        return self.region_id


class LkRoeStatus(models.Model):
    roe_status_id = models.AutoField(db_column='ROE_Status_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_ROE_Status'

    def __str__(self):
        return str(self.name)

class LkSearchType(models.Model):
    search_type_id = models.AutoField(db_column='Search_Type_Id', primary_key=True, blank=True, verbose_name='Search Type')  # Field name made lowercase.
    display_order = models.IntegerField(db_column='Display_Order', blank=True, null=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    stored_procedure = models.CharField(db_column='Stored_Procedure', max_length=255, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Search_Type'

    def __str__(self):
        return str(self.name)

class LkSegmentType(models.Model):
    segment_type_id = models.AutoField(db_column='Segment_Type_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Segment_Type'

    def __str__(self):
        return str(self.name)


class LkState(models.Model):
    state_id = models.AutoField(db_column='State_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    abbrev = models.CharField(db_column='Abbrev', max_length=2, blank=True, null=True)  # Field name made lowercase.
    region = models.ForeignKey(LkRegion, models.DO_NOTHING, db_column='Region_Id')  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_State'

    def __str__(self):
        return str(self.name)


class LkSurveyType(models.Model):
    survey_type_id = models.AutoField(db_column='Survey_Type_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Survey_Type'

    def __str__(self):
        return str(self.name)

class LkTermLength(models.Model):
    term_length_id = models.AutoField(db_column='Term_Length_Id', primary_key=True)  # Field name made lowercase.
    term = models.IntegerField(db_column='Term', blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Term_Length'

    def __str__(self):
        return str(self.term)


class LkTransportType(models.Model):
    transport_type_id = models.AutoField(db_column='Transport_Type_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Transport_Type'

    def __str__(self):
        return str(self.name)


class LkUploadType(models.Model):
    upload_type_id = models.AutoField(db_column='Upload_Type_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_Upload_Type'

    def __str__(self):
        return str(self.name)


class LkUserGroup(models.Model):
    user_group_id = models.AutoField(db_column='User_Group_Id', primary_key=True)  # Field name made lowercase.
    name = models.CharField(db_column='Name', max_length=100, blank=True, null=True)  # Field name made lowercase.
    isactive = models.IntegerField(db_column='IsActive', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    editedon = models.DateTimeField(db_column='EditedOn', blank=True, null=True)  # Field name made lowercase.
    editedby = models.CharField(db_column='EditedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'lk_User_Group'


class RegistrationRegistrationprofile(models.Model):
    status = models.CharField(max_length=10)
    activation_key = models.CharField(max_length=40, blank=True, null=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING, unique=True)

    class Meta:
        managed = False
        db_table = 'registration_registrationprofile'

class RptCalculator(models.Model):
    record_id = models.AutoField(db_column='Record_Id', primary_key=True)
    region = models.ForeignKey('LkRegion', models.DO_NOTHING, db_column='Region_Id', blank=True, null=True)  # Field name made lowercase.
    region_assump = models.ForeignKey('AssumpRegion', models.DO_NOTHING, db_column='Region_Assump_Id', blank=True, null=True)  # Field name made lowercase.
    customer_contribution = models.DecimalField(db_column='Customer_Contribution', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Customer Contribution')
    row_est_build_cost = models.DecimalField(db_column='ROW_Est_Build_Cost', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Estimated Build Cost ROW')  # Field name made lowercase.
    headend_cost = models.DecimalField(db_column='HeadEnd_Cost', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Head End / Node / V-Hub Cost')  # Field name made lowercase.
    transport_cost = models.DecimalField(db_column='Transport_Cost', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Transportation / Distribution Cost')  # Field name made lowercase.
    private_property_cost = models.DecimalField(db_column='Private_Property_Cost', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Private Property Cost (including material)')
    smb_arpu = models.DecimalField(db_column='SMB_ARPU', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='SMB ARPU')  # Field name made lowercase.
    ent_arpu = models.DecimalField(db_column='ENT_ARPU', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='ENT ARPU')  # Field name made lowercase.
    smb_12mo_pen = models.DecimalField(db_column='SMB_12mo_Pen', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='SMB Penetration 12 Mo', validators=[validate_number_greather_than_zero])  # Field name made lowercase.
    smb_36mo_pen = models.DecimalField(db_column='SMB_36mo_Pen', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='SMB Penetration 36 Mo')  # Field name made lowercase.
    ent_12mo_pen = models.DecimalField(db_column='ENT_12mo_Pen', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='ENT Penetration 12 Mo')  # Field name made lowercase.
    ent_36mo_pen = models.DecimalField(db_column='ENT_36mo_Pen', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='ENT Penetration 36 Mo')  # Field name made lowercase.
    lateral_construct_upfront_pct = models.DecimalField(db_column='Lateral_Construct_Upfront_Pct', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='% of Laterals Constructed Upfront')  # Field name made lowercase.
    fund_bucket = models.CharField(db_column='Fund_Bucket', max_length=255, blank=True, null=True, verbose_name='Funding Bucket')  # Field name made lowercase.
    building_ct = models.IntegerField(db_column='Building_Ct', blank=True, null=True, verbose_name='# of Buildings')  # Field name made lowercase.
    multi_tenant_building_ct = models.IntegerField(db_column='Multi_Tenant_Building_Ct', blank=True, null=True, verbose_name='# of Multi-Tenant Buildings')  # Field name made lowercase.
    mdu_ct = models.IntegerField(db_column='MDU_Ct', blank=True, null=True, verbose_name='# of MDUs')  # Field name made lowercase.
    datacenter_ct = models.IntegerField(db_column='DataCenter_Ct', blank=True, null=True, verbose_name='# of Data Centers')  # Field name made lowercase.
    smb_qb_ct = models.IntegerField(db_column='SMB_QB_Ct', blank=True, null=True, verbose_name='SMB QBs')  # Field name made lowercase.
    ent_qb_ct = models.IntegerField(db_column='ENT_QB_Ct', blank=True, null=True, verbose_name='ENT QBs')  # Field name made lowercase.
    smb_dealinhand_ct = models.IntegerField(db_column='SMB_DealInHand_Ct', blank=True, null=True, verbose_name='# of SMB Deals In Hand')  # Field name made lowercase.
    smb_dealinhand_mrc = models.DecimalField(db_column='SMB_DealInHand_MRC', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='SMB Deal In Hand MRC')  # Field name made lowercase.
    ent_dealinhand_ct = models.IntegerField(db_column='ENT_DealInHand_Ct', blank=True, null=True, verbose_name='# of ENT Deals In Hand')  # Field name made lowercase.
    ent_dealinhand_mrc = models.DecimalField(db_column='ENT_DealInHand_MRC', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='ENT Deal In Hand MRC')  # Field name made lowercase.
    row_car_value = models.DecimalField(db_column='ROW_CAR_Value', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='$ ROW CAR')  # Field name made lowercase.
    lat_car_value = models.DecimalField(db_column='Lat_CAR_Value', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='$ Lateral CAR')  # Field name made lowercase.
    total_car_value = models.DecimalField(db_column='Total_CAR_Value', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='$ Estimated Total Expenditure')  # Field name made lowercase.
    irr_pct = models.DecimalField(db_column='IRR_Pct', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='IRR')  # Field name made lowercase.
    irr_pct_less_he_trnsprt = models.DecimalField(db_column='IRR_Pct_Less_HE_Trnsprt', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='IRR (Less HE & Transport)')  # Field name made lowercase.
    npv = models.DecimalField(db_column='NPV', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='NPV')  # Field name made lowercase.
    npv_less_he_trnsprt = models.DecimalField(db_column='NPV_Less_HE_Trnsprt', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='NPV (Less HE & Transport)')  # Field name made lowercase.
    payback_mo = models.IntegerField(db_column='Payback_Mo', blank=True, null=True, verbose_name='Payback Month')  # Field name made lowercase.
    passing_cost_per = models.DecimalField(db_column='Passing_Cost_Per', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Cost Per Passing')  # Field name made lowercase.
    additional_osp_lateral_cost_per_connect = models.DecimalField(db_column='Additional_OSP_Lateral_Cost_per_Connect', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Additional OSP Lateral Cost/Cx')  # Field name made lowercase.
    business_max_actual_capital = models.DecimalField(db_column='Business_Max_Actual_Capital', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Business NPV')
    resi_max_actual_capital = models.DecimalField(db_column='Resi_Max_Actual_Capital', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Residential NPV')
    business_capital_pct = models.DecimalField(db_column='Business_Capital_Pct', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='% Business')
    resi_capital_pct = models.DecimalField(db_column='Resi_Capital_Pct', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='% Residential')

    class Meta:
        managed = False
        db_table = 'rpt_Calculator'


class RptProbuild(models.Model):
    record_id = models.AutoField(db_column='Record_Id', primary_key=True)
    probuild = models.IntegerField(db_column='Probuild_Id', blank=True, null=True)  # Field name made lowercase.
    #probuild = models.ForeignKey('AppProbuild', models.DO_NOTHING, db_column='Probuild_Id')  # Field name made lowercase.
    lateral_construct_upfront_pct = models.DecimalField(db_column='Lateral_Construct_Upfront_Pct', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='% of Laterals Constructed Upfront')  # Field name made lowercase.
    fund_bucket = models.CharField(db_column='Fund_Bucket', max_length=255, blank=True, null=True, verbose_name='Funding Bucket')  # Field name made lowercase.
    smb_qb_ct = models.IntegerField(db_column='SMB_QB_Ct', blank=True, null=True, verbose_name='SMB QBs')  # Field name made lowercase.
    ent_qb_ct = models.IntegerField(db_column='ENT_QB_Ct', blank=True, null=True, verbose_name='ENT QBs')  # Field name made lowercase.
    building_ct = models.IntegerField(db_column='Building_Ct', blank=True, null=True, verbose_name='# of Buildings')  # Field name made lowercase.
    multi_tenant_building_ct = models.IntegerField(db_column='Multi_Tenant_Building_Ct', blank=True, null=True, verbose_name='# of Multi-Tenant Buildings')  # Field name made lowercase.
    dealinhand_ct = models.IntegerField(db_column='DealInHand_Ct', blank=True, null=True, verbose_name='# of Deals In Hand')  # Field name made lowercase.
    mdu_ct = models.IntegerField(db_column='MDU_Ct', blank=True, null=True, verbose_name='# of MDUs')  # Field name made lowercase.
    datacenter_ct = models.IntegerField(db_column='DataCenter_Ct', blank=True, null=True, verbose_name='# of Data Centers')  # Field name made lowercase.
    car_value = models.DecimalField(db_column='CAR_Value', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='CAR Value')  # Field name made lowercase.
    irr_pct = models.DecimalField(db_column='IRR_Pct', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='IRR')  # Field name made lowercase.
    irr_pct_less_he_trnsprt = models.DecimalField(db_column='IRR_Pct_Less_HE_Trnsprt', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='IRR (Less HE & Transport)')  # Field name made lowercase.
    npv = models.DecimalField(db_column='NPV', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='NPV')  # Field name made lowercase.
    npv_less_he_trnsprt = models.DecimalField(db_column='NPV_Less_HE_Trnsprt', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='NPV (Less HE & Transport)')  # Field name made lowercase.
    payback_mo = models.IntegerField(db_column='Payback_Mo', blank=True, null=True, verbose_name='Payback Month')  # Field name made lowercase.
    passing_cost_per = models.DecimalField(db_column='Passing_Cost_Per', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Cost Per Passing')  # Field name made lowercase.
    additional_osp_lateral_cost_per_connect = models.DecimalField(db_column='Additional_OSP_Lateral_Cost_per_Connect', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Additional OSP Lateral Cost/Cx')  # Field name made lowercase.
    business_max_actual_capital = models.DecimalField(db_column='Business_Max_Actual_Capital', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Business Max Cap')
    resi_max_actual_capital = models.DecimalField(db_column='Resi_Max_Actual_Capital', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='Residential Max Cap')
    business_capital_pct = models.DecimalField(db_column='Business_Capital_Pct', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='% Business')
    resi_capital_pct = models.DecimalField(db_column='Resi_Capital_Pct', max_digits=5, decimal_places=3, blank=True, null=True, verbose_name='% Residential')
    saved = models.IntegerField(db_column='Saved', blank=True, null=True)  # Field name made lowercase.
    submitted = models.IntegerField(db_column='Submitted', blank=True, null=True)  # Field name made lowercase.
    approved = models.IntegerField(db_column='Approved', blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True, verbose_name='Case Created On')  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True, verbose_name='Case Created By')  # Field name made lowercase.
    deleted = models.IntegerField(db_column='Deleted', blank=True, null=True)  # Field name made lowercase.
    deletedon = models.DateTimeField(db_column='DeletedOn', blank=True, null=True)  # Field name made lowercase.
    deletedby = models.CharField(db_column='DeletedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.
    row_car_value = models.DecimalField(db_column='ROW_CAR_Value', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='$ ROW CAR')  # Field name made lowercase.
    lat_car_value = models.DecimalField(db_column='Lat_CAR_Value', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='$ Lateral CAR')  # Field name made lowercase.
    total_car_value = models.DecimalField(db_column='Total_CAR_Value', max_digits=20, decimal_places=2, blank=True, null=True, verbose_name='$ Estimated Total Expenditure')  # Field name made lowercase.
    roe_needed = models.IntegerField(db_column='ROE_Needed', blank=True, null=True, verbose_name='# of ROE (Passings) Needed')  # Field name made lowercase.
    roe_acquired = models.IntegerField(db_column='ROE_Acquired', blank=True, null=True, verbose_name='# of ROE (Passings) Acquired')  # Field name made lowercase.
    roe_target = models.IntegerField(db_column='ROE_Target', blank=True, null=True, verbose_name='# of ROE (Passings) Targeted')  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'rpt_Probuild'

class RptProbuildDictLog(models.Model):
    record_id = models.AutoField(db_column='record_id', primary_key=True)
    probuild = models.ForeignKey('AppProbuild', models.DO_NOTHING, db_column='Probuild_Id')  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True, verbose_name="Added On")  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True, verbose_name="Added By")  # Field name made lowercase.
    probuild_dict = models.TextField(db_column='Probuild_Dict', blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'rpt_Probuild_Dict_Log'

class RptProbuildStatusLog(models.Model):
    record_id = models.AutoField(db_column='record_id', primary_key=True)
    probuild = models.ForeignKey('AppProbuild', models.DO_NOTHING, db_column='Probuild_Id')  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True, verbose_name="Added On")  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True, verbose_name="Added By")  # Field name made lowercase.
    status = models.CharField(db_column='Status', max_length=50, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'rpt_Probuild_Status_Log'

class RptSearchType(models.Model):
    record_id = models.AutoField(db_column='record_id', primary_key=True)
    search_type_id = models.ForeignKey('LkSearchType', models.DO_NOTHING, db_column='Search_Type_Id', blank=True, null=True, verbose_name='Search Type')  # Field name made lowercase.
    search_value = models.CharField(db_column='Search_Value', max_length=255, blank=True, null=True, verbose_name='Search Value')
    stored_procedure = models.CharField(db_column='Stored_Procedure', max_length=255, blank=True, null=True)  # Field name made lowercase.
    addedon = models.DateTimeField(db_column='AddedOn', blank=True, null=True)  # Field name made lowercase.
    addedby = models.CharField(db_column='AddedBy', max_length=100, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        managed = False
        db_table = 'rpt_Search_Type'