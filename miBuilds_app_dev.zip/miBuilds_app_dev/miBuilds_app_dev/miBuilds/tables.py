import django_tables2 as tables
from django_tables2.utils import A
from miBuilds.models import (AppProbuild,
                            AppProbuildNote,
                            AppBuilding,
                            AppBusiness,
                            AppMdu,
                            AppDatacenter,
                            AppSfDealinhand,
                            AppFile,
                            )

class BusinessCaseSearchTable(tables.Table):
    view_template = """
        <button id="id_view_record" class="navBtn"
        onClick="location.href='{% url 'business_case_edit' record.probuild_id %}'">View</button>
    """
    delete_template = """
        <button id="id_delete_record" class="delBtn">Delete</button>
    """

    status = tables.Column(accessor='status', verbose_name="Case Status")
    view = tables.TemplateColumn(view_template)
    delete = tables.TemplateColumn(delete_template)

    class Meta:
        model = AppProbuild
        fields = ('name','region','build_type','transport_type',
                'addedon','addedby','status')
        order_by = ('-addedon')
        attrs = {'class': 'bizTable'}
        row_attrs = {
            'probuild_id': lambda record: record.probuild_id,
            'addedby': lambda record: record.addedby
        }

class BusinessCaseAddedTable(tables.Table):
    view_template = """
        <button id="id_view_record" class="navBtn"
        onClick="location.href='{% url 'business_case_edit' record.probuild_id %}'">View</button>
    """
    delete_template = """
        <button id="id_delete_record" class="delBtn">Delete</button>
    """
    view = tables.TemplateColumn(view_template)
    delete = tables.TemplateColumn(delete_template)

    class Meta:
        model = AppProbuild
        fields = ('name','region','build_type','transport_type',
                'addedon','addedby')
        order_by = ('-addedon')
        attrs = {'class': 'bizTable'}
        row_attrs = {
            'probuild_id': lambda record: record.probuild_id,
            'addedby': lambda record: record.addedby
        }

class BusinessCaseSubmittedTable(tables.Table):
    view_template = """
        <button id="id_view_record" class="navBtn"
        onClick="location.href='{% url 'business_case_edit' record.probuild_id %}'">View</button>
    """
    delete_template = """
        <button id="id_delete_record" class="delBtn" addedby="{{ record.addedby }}">Delete</button>
    """
    #fund_bucket = tables.Column(accessor='fund_bucket',
            #verbose_name="Funding Bucket")
    view = tables.TemplateColumn(view_template)
    delete = tables.TemplateColumn(delete_template)

    class Meta:
        model = AppProbuild
        fields = ('name','region','build_type','transport_type',
                'submittedon','submittedby')
        order_by = ('-submittedon')
        row_attrs = {
            'probuild_id': lambda record: record.probuild_id,
            'addedby': lambda record: record.addedby
        }

class BusinessCaseApprovedTable(tables.Table):
    view_template = """
        <button id="id_view_record" class="navBtn"
        onClick="location.href='{% url 'business_case_edit' record.probuild_id %}'">View</button>
    """
    delete_template = """
        <button id="id_delete_record" class="delBtn">Delete</button>
    """
    export_template = """
        <button id="id_view_record" class="navBtn"
        onClick="location.href='{% url 'construction_business_case_summary' record.probuild_id %}'">Summary</button>
    """
    view = tables.TemplateColumn(view_template)
    delete = tables.TemplateColumn(delete_template)
    export = tables.TemplateColumn(export_template)

    class Meta:
        model = AppProbuild
        fields = ('name','region','build_type','transport_type',
                'approvedon','approvedby')
        order_by = ('-approvedon')
        #attrs = {'class': 'bizTable'}
        row_attrs = {
            'probuild_id': lambda record: record.probuild_id,
            'addedby': lambda record: record.addedby
        }

class BusinessCaseNoteTable(tables.Table):
    email_template = """
            <button id="id_email_record" class="emailBtn">Email</button>
        """
    #delete_template = """
        #<button id="id_delete_record" class="delBtn">Delete</button>
        #"""
    email = tables.TemplateColumn(email_template)
    #delete = tables.TemplateColumn(delete_template)

    class Meta:
        model = AppProbuildNote
        exclude = ('probuild_note_id','probuild', 'auth_user_id',
                    'editedby','editedon',
                    'deleted', 'deletedon', 'deletedby')
        sequence = ('note_type', 'note', 'addedon', 'addedby', 'email')
        #attrs = {'th': {'id': 'tblHeader'}}
        row_attrs = {
            'probuild_note_id': lambda record: record.probuild_note_id
        }


class BuildingTable(tables.Table):
    edit_template = """
        <button class="navBtn" style="visibility:hidden" id="id_edit_record"
        onClick="location.href='{% url 'building_edit' record.record_id %}'">Edit</button>
        """
    delete_template = """
        <button class="delBtn" style="visibility:hidden"
        id="id_delete_record">Delete</button>
        """
    select_template = """
        <input type="checkbox" class="chkBox" style="visibility:hidden"
        id="id_select_record"</input>
    """
    edit = tables.TemplateColumn(edit_template)
    delete = tables.TemplateColumn(delete_template)
    select = tables.TemplateColumn(select_template)
    #dwelling_type = tables.Column(attrs={'td': {'bgcolor': ''}})

    class Meta:
        model = AppBuilding
        exclude = ('record_id','probuild',
                    'addedon','addedby','editedby','editedon',
                    'deleted', 'deletedon', 'deletedby')
        #attrs = {'th': {'id': 'tblHeader'}}
        row_attrs = {
            'record_id': lambda record: record.record_id
        }

class BusinessTable(tables.Table):
    edit_template = """
        <button class="navBtn" style="visibility:hidden" id="id_edit_record"
        onClick="location.href='{% url 'business_edit' record.record_id %}'">Edit</button>
        """
    delete_template = """
        <button  class="delBtn" style="visibility:hidden"
        id="id_delete_record">Delete</button>
        """
    select_template = """
        <input type="checkbox" class="chkBox" style="visibility:hidden"
        id="id_select_record"</input>
        """
    edit = tables.TemplateColumn(edit_template)
    delete = tables.TemplateColumn(delete_template)
    select = tables.TemplateColumn(select_template)

    class Meta:
        model = AppBusiness
        exclude = ('record_id','probuild', 'address_id', 'segment_assump',
                    'addedon','addedby','editedby','editedon',
                    'deleted', 'deletedon', 'deletedby')
        sequence = ('business_id','building_id','business_name',
                    'address_1', 'address_2', 'city', 'state', 'zip',
                    'sellability_color_coax', 'sellability_color_fiber',
                    'segment_type_id', 'mip_in_or_out',
                    'revised_segment_type_id','revised_segment_notes', 'roe_id',
                    'edit','delete','select')
        #attrs = {'th': {'id': 'tblHeader'}}
        row_attrs = {
            'record_id': lambda record: record.record_id
        }

class MduTable(tables.Table):
    edit_template = """
        <button class="navBtn" style="visibility:hidden" id="id_edit_record"
        onClick="location.href='{% url 'mdu_edit' record.mdu_id %}'">Edit</button>
        """
    delete_template = """
        <button class="delBtn" style="visibility:hidden"
        id="id_delete_record" >Delete</button>
        """
    edit = tables.TemplateColumn(edit_template)
    delete = tables.TemplateColumn(delete_template)

    class Meta:
        model = AppMdu
        fields = ('probuild','property_name','property_owner','est_compl_dt',
                'mdu_build_type', 'current_service_type')
        #attrs = {'th': {'id': 'tblHeader'}}
        row_attrs = {
            'mdu_id': lambda record: record.mdu_id
        }

class DataCenterTable(tables.Table):
    edit_template = """
        <button class="navBtn" style="visibility:hidden" id="id_edit_record"
        onClick="location.href='{% url 'data_center_edit' record.datacenter_id %}'">Edit</button>
        """
    delete_template = """
        <button class="delBtn" style="visibility:hidden"
        id="id_delete_record" >Delete</button>
        """
    edit = tables.TemplateColumn(edit_template)
    delete = tables.TemplateColumn(delete_template)

    class Meta:
        model = AppDatacenter
        fields = ('probuild','name','data_center_type','data_center_equip_type')
        #attrs = {'th': {'id': 'tblHeader'}}
        row_attrs = {
            'datacenter_id': lambda record: record.datacenter_id
        }

class DealInHandTable(tables.Table):
    edit_template = """
        <button class="navBtn" style="visibility:hidden" id="id_edit_record"
        onClick="location.href='{% url 'deal_in_hand_edit' record.sf_dealinhand_id %}'">Edit</button>
        """
    delete_template = """
        <button class="delBtn" style="visibility:hidden"
        id="id_delete_record" >Delete</button>
        """
    edit = tables.TemplateColumn(edit_template)
    delete = tables.TemplateColumn(delete_template)

    class Meta:
        model = AppSfDealinhand
        fields = ('opportunity_id','customer_name','term_length','segment_type','mrr')
        #attrs = {'th': {'id': 'tblHeader'}}
        row_attrs = {
            'sf_dealinhand_id': lambda record: record.sf_dealinhand_id
        }

class FileTable(tables.Table):
    view_template = """
        <button class="viewBtn" id="id_view_record"
        value="{{ record.path.url }}">View</button>
        """
    edit_template = """
        <button class="navBtn" style="visibility:hidden" id="id_edit_record"
        onClick="location.href='{% url 'file_edit' record.file_id %}'">Edit</button>
        """
    delete_template = """
        <button class="delBtn" style="visibility:hidden"
        id="id_delete_record" >Delete</button>
        """
    select_template = """
        <input type="checkbox" id="id_select_record" class="chkBox"</input>
    """
    view = tables.TemplateColumn(view_template)
    edit = tables.TemplateColumn(edit_template)
    delete = tables.TemplateColumn(delete_template)
    select = tables.TemplateColumn(select_template)

    class Meta:
        model = AppFile
        fields = ('name','file_type')
        #attrs = {'th': {'id': 'tblHeader'}}
        row_attrs = {
            'file_id': lambda record: record.file_id
        }
