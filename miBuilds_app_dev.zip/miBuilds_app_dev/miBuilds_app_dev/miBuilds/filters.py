from django.shortcuts import render, redirect, get_object_or_404
from django.views import generic
from django.conf import settings
from django.db import connection
from django import forms
import django_filters
from miBuilds.models import (
								AppProbuild,
								AppBuilding
                            )
from miBuilds.forms import BusinessCaseSearchForm

######################################################################
# Helper functions
######################################################################

class BusinessCaseFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(label='Build Name (contains)',
        lookup_expr='contains')
    addedby = django_filters.CharFilter(label='Case Created By (contains)',
        lookup_expr='contains')

    class Meta:
        model = AppProbuild
        #form = BusinessCaseSearchForm
        fields = ['name', 'addedby']
        #widgets = {	'name': forms.HiddenInput(),
        #            'addedby': forms.HiddenInput(),
        #        }