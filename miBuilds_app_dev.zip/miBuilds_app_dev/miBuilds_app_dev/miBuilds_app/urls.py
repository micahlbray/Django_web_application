"""miBuilds_app URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf import settings
from django.contrib import admin
from django.conf.urls import url, include
from django.conf.urls.static import static
from django.contrib.auth.views import (
                                        login,
                                        logout,
                                        password_reset,
                                        password_reset_done,
                                        password_reset_confirm,
                                        password_reset_complete,
                                        password_change,
                                        password_change_done,
                                    )
from django.views.generic import TemplateView
from miBuilds import views, ajax, exports, reports, services, pdfs
from marketing import views as mktg_views

urlpatterns = [
    url(r'^miBuilds/$', views.index, name='home'),
    url(r'^miBuilds/about/$', views.about, name='about'),
    url(r'^miBuilds/contact/$', views.contact, name='contact'),
    url(r'^miBuilds/calculator/$', views.calculator,
        name='calculator'),
    url(r'^miBuilds/building/add/upload/post_approval/$',
        views.building_add_upload_post_approval,
        name='building_add_upload_post_approval'),
    #url(r'^miBuilds/business/add/upload/post_approval/$',
    #    views.business_add_upload_post_approval,
    #    name='business_add_upload_post_approval'),
    
    ############################################################################
    #### miBuilds Business Case creation forms ###
    ############################################################################
    url(r'^miBuilds/business_case/select/$', views.business_case_select,
        name='business_case_select'),
    url(r'^miBuilds/business_case/select/failure$',
        views.business_case_select_failure, name='business_case_select_failure'),
    url(r'^miBuilds/business_case/search/$',
        views.business_case_search, name='business_case_search'),
    url(r'^miBuilds/business_case/add/$',
        views.business_case_add, name='business_case_add'),
    url(r'^miBuilds/business_case/add/(?P<probuild_id>\d+)/success/$',
        views.business_case_add_success, name='business_case_add_success'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/edit/$',
        views.business_case_edit, name='business_case_edit'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/check/failure/$',
        views.business_case_check_failure, name='business_case_check_failure'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/note/add/$',
        views.business_case_note_add, name='business_case_note_add'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/review/$',
        views.business_case_review, name='business_case_review'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/building/add/$',
        views.building_add, name='building_add'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/building/add/failure/$',
        views.building_add_failure, name='building_add_failure'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/building/add/upload/$',
        views.building_add_upload, name='building_add_upload'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/building/add/upload/failure/$',
        views.building_add_upload_failure, name='building_add_upload_failure'),
    url(r'^miBuilds/building/(?P<record_id>\d+)/edit/$', views.building_edit,
        name='building_edit'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/greenfield/building/add/upload/$',
        views.greenfield_building_add_upload,
        name='greenfield_building_add_upload'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/business/add/$',
        views.business_add, name='business_add'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/business/add/failure/$',
        views.business_add_failure, name='business_add_failure'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/business/add/upload/$',
        views.business_add_upload, name='business_add_upload'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/business/add/upload/failure/$',
        views.business_add_upload_failure, name='business_add_upload_failure'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/greenfield/business/add/upload/$',
        views.greenfield_business_add_upload,
        name='greenfield_business_add_upload'),
    url(r'^miBuilds/business/(?P<record_id>\d+)/edit/$', views.business_edit,
        name='business_edit'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/deal_in_hand/add/$',
        views.deal_in_hand_add, name='deal_in_hand_add'),
    url(r'^miBuilds/deal_in_hand/(?P<sf_dealinhand_id>\d+)/edit/$',
        views.deal_in_hand_edit, name='deal_in_hand_edit'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/mdu/add/$',
        views.mdu_add, name='mdu_add'),
    url(r'^miBuilds/mdu/(?P<mdu_id>\d+)/edit/$', views.mdu_edit, name='mdu_edit'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/data_center/add/$',
        views.data_center_add, name='data_center_add'),
    url(r'^miBuilds/data_center/(?P<datacenter_id>\d+)/edit/$',
        views.data_center_edit, name='data_center_edit'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/file/upload/$',
        views.file_upload, name='file_upload'),
    url(r'^miBuilds/file/(?P<file_id>\d+)/edit/$', views.file_edit, name='file_edit'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/cashflow/$',
        views.cashflow_view, name='cashflow_view'),
    url(r'^miBuilds/upload_test/$', views.upload_test, name='upload_test'),
    url(r'^miBuilds/upload_test/failure/$', views.upload_test_failure,
        name='upload_test_failure'),
    url(r'^miBuilds/upload_test/success/$', views.upload_test_success,
        name='upload_test_success'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/email_send/failure/$',
        views.email_send_failure,
        name='email_send_failure'),
    ############################################################################
    ### Reporting URLs ###
    ############################################################################
    url(r'^miBuilds/reporting/$', views.reporting_home, name='reporting_home'),
    url(r'^miBuilds/reporting/business_case_summary$',
        reports.business_case_summary_report, name='business_case_summary_report'),
    ############################################################################
    ### Review Business Case URLs ###
    ############################################################################
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/export_business_case_business/csv/$',
        exports.export_business_case_business, name='export_business_case_business'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/export/building_business_not_matched_report/csv/$',
        reports.building_business_not_matched_report,
        name='building_business_not_matched_report'),
    url(r'^miBuilds/business_case/(?P<probuild_id>\d+)/export/construction_business_case_summary/xlsx/$',
        reports.construction_business_case_summary,
        name='construction_business_case_summary'),
    ############################################################################
    ### Downloadable Templates ###
    ############################################################################
    url(r'^miBuilds/templates/building_upload_template/$',
        exports.export_building_upload_template, name='building_upload_template'),
    url(r'^miBuilds/templates/building_greenfield_upload_template/$',
        exports.export_building_greenfield_upload_template,
        name='building_greenfield_upload_template'),
    url(r'^miBuilds/templates/business_upload_template/$',
        exports.export_business_upload_template, name='business_upload_template'),
    url(r'^miBuilds/templates/business_greenfield_upload_template/$',
        exports.export_business_greenfield_upload_template,
        name='business_greenfield_upload_template'),
    ############################################################################
    ### AJAX URLs ###
    ############################################################################
    url(r'^ajax/get_user_permissions/$', ajax.get_user_permissions,
        name='get_user_permissions'),
    url(r'^ajax/get_business_case_status/$', ajax.get_business_case_status,
        name='get_business_case_status'),
    url(r'^ajax/get_business_case_status_and_user_group_permission/$',
        ajax.get_business_case_status_and_user_group_permission,
        name='get_business_case_status_and_user_group_permission'),
    url(r'^ajax/delete_business_case/$', ajax.delete_business_case,
        name='delete_business_case'),
    url(r'^ajax/select_state/$', ajax.select_state, name='select_state'),
    url(r'^ajax/assumps_region/$', ajax.assumps_region, name='assumps_region'),
    url(r'^ajax/email_business_case_note/$', ajax.email_business_case_note,
        name='email_business_case_note'),
    url(r'^ajax/alert_invalid_roe_id/$', ajax.alert_invalid_roe_id,
        name='alert_invalid_roe_id'),
    url(r'^ajax/autofill_building/$', ajax.autofill_building,
        name='autofill_building'),
    url(r'^ajax/highlight_building_unmatched/$', ajax.highlight_building_unmatched,
        name='highlight_building_unmatched'),
    url(r'^ajax/highlight_building_invalid_roe_id/$', 
        ajax.highlight_building_invalid_roe_id,
        name='highlight_building_invalid_roe_id'),
    url(r'^ajax/flag_building_serviceability/$', ajax.flag_building_serviceability,
        name='flag_building_serviceability'),
    url(r'^ajax/flag_building_dwelling_type/$', ajax.flag_building_dwelling_type,
        name='flag_building_dwelling_type'),
    url(r'^ajax/delete_building/$', ajax.delete_building, name='delete_building'),
    url(r'^ajax/delete_building_selection/$', ajax.delete_building_selection,
        name='delete_building_selection'),
    url(r'^ajax/autofill_business/$', ajax.autofill_business,
        name='autofill_business'),
    url(r'^ajax/highlight_business_invalid_roe_id/$', 
        ajax.highlight_business_invalid_roe_id,
        name='highlight_business_invalid_roe_id'),
    url(r'^ajax/highlight_business_unmatched/$', ajax.highlight_business_unmatched,
        name='highlight_business_unmatched'),
    url(r'^ajax/delete_business/$', ajax.delete_business, name='delete_business'),
    url(r'^ajax/delete_business_selection/$', ajax.delete_business_selection,
        name='delete_business_selection'),
    url(r'^ajax/autofill_deal_in_hand/$', ajax.autofill_deal_in_hand,
        name='autofill_deal_in_hand'),
    url(r'^ajax/delete_deal_in_hand/$', ajax.delete_deal_in_hand,
        name='delete_deal_in_hand'),
    url(r'^ajax/assumps_mdu/$', ajax.assumps_mdu, name='assumps_mdu'),
    url(r'^ajax/delete_mdu/$', ajax.delete_mdu, name='delete_mdu'),
    url(r'^ajax/assumps_data_center_type/$', ajax.assumps_data_center_type,
        name='assumps_data_center_type'),
    url(r'^ajax/assumps_data_center_equip/$', ajax.assumps_data_center_equip,
        name='assumps_data_center_equip'),
    url(r'^ajax/delete_data_center/$', ajax.delete_data_center,
        name='delete_data_center'),
    url(r'^ajax/delete_file/$', ajax.delete_file, name='delete_file'),
    url(r'^ajax/calcs_child_business_case/$', ajax.calcs_child_business_case,
        name='calcs_child_business_case'),
    url(r'^ajax/calcs_parent_business_case/$', ajax.calcs_parent_business_case,
        name='calcs_parent_business_case'),
    url(r'^ajax/calcs_calculator/$', ajax.calcs_calculator,
        name='calcs_calculator'),
    ############################################################################
    ### AJAX DataTables URLs ###
    ############################################################################
    ### Search
    url(r'^ajax/get_search_results_business_case_detail/$',
        ajax.get_search_results_business_case_detail,
        name='get_search_results_business_case_detail'),
    ### Business Case Select
    url(r'^ajax/get_pending_business_case_detail/$',
        ajax.get_pending_business_case_detail,
        name='get_pending_business_case_detail'),
    url(r'^ajax/get_submitted_business_case_detail/$',
        ajax.get_submitted_business_case_detail,
        name='get_submitted_business_case_detail'),
    url(r'^ajax/get_approved_business_case_detail/$',
        ajax.get_approved_business_case_detail,
        name='get_approved_business_case_detail'),
    url(r'^ajax/get_related_business_case_detail/$',
        ajax.get_related_business_case_detail,
        name='get_related_business_case_detail'),
    ### Building
    url(r'^ajax/get_building_add_detail/$',
        ajax.get_building_add_detail,
        name='get_building_add_detail'),
    ### Business
    url(r'^ajax/get_business_add_detail/$',
        ajax.get_business_add_detail,
        name='get_business_add_detail'),
    ############################################################################
    ### Spectrum URLs ###
    ############################################################################
    url(r'^spectrum/job_id=(?P<job_id>(\{?\w+\-?\}?){1,7})/$',
        services.spectrum_build_business_case, name='spectrum_build_business_case'),
    url(r'^spectrum_job/add/failure/$',
        services.spectrum_job_add_failure, name='spectrum_job_add_failure'),
    ############################################################################
    ### PDF URLs ###
    ############################################################################
    #url(r'^hello.pdf$', pdfs.HelloPDFView.as_view()),
    ############################################################################
    ### Password Reset URLs ###
    ############################################################################
    url(r'^login/$', login, {'template_name': 'registration/login.html'},
        name='auth_login'),
    url(r'^logout/$', logout, {'template_name': 'registration/logout.html'},
        name='auth_logout'),
    url(r'^registration/password/reset/$', password_reset,
        {'template_name': 'registration/password_reset_form.html'},
        name='password_reset'),
    url(r'^registration/password/reset/done/$', password_reset_done,
        {'template_name': 'registration/password_reset_done.html'},
        name='password_reset_done'),
    url(r'^registration/password/reset/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$',
        password_reset_confirm,
        {'template_name': 'registration/password_reset_confirm.html'},
        name='password_reset_confirm'),
    url(r'^registration/password/done/$', password_reset_complete,
        {'template_name': 'registration/password_reset_complete.html'},
        name='password_reset_complete'),
    #### PASSWORD CHANGE (for logged in users)
    url(r'^registration/password/change/$', views.pw_change, ###password_change,
        {'template_name': 'registration/password_change_form.html'},
        name='password_change'),
    url(r'^registration/password/change/done/$', views.pw_change_done, ###password_change_done,
        {'template_name': 'registration/password_change_done.html'},
        name='password_change_done'),
    #### USER/ADMIN urls
    url(r'^admin/', include(admin.site.urls)),
    url(r'^registration/', include('registration.urls')),
    ############################################################################
    ### Marketing URLs ###
    ############################################################################
    url(r'^requests/$', mktg_views.req_detail,
        name='req_detail'),
    url(r'^requests/summary/$', mktg_views.req_detail,
        {'summary': True}, name='req_summary'),
    url(r'^requests/edit/$', mktg_views.edit_req,
        name='edit_req'),
    url(r'^requests/submit/$', mktg_views.submit_req,
        name='submit_req'),
    url(r'^requests/loading/$', mktg_views.req_loading,
        name='req_loading'),
    url(r'^requests/download/$', mktg_views.download_req,
        name='download_req'),
    url(r'^requests/region/$', mktg_views.change_region,
        name='change_region'),
    url(r'^refresh/$', mktg_views.update_hyperbuild_names,
        name='update_hyperbuild_names'),
    url(r'^requests/error/$', mktg_views.sql_error,
        name='sql_error'),
    #API call
    url(r'^cmpgn/(?P<id>[-\w]+)/$', mktg_views.get_campaign_info),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
