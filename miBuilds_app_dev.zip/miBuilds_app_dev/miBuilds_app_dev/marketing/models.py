from django.db import models
from django.contrib.auth.models import User
from picklefield.fields import PickledObjectField

CHANNELS = (
    ('SMB', 'SMB'),
    ('ENT', 'ENT'),
    ('MAJ', 'MAJ'),
    ('GED', 'GED'),
    ('FED', 'FED'),
    ('NAT', 'NAT')
)

REGIONS = (
    ('Houston', 'Houston'), # (Value, human-readable name)
    ('Twin Cities', 'Twin Cities'),
    ('Portland', 'Portland'),
    ('Seattle', 'Seattle'),
    ('California', 'California'),
    ('Mountain West', 'Mountain West')
)

# Create your models here.

class Channel(models.Model):
    channel = models.CharField(max_length=3, choices=CHANNELS)
    
    def __str__(self):
        return self.channel
    
class Region(models.Model):
    region = models.CharField(max_length=15, choices=REGIONS)
    
    def __str__(self):
        return self.region
    
class HyperBuildName(models.Model):
    hyperbuild_name = models.CharField(max_length=100)
    region = models.ForeignKey(Region, on_delete=models.CASCADE, 
                               blank=True, null=True)
    approval_date = models.CharField(max_length=50, null=True)
    completion_date = models.CharField(max_length=50, null=True)
    SMB_ID = models.CharField(max_length=100, null=True)
    SMB_code = models.CharField(max_length=50, null=True)
    ENT_ID = models.CharField(max_length=100, null=True)
    ENT_code = models.CharField(max_length=50, null=True)
    def __str__(self):
        try:
            return self.approval_date + ": " + self.hyperbuild_name  
        except:
            return self.hyperbuild_name
        
    def name(self):
        return self.hyperbuild_name
        
    class Meta:
        ordering = ('hyperbuild_name',)
        
class SQLBuildFix(models.Model):
    busn_build_name = models.CharField(max_length=100)
    bldg_build_name = models.CharField(max_length=100)
    
    def __str__(self):
        return self.bldg_build_name
    
    def busn_name(self):
        return self.busn_build_name

class HyperBuildReq(models.Model):
    request_ID = models.CharField(max_length=10)
    hyperbuild_names = models.ManyToManyField(HyperBuildName, 
                                        blank=True)

    channels = models.ManyToManyField(Channel, blank=True)
    region = models.ForeignKey(Region, on_delete=models.CASCADE, 
                               blank=True, null=True)
    slug = models.SlugField(unique=False)
    user = models.OneToOneField(User, blank=True, null=True)
    prev_req = PickledObjectField(blank=True, null=True)
    build_summary = PickledObjectField(blank=True, null=True)
    prev_names = models.TextField(blank=True, null=True)
    prev_channels = models.CharField(max_length=40, blank=True, null=True)
    
class RequestIterator(models.Model):
    request_ID = models.CharField(max_length=10)
    
class QueryHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, blank=True, null=True)
    hyperbuild_names = models.TextField(blank=True, null=True)
    region = models.CharField(max_length=15, blank=True, null=True)
    channels = models.CharField(max_length=40, blank=True, null=True)
    timestamp = models.DateTimeField(blank=True, null=True)
    

