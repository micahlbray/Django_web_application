from rest_framework import serializers
from marketing.models import HyperBuildName


class CampaignSerializer(serializers.ModelSerializer):
    class Meta:
        model = HyperBuildName
        fields = ('SMB_ID','SMB_code','ENT_ID','ENT_code')