from django.db.models.signals import post_save
from marketing.models import HyperBuildReq, RequestIterator#, HyperBuildName
from django.contrib.auth.models import User
#from django.contrib.auth.signals import user_logged_in
#import pyodbc
#import pandas as pd

def create_request(sender, **kw):
    user = kw["instance"]
    if kw["created"]:
        try:
            iterators = RequestIterator.objects.all()
            iterator = [iterator for iterator in iterators]
            iterator = iterator[0]
            new_ID = str(int(iterator.request_ID) + 1).zfill(3)
            iterator.request_ID = new_ID
            iterator.save() 
        except:
            #no iterators - case when sqlite db cleared
            new_ID = str(0).zfill(3)
            iterator = RequestIterator(request_ID=new_ID)  
            iterator.save()
        
        probuild_req = HyperBuildReq(request_ID=new_ID, user=user, slug=new_ID)
        probuild_req.save()

#def update_hyperbuild_options(sender, **kw):
#    sql = ('SELECT DISTINCT BUILD_NAME '
#           'FROM BI_MIP_DEV.DEV.PROBUILD_SUMMARY')
#    cnxn = pyodbc.connect('DRIVER={SQL Server Native Client 11.0};'
#                      'SERVER=WestBIS-RPT;DATABASE=ExternalUser;'
#                      'Trusted_Connection=yes')
#    name_df = pd.read_sql(sql,cnxn)
#    cnxn.close()
#    
#    old_names = HyperBuildName.objects.all()
#    new_names = [name for name in name_df['BUILD_NAME'] 
#                      if name not in old_names]
#    for name in new_names:
#        new_name = HyperBuildName(hyperbuild_name=name)
#        new_name.save()
#    
    
        
post_save.connect(create_request, 
                  sender=User, 
                  dispatch_uid="users-profilecreation-signal")

#user_logged_in.connect(update_hyperbuild_options)