from django.forms import ModelForm
from marketing.models import HyperBuildReq, Channel, HyperBuildName, Region
from django.forms.widgets import CheckboxSelectMultiple

        
class HyperBuildReqForm(ModelForm):
    class Meta:
        model = HyperBuildReq
        fields = ('hyperbuild_names', 'channels')
        
    def __init__(self, *args, **kwargs):

        try:
            order = kwargs.pop('order')
        except: 
            order = 'hyperbuild_name' 
        super(HyperBuildReqForm, self).__init__(*args, **kwargs)
        
        self.fields["channels"].widget = CheckboxSelectMultiple()
        self.fields["channels"].queryset = Channel.objects.all()
        
        self.fields["hyperbuild_names"].queryset = (
          HyperBuildName.objects.filter(
            region=Region.objects.get(region=self.instance.region.__str__())
          ).order_by(order)
        )
        
class HyperBuildRegionForm(ModelForm):
    class Meta:
        model = HyperBuildReq
        fields = ('region',)