from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import Http404, StreamingHttpResponse, HttpResponse
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from marketing.forms import HyperBuildReqForm, HyperBuildRegionForm
from marketing.models import (HyperBuildReq,
                               QueryHistory,
                               HyperBuildName,
                               Channel,
                               Region,
                               SQLBuildFix)
from marketing.serializers import CampaignSerializer
from rest_framework.renderers import JSONRenderer
from rest_framework import status

from datetime import date
import pyodbc
import pandas as pd
from math import floor
import numpy as np
import time
import pysftp
import os
from io import StringIO
import sys
sys.path.append(r'C:\projects\hyperbuild_marketing\SFTP\Outbox')


#==========================================
#=          Home Page                     =
#==========================================
def DoNotCall_SFTP(out_df, hyperbuild_str, channel_str):

    base_name = 'HyperBuild_Marketing_{}_{}_'.format(hyperbuild_str,
                                                     channel_str).replace(
                                                        ':','_')
    ts = time.strftime('%Y%m%d_%H%M')
#    filename = base_name + ts + '.xlsx'
    filename = base_name + ts

    phone_df = out_df['PHONE']

    out_dir = r'C:\projects\hyperbuild_marketing\SFTP\Outbox'
    phone_df.to_csv(os.path.join(out_dir, filename + '.csv'),index=False)

    hostname = 'xfer.dncsolution.com'
    username = 'comcast_mip'
    password = '4Udafahe'

    cnopts = pysftp.CnOpts()
    cnopts.hostkeys = None

    sftp_flag = False
    with pysftp.Connection(hostname, username=username, password=password, cnopts=cnopts) as sftp:
        with sftp.cd('Inbox'):             # temporarily chdir to Inbox
            sftp.put(os.path.join(out_dir, filename + '.csv'))  # upload file to public/ on remote
        with sftp.cd('Outbox'):
            match = False
            while not match:
                filelist = sftp.listdir()
                filematch = [file for file in filelist if filename in file]
                if len(filematch) > 0:
                    match = True
                    acquired = False
                    attempts = 0
                    while not acquired:
                        attempts += 1
                        print("DNC SFTP Attempt".format(str(attempts)))
                        try:
                            sftp.get(filematch[0])
                            acquired = True
                            new_df = pd.read_csv(filematch[0],
                                         names=('Phone','F1','F2','F3','F4'),
                                         skip_blank_lines=False)
                        except:
                            acquired = True
                            sftp_flag = True
                else:
                    time.sleep(15)

    col_loc = out_df.columns.get_loc('PHONE')

    if sftp_flag:
        print('DNC failure')
        out_df.loc[:,'PHONE'] = ''
        return out_df

    for index, row in new_df.iterrows():
        if type(row['F1']) is str:
            if row['F1'] in ['BN1', 'NCO', 'CO1', 'NCO', 'NXX']:
                out_df.iloc[index,col_loc] = ''
                continue
        if type(row['F2']) is str:
            if row['F2'] in ['BN1', 'NCO', 'CO1', 'NCO', 'NXX']:
                out_df.iloc[index,col_loc] = ''
                continue
        if type(row['F3']) is str:
            if row['F3'] in ['BN1', 'NCO', 'CO1', 'NCO', 'NXX']:
                out_df.iloc[index,col_loc] = ''
                continue
        if type(row['F4']) is str:
            if row['F4'] in ['BN1', 'NCO', 'CO1', 'NCO', 'NXX']:
                out_df.iloc[index,col_loc] = ''
                continue

    return out_df



#==========================================
#=              API Tools                 =
#==========================================

class JSONResponse(HttpResponse):
    def __init__(self, data, **kwargs):
        content = JSONRenderer().render(data)
        kwargs['content_type'] = 'application/json'
        super(JSONResponse, self).__init__(content, **kwargs)

# Eliminate this later
@csrf_exempt
def get_campaign_info(request, id):
    if request.method == 'GET':
        try:
            hyperbuild = HyperBuildName.objects.get(id=id)
        except:
            return HttpResponse(status=status.HTTP_404_NOT_FOUND)
    else:
        return HttpResponse(status=status.HTTP_404_NOT_FOUND)
    hyperbuild_serializer = CampaignSerializer(hyperbuild)
    return JSONResponse(hyperbuild_serializer.data)




#==========================================
#=        Hyperbuild Tools                =
#==========================================
@login_required
def update_hyperbuild_names(request):
    '''This function queries SQL and updates the internal
       list of hyperbuild names and building channels.'''

    #update regions
    region_list = ['Houston','Twin Cities', 'Portland', 'Seattle',
                   'California', 'Mountain West']
    curr_regions = [region.__str__() for region in Region.objects.all()]
    new_regions = [region for region in region_list
                            if region not in curr_regions]
    for region in new_regions:
        new_region = Region(region=region)
        new_region.save()

    # Get Hyperbuild names from SQL
    sql = ('SELECT DISTINCT BUILD_NAME '
           '      ,REGION '
           'FROM BI_MIP.MIP2.PROBUILD_SUMMARY')
    sfdc_sql = ("SELECT Description as NAME, "
                "       Id as ID, "
                "       Name as CODE "
                "FROM ExternalUser.SFDC.Campaign "
                "WHERE Type = 'Hyperbuild' "
                "  AND Division__c = 'West'"
                )

    build_sql = ("SELECT BUILD_NAME AS NAME, "
                 "       Approval_Date AS approval_date, "
                 "       Est_Completion_Date AS completion_date "
                 "FROM BI_MIP.MIP2.PROBUILD_SUMMARY")

    cnxn = pyodbc.connect('DRIVER={SQL Server Native Client 11.0};'
                      'SERVER=WestBIS-RPT;DATABASE=ExternalUser;'
                      'Trusted_Connection=yes')
    name_df = pd.read_sql(sql,cnxn).drop_duplicates()
    sfdc_df = pd.read_sql(sfdc_sql, cnxn).drop_duplicates()
    build_df = pd.read_sql(build_sql, cnxn).drop_duplicates()
    cnxn.close()

    # Compare queried names to stored names, and update stored names
    old_names = [name.name() for name in HyperBuildName.objects.all()]
    new_names = [name for name in name_df['BUILD_NAME']
                      if name not in old_names]
    del_names = [name for name in old_names
                     if name not in name_df['BUILD_NAME'].tolist()]

    n_builds = name_df.shape[0]
    for i in range(n_builds):
        curr_name = name_df['BUILD_NAME'][i]
        if curr_name in new_names:
            print("{} added".format(curr_name))
            region = name_df['REGION'][i].title()
            if region == 'Mile High' or region == 'Mountain':
                region = 'Mountain West'
            new_region = Region.objects.get(region=region)
            new_date = build_df.loc[build_df['NAME'] == curr_name,
                                    'approval_date'].to_string(index=False)
            new_complete = build_df.loc[build_df['NAME'] == curr_name,
                                    'completion_date'].to_string(index=False)
            new_build = HyperBuildName(hyperbuild_name=curr_name,
                                       approval_date=new_date,
                                       completion_date=new_complete)
            new_build.save()
            new_build.region = new_region
            new_build.save()

    for del_name in del_names:
        del_build = HyperBuildName.objects.get(hyperbuild_name=del_name)
        del_build.delete()
        print("{} deleted".format(del_name))

    # Update default campaign IDs and codes for all matching builds
    names = [name.name() for name in HyperBuildName.objects.all()]

    sfdc_df['NAME'] = sfdc_df['NAME'].str.lower()
    sfdc_names = [name for name in sfdc_df['NAME'] if name is not None]
    for curr_name in names:
        curr_build = HyperBuildName.objects.get(hyperbuild_name=curr_name)
#        if curr_build.SMB_ID != '' and curr_build.ENT_ID != '':
#            continue
        if curr_name.lower() in sfdc_names:
            print("{} Matched in SFDC".format(curr_name))
            smb_found = False
            ent_found = False
            curr_df = sfdc_df.loc[
                sfdc_df['NAME']==curr_name.lower(),('ID','CODE')
                ]
            for i in range(curr_df.shape[0]):
                curr_row = curr_df.iloc[i,:]
                if curr_row['CODE'][-3:] == 'SMB':
                    smb_found = True
                    smb_id = curr_row['ID']
                    smb_code = curr_row['CODE']
                elif curr_row['CODE'][-3:] == 'ENT':
                    ent_found = True
                    ent_id = curr_row['ID']
                    ent_code = curr_row['CODE']
            if not smb_found:
                smb_id = ""
                smb_code = ""
            if not ent_found:
                ent_id = ""
                ent_code = ""
            curr_build.SMB_ID = smb_id
            curr_build.SMB_code = smb_code
            curr_build.ENT_ID = ent_id
            curr_build.ENT_code = ent_code
        else:
            curr_build.SMB_ID = ''
            curr_build.SMB_code = ''
            curr_build.ENT_ID = ''
            curr_build.ENT_code = ''
        curr_build.save()



    #update business channels too
    channel_list = ['SMB','ENT','MAJ','GED','FED','NAT']
    curr_channels = [channel.__str__() for channel in Channel.objects.all()]
    new_channels = [channel for channel in channel_list
                            if channel not in curr_channels]
    for channel in new_channels:
        new_channel = Channel(channel=channel)
        new_channel.save()

    return redirect('req_loading', slug=slug)

@login_required
def change_region(request):
    '''Allows users to change the region of inquiry'''

    # Make sure logged in user is the request owner
    hyperbuild_req = HyperBuildReq.objects.get(slug=slug)
    if hyperbuild_req.user != request.user:
        raise Http404

    form_class = HyperBuildRegionForm
    #if we're coming to this view from a submitted form,
    if request.method == 'POST':
        # grab the data from the submitted form
        form = form_class(data=request.POST, instance=hyperbuild_req)
        if form.is_valid():
            # save the new data
            form.save()
            return redirect('edit_req', slug=hyperbuild_req.slug)
    # otherwise just create the form
    else:
        form = form_class(instance=hyperbuild_req)
    # and render the template
    return render(request, 'hyperbuild_request/change_region.html',
                  {'hyperbuild_req':hyperbuild_req, 'form':form})

@login_required
def submit_req(request):
    '''This function queries the database'''

    # Make sure logged in user is the request owner
    hyperbuild_req = HyperBuildReq.objects.get(slug=slug)
    if hyperbuild_req.user != request.user:
        raise Http404

    # Get the name of the current hyperbuild
    # If blank, redirect to the edit page
    try:
        hyperbuild_names = [build.name()
                            for build in hyperbuild_req.hyperbuild_names.all()]
    except:
        return redirect('change_region', slug=hyperbuild_req.slug)

    hyperbuild_html = ", ".join(hyperbuild_names)


    # Create a search string for SQL based on channel selections
    new_channels = [channel.__str__()
                    for channel in hyperbuild_req.channels.all()]
    channel_html = ", ".join(new_channels)

    channel_str = ""
    for channel in new_channels:
        channel_str = channel_str + channel + "_"
    channel_str = channel_str[:-1]

    if 'SMB' in new_channels:
        SMBflag = True
        sql_channel = 'SMB'
        sql_cust = 'COMCAST_CUSTOMER = 0 AND COMCAST_CUSTOMER_FIBER = 0'
    else:
        SMBflag = False
        sql_channel = 'ENT'
        sql_cust = 'COMCAST_CUSTOMER_FIBER = 0'

#    # Begin SQL calls
#    cnxn = pyodbc.connect('DRIVER={SQL Server Native Client 11.0};'
#                          'SERVER=WestBIS-RPT;DATABASE=ExternalUser;'
#                          'Trusted_Connection=yes')


    summary_cols = ['NAME','BC (SMB)','BC (ENT+)','QUERY TYPE','TARGET BUSN CNT',
                    '% LEADS FOUND','LEADS INCLD']
    summary_df = pd.DataFrame(columns=summary_cols)
    out_df = pd.DataFrame()
    today = date.today()
    today_str = date(today.year+(today.month-7)//12,
                     (today.month-7)%12 + 1,
                     1).isoformat()
    one_month_str =  date(today.year+(today.month-2)//12,
                     (today.month-2)%12 + 1,
                     1).isoformat()

    for build_name in hyperbuild_names:
        cnxn = pyodbc.connect('DRIVER={SQL Server Native Client 11.0};'
                          'SERVER=WestBIS-RPT;DATABASE=ExternalUser;'
                          'Trusted_Connection=yes')
        print('Working on {}'.format(build_name))
        eps_list = []
        # SQL query to get the number of businesses within each channel for
        # a given business case

        sql_summ = ("SELECT SMB_Passings, ENT_Passings, Region "
                    "FROM BI_MIP.MIP2.PROBUILD_SUMMARY "
                    "WHERE BUILD_NAME = '{}' ".format(build_name))

        # SQL query to identify all businesses Epsilon can find located
        # at the buildings identified in the business case.
        sql_eps = (
                "SELECT DISTINCT BUSN_ID "
                "               ,MIP_SEGMENT "
                "FROM ExternalUser.MIP.MIP2_BUSINESS_PROFILE "
                "WHERE NAX_BUILDING_ID IN ( "
                "    SELECT DISTINCT A.NAX_BUILDING_ID "
                "    FROM BI_MIP.MIP2.PROBUILD_BUILDINGS A "
                "    LEFT JOIN ExternalUser.MIP.MIP2_BUILDING_PROFILE B "
                "      ON A.NAX_BUILDING_ID = B.NAX_BUILDING_ID "
                "    WHERE A.BUILD_NAME = '{}' "
                "    AND A.NAX_BUILDING_ID IS NOT NULL "
                "    AND B.MIP_BUILDING_IS_GOOD = 'Y' "
                "    AND B.MIP_BUILDING_TYPE != 'RESIDENTIAL' "
                "    AND B.MIP_TOTAL_BUSINESSES_IN_{} > 0 "
                ") "
                "AND MIP_IN_OR_OUT = 'IN' "
                "AND IS_HBB = 'N' "
                "AND TELEWORKER_FLAG = 'N' "
                "AND {} "
                "AND COMCAST_DIVISION = 'WEST DIVISION' "
                "".format(build_name, sql_channel, sql_cust)
        )

        try:
            sqlfix = SQLBuildFix.objects.get(bldg_build_name=build_name)
            busn_name = sqlfix.busn_name()
        except:
            busn_name = build_name

        # SQL query to identify businesses identified in the business
        # case
        sql_match = (
                "SELECT A.BUSN_ID, MIP_IN_OR_OUT, B.[Revised_Segment] AS SEGMENT, "
                "       COMCAST_REGION "
                "FROM ExternalUser.MIP.MIP2_BUSINESS_PROFILE A "
                "INNER JOIN BI_MIP.MIP2.PROBUILD_BUSINESSES B "
                "     ON A.BUSN_ID = B.BUSN_ID "
                "     AND B.BUILD_NAME = '{}' "
                "     AND B.BUSN_ID IS NOT NULL "
                "WHERE A.COMCAST_DIVISION = 'WEST DIVISION' ".format(busn_name)
        )

        sql_bc = ("SELECT [Revised_Segment] AS [Qb Segment], "
                  " count(DISTINCT BUSN_ID) AS QB_CNT, "
                  " count(BUSN_ID) AS BUS_CNT "
                  "FROM BI_MIP.MIP2.PROBUILD_BUSINESSES  "
                  "WHERE BUILD_NAME = '{}' "
                  "GROUP BY [Revised_Segment]".format(busn_name))

        sql_addr = (
                "SELECT [Building Address] AS STREET, City AS CITY, "
                "       State AS STATE, Zip AS ZIP "
                "FROM BI_MIP.MIP2.PROBUILD_BUILDINGS A "
                "LEFT JOIN ExternalUser.MIP.MIP2_BUILDING_PROFILE B "
                "  ON A.NAX_BUILDING_ID = B.NAX_BUILDING_ID "
                "WHERE BUILD_NAME = '{}' "
                "AND B.MIP_BUILDING_TYPE != 'RESIDENTIAL' "
                "AND B.MIP_TOTAL_BUSINESSES_IN_ENT = 0 "
                "AND A.NAX_BUILDING_ID IS NOT NULL".format(build_name)
        )

        bc_df = pd.read_sql(sql_bc, cnxn)
        summ_df = pd.read_sql(sql_summ, cnxn)
        summ_df.iloc[:,:2] = summ_df.iloc[:,:2].astype(int)
        eps_df = pd.read_sql(sql_eps, cnxn)
        match_df = pd.read_sql(sql_match, cnxn)
        addr_df = pd.read_sql(sql_addr, cnxn)

        # Count overall 'SMB' and 'ENT+' MIP QBs in BC
        try:
            smb_n = summ_df['SMB_Passings'][0]
            ent_n = summ_df['ENT_Passings'][0]
        except:
            print('{} is bad'.format(build_name))
            continue

#        bc_list = list(set(match_df['BUSN_ID']))

        # Count number of businesses in BC, regardless of MIP status
        bc_counts = []
        for channel in new_channels:
            try:
                bc_counts.append(bc_df.loc[bc_df['Qb Segment'] == channel,'QB_CNT'].values[0])
            except:
                bc_counts.append(0)

        # Generate value to compare output list to - only need to produce
        # up to 90% of the business count in BC
        if sum(bc_counts) > 0:
            bc_n = sum(bc_counts) * .9
        elif SMBflag:
            bc_n = smb_n * .9
        else:
            bc_n = ent_n * .9

#
#        # Identify Epsilon businesses in descending order of confidence
#        # that are not already matched to MIP QBs
        eps_test = [seg in new_channels for seg in eps_df['MIP_SEGMENT']]
        match_test = [seg in new_channels for seg in match_df['SEGMENT']]

        eps_df = eps_df.loc[eps_test,:]
        match_df = match_df.loc[match_test,:]
#
#        eps_4v = eps_df.loc[(eps_df['LS_NUMBER_OF_SOURCES_CNT'] > 3)
#                    & (eps_test),'EPS_BUSN_ID']
#        eps_3v = eps_df.loc[(eps_df['LS_NUMBER_OF_SOURCES_CNT'] == 3)
#                    & (eps_test),'EPS_BUSN_ID']
#        eps_2v = eps_df.loc[((eps_df['LS_NUMBER_OF_SOURCES_CNT'] == 2)
#                             | ((eps_df['LS_NUMBER_OF_SOURCES_CNT'] == 1)
#                                & ((eps_df['LS_SOURCE_CD'] == 'NDW')
#                                   | (eps_df['LS_SOURCE_CD'] == 'SVIEW')
#                                  )
#                               )
#                             )
#                             & (eps_test),'EPS_BUSN_ID']
#
#        # Remove potential duplicates for bc_list
#        bc_list = list(set(bc_list))
#
#        eps_4v = [eps for eps in eps_4v if eps not in bc_list]
#        eps_3v = [eps for eps in eps_3v if eps not in bc_list]
#        eps_2v = [eps for eps in eps_2v if eps not in bc_list]
#
#        # Be continuously more inclusive of Epsilon businesses until
#        # the business count reaches the threshold defined above
#        if len(bc_list) >= bc_n:
#            [eps_list.append(eps) for eps in bc_list]
#            eps_n = len(bc_list)
#            match_type = 'XREF'
#        elif len(bc_list + eps_4v) >= bc_n:
#            [eps_list.append(eps) for eps in (bc_list + eps_4v)]
#            eps_n = len(bc_list + eps_4v)
#            match_type = 'XREF|4V'
#        elif len(bc_list + eps_4v + eps_3v) >= bc_n:
#            [eps_list.append(eps) for eps in (bc_list + eps_4v + eps_3v)]
#            eps_n = len(bc_list + eps_4v + eps_3v)
#            match_type = 'XREF|4V|3V'
#        else:
#            [eps_list.append(eps) for eps in (bc_list + eps_4v
#                                              + eps_3v + eps_2v)]
#            eps_n = len(bc_list + eps_4v + eps_3v + eps_2v)
#            match_type = 'XREF|4V|3V|2V'

        eps_list = list(set(match_df['BUSN_ID'].tolist() + eps_df['BUSN_ID'].tolist()))
        eps_n = len(eps_list)

        if bc_n > 0:
            per_found = eps_n/(bc_n/0.9)
            per_str = "{0:.2f}%".format(per_found*100)
        else:
            per_str = 'NA'
        bus_type = ", ".join(new_channels)
        build_df = pd.DataFrame([[build_name, smb_n, ent_n, bus_type, bc_n/0.9,
                        per_str, len(eps_list)]], columns=summary_cols)
        summary_df = summary_df.append(build_df)
        try:
            eps_str = "('" + "', '".join(str(eps) for eps in eps_list) + "')"
        except:
            eps_str = "('')"

        # Make 3 separate dataframes and union them to create final output
        # using the Epsilon business IDs defined above
        sql_oppty = (
           "SELECT A.EPS_BUSN_ID, "
           "       B.ID, "
           "       C.UserEmail__c AS PROSPECT_OWNER, "
           "       D.JobDescr AS JOB, "
           "       B.CreatedDate, "
           "       'oppty' as 'TYPE', "
           "       '' AS FIRST_NAME, "
           "       '' AS LAST_NAME, "
           "       '' AS COMPANY, "
           "       '' AS STREET, "
           "       '' AS CITY, "
           "       '' AS STATE, "
           "       '' AS PHONE, "
           "       '' AS EMAIL, "
           "       '' AS REASON, "
           "       '' AS PROSPECT_STATUS "
           "FROM BI_MIP.EPSILON.CDM_SFDC_ID_XREF A "
           "INNER JOIN ExternalUser.SFDC.OPPORTUNITY_COMBINED B "
           "   ON A.ACCOUNT_ID = B.AccountId "
           "   AND A.LOCATION_ID = B.Site__c "
           "LEFT JOIN EXTERNALUSER.SFDC.[USER] C "
           "   ON B.OWNERID = C.ID "
           "LEFT JOIN WISDM.DIM.Employee D "
           "   ON C.[Comcast_Employee_ID__c] = D.Pernr "
           "LEFT JOIN EXTERNALUSER.MIP.MIP2_BUSINESS_PROFILE E "
           "  ON E.BUSN_ID = A.EPS_BUSN_ID "
           "WHERE A.EPS_BUSN_ID IN {} "
           "AND C.IsActive = 'true' "
           "AND B.STAGENAME IN ("
           "  'Close Won'"
           "  ,'Closed - Won'"
           "  ,'Closed Won'"
           "  ,'Closed Won - Cancelled'"
           "  ,'Closed Won - CBI'"
           "  ,'Closed Won - Complete'"
           "  ,'Closed Won - In Progress'"
           "  ,'Closed Won - Install Complete'"
           "  ,'Closed Won - Order Complete'"
           "  ,'Closed Won - Pending Order'"
           "  ,'Completed Order'"
           "  ,'Contract Generation'"
           "  ,'Contract Negotiations'"
           "  ,'Contract Received'"
           "  ,'Contract Sent'"
           "  ,'Contract Signed Pending Additional Docs'"
           "  ,'Contract Signed Pending Adtl. Docs'"
           "  ,'Final Proposal Accepted'"
           "  ,'OA Pending - APS'"
           "  ,'On Hold'"
           "  ,'Opportunity'"
           "  ,'Order Acceptance - Rejected'"
           "  ,'Order Acceptance Pending'"
           "  ,'Order Acceptance Rejected'"
           "  ,'Order Acceptance Requested'"
           "  ,'Order Submitted'"
           "  ,'Pending Billing'"
           "  ,'Pending Order'"
           "  ,'Pending Post-Order Completion Tasks'"
           "  ,'Pending Pre-Order Site Survey'"
           "  ,'Pending Proposal Acceptance'"
           "  ,'Pending Sales Accept'"
           "  ,'Pending Signature'"
           "  ,'Proposal Accepted'"
           "  ,'Proposal Generation'"
           "  ,'Proposal Review'"
           "  ,'Proposal Sent'"
           "  ,'Proposed'"
           "  ,'Qualified'"
           "  ,'Qualifying Funding'"
           "  ,'Qualifying Interest'"
           "  ,'Rejected Pre-Order Site Survey'"
           "  ,'Sales Accepted'"
           "  ,'Sales Engineer Verification'"
           "  ,'Solutions Proposal Accepted'"
           "  ,'Tech Review'"
           ") "
           "AND B.CreatedDate >= '{}' "
           "AND E.COMCAST_CUSTOMER = 0 "
           "AND D.[EmplStatusDescr] = 'Active' "
           "AND D.MAIL <> '' "
           "AND D.iscurrent = '1' ".format(eps_str, today_str))

        #leads are called prospects in marketing
        sql_lead = ("SELECT A.EPS_BUSN_ID, "
           "  B.ID, "
           "  D.MAIL AS PROSPECT_OWNER, "
           "  D.JobDescr AS JOB, "
           "  B.CreatedDate, "
           "  CASE WHEN B.iLEAD_Qualified__c = 'true' THEN 'ilead' "
           "       ELSE 'prospect' END AS 'TYPE', "
           "  B.FirstName AS FIRST_NAME, "
           "  B.LastName AS LAST_NAME, "
           "  B.Company AS COMPANY, "
           "  B.Street AS STREET, "
           "  B.City AS CITY, "
           "  B.State AS STATE, "
           "  B.Phone AS PHONE, "
           "  B.Email AS EMAIL, "
           "  B.Email_Opt_Out_Reason__c AS REASON, "
           "  B.Status AS PROSPECT_STATUS "
           "FROM BI_MIP.EPSILON.MIPS_SOURCE_XREF A "
           "LEFT JOIN EXTERNALUSER.SFDC.LEAD B ON A.VENDOR_SOURCE_ID = B.ID "
           "LEFT JOIN EXTERNALUSER.SFDC.[USER] C ON B.OWNERID = C.ID "
           "LEFT JOIN WISDM.DIM.Employee D "
           "  ON C.Comcast_Employee_ID__c = D.Pernr "
           "LEFT JOIN EXTERNALUSER.MIP.MIP2_BUSINESS_PROFILE E "
           "  ON E.BUSN_ID = A.EPS_BUSN_ID "
           "WHERE A.EPS_BUSN_ID IN {} "
           "AND ((B.LastModifiedDate >= '{}' AND B.[iLEAD_Qualified__c] = 'false') "
           "     OR (B.[iLEAD_Qualified__c] = 'true' "
           "         AND ((DATEDIFF(MM,B.Contract_Expiration_Data__c,GETDATE()) <= 0) "
           "              OR (DATEDIFF(MM,B.Contract_Expiration_Voice__c,GETDATE()) <= 0) "
           "              OR (DATEDIFF(DD,B.LastModifiedDate,GETDATE()) <= 730) "
           "              OR (DATEDIFF(DD,B.LastActivityDate,GETDATE()) <= 730) "
           "             ) "
           "        ) "
           ") "
           "AND B.OwnerId NOT IN ('00GA0000003SRF6MAO','005A0000004PBzvIAG') "
           "AND E.COMCAST_CUSTOMER = 0 "
           "AND B.LASTNAME <> 'ROE' "
           "AND B.Status <> 'Archived' "
           "AND A.SOURCE_CD = 'SFDCB' "
           "AND D.[EmplStatusDescr] = 'Active' "
           "AND D.MAIL <> '' "
           "AND D.iscurrent = '1' ".format(eps_str, one_month_str))

        sql_base = ("SELECT '' AS PROSPECT_OWNER, "
           "       CASE WHEN LEN(F.[First Name])>0 THEN F.[FIRST NAME] "
           "            WHEN LEN(G.[First Name])>0 THEN G.[FIRST NAME] "
           "            WHEN LEN(CNTCT_FIRST_NM)>0 THEN H.CNTCT_FIRST_NM "
           "            ELSE '[Not Provided]' END AS FIRST_NAME, "
           "       CASE WHEN LEN(F.[LAST Name])>0 THEN F.[LAST NAME] "
           "            WHEN LEN(G.[LAST Name])>0 THEN G.[LAST NAME] "
           "            WHEN LEN(CNTCT_LAST_NM)>0 THEN H.CNTCT_LAST_NM "
           "            ELSE '[Not Provided]' END AS LAST_NAME, "
           "       B.BUSN_NAME AS COMPANY, "
           "       CASE WHEN A.NAX_CONFORMED_ADDRESS_2  = '' "
           "              THEN A.NAX_CONFORMED_ADDRESS_1 "
           "            ELSE CONCAT(A.NAX_CONFORMED_ADDRESS_1,',',A.NAX_CONFORMED_ADDRESS_2)"
           "              END AS STREET, "
           "       A.NAX_CONFORMED_CITY AS CITY, "
           "       A.NAX_CONFORMED_STATE_CODE AS [STATE], "
           "       A.NAX_CONFORMED_ZIP5 AS ZIP, "
           "       H.BUS_PRIMARY_PHONE_NBR_TXT AS PHONE, "
           "       CASE WHEN F.EMAIL = '' THEN 'none@none.com' "
           "            WHEN G.EMAIL = '' THEN 'none@none.com' "
           "            WHEN F.EMAIL IS NOT NULL THEN F.EMAIL "
           "            WHEN G.EMAIL IS NOT NULL THEN G.EMAIL "
           "            ELSE 'none@none.com' END AS EMAIL, "
           "       'FALSE' AS EMAILOPTOUT, "
           "       '' AS REASON, "
           "       'NEW' as PROSPECT_STATUS, "
           "       B.BUSN_ID AS EPS_BUSN_ID, "
           "       CONCAT(C.SEGMENT,'-') AS [DESCRIPTION], "
           "       C.TOTAL_TEL_SPEND, "
           "       '' AS ID "
           "FROM ExternalUser.MIP.MIP2_BUSINESS_PROFILE B "
           "  LEFT JOIN ExternalUser.MIP.MIP2_ADDRESS_PROFILE A "
           "    ON B.NAX_ADDRESS_ID = A.NAX_ADDRESS_ID "
           "  INNER JOIN [BI_MIP].[MIP2].[BUSINESS_PROFILE_HIERARCHY] C "
           "    ON B.BUSN_ID = C.EPS_BUSN_ID "
           "  LEFT JOIN BI_MIP.MIP2.PROBUILD_BUILDINGS E "
           "    ON B.NAX_BUILDING_ID = E.NAX_BUILDING_ID "
           "  LEFT JOIN BI_MIP.MIP.AllProbuilds_EmailList_Clients_20160929 F "
           "    ON B.BUSN_ID = F.[EPS BUSN ID] "
           "  LEFT JOIN BI_MIP.MIP.AllProbuilds_EmailList_MultiTenant_20160929 G "
           "    ON B.BUSN_ID = G.EPS_BUSN_ID "
           "  LEFT JOIN BI_MIP.EPSILON.CDM_BUSINESS_DM_BASE H "
           "    ON B.BUSN_ID = H.EPS_BUSN_ID "
           "WHERE B.BUSN_ID IN {} "
           "AND B.COMCAST_CUSTOMER = 0 ".format(eps_str))

        base_df = pd.read_sql(sql_base, cnxn).drop_duplicates()
        lead_df = pd.read_sql(sql_lead, cnxn)
        oppty_df = pd.read_sql(sql_oppty, cnxn)

        #scrub none@none.com
        if base_df.shape[0] > 0:
            idx = base_df.EMAIL == 'none@none.com'
            base_df.loc[idx,'EMAIL'] = ''
            base_df.loc[idx,'EMAILOPTOUT'] = 'FALSE'

        #Scrub against Do-Not-Call Registry
        if base_df.shape[0] > 0:
            base_df = DoNotCall_SFTP(base_df, build_name, channel_str)

        # clean oppty_df (only keep latest touch per person/busn)
        clean_oppty = pd.DataFrame()
        if oppty_df.shape[0] > 1: #More than one row
            oppty_eps = list(set(oppty_df['EPS_BUSN_ID']))
            for eps in oppty_eps:
                owners = list(set(oppty_df.loc[oppty_df['EPS_BUSN_ID']==eps,'PROSPECT_OWNER']))
                for owner in owners:
                    trim_df = oppty_df.loc[(oppty_df['EPS_BUSN_ID']==eps)
                                           & (oppty_df['PROSPECT_OWNER']==owner)
                                           , :]
                    clean_oppty = clean_oppty.append(
                                    trim_df.sort_values(
                                        by='CreatedDate',ascending=False
                                        ).iloc[0,:]
                                    )
            oppty_df = clean_oppty

        #combine lead and oppty dfs and merge into base
        prospect_df = pd.concat(objs=(lead_df,oppty_df))
        prospect_df.loc[:,'EPS_BUSN_ID'] = prospect_df.loc[:,'EPS_BUSN_ID'].astype(int)

        # Add extra rows to merge_df when BAE1 owns non-iLEAD non-SMB
        dupe_rows = pd.DataFrame()
        dupe_eps = []
        #First figure out which non-SMB non-ileads are owned by non-BAE1s
        # (do this because same business may also have a prospect opened by
        #  a BAE, which would then be incorrectly duplicated)
        for index, row in prospect_df.iterrows():
            job = row['JOB']
            segment = base_df.loc[base_df['EPS_BUSN_ID'] == row['EPS_BUSN_ID'], 'DESCRIPTION'].values[0]
            lead_type = row['TYPE']
            if ((('SMB' in job) and (job != 'Business Acct Exec 3, SMB Direct Sales'))
              and ('SMB' not in segment)
              and (lead_type != 'ilead')):
                dupe_eps.append(row['EPS_BUSN_ID'])
        # Using the prior list, figure which businesses to actually duplicate,
        # and do so
        dupe_eps = [int(dupe) for dupe in set(dupe_eps)]
        for index, row in base_df.iterrows():
            if row['EPS_BUSN_ID'] in dupe_eps:
                dupe_rows = dupe_rows.append(row)

        # Now that dupe rows are identified, remove matching rows in
        # base df matching EPS_BUSN_IDs in prospects, and then
        # add in the prospects (and dupes)
        prospect_ids = list(set(prospect_df['EPS_BUSN_ID']))
        for prospect_id in prospect_ids:
            row = base_df.loc[base_df['EPS_BUSN_ID'] == prospect_id, :]
            if row.shape[0] > 0: #Not an active customer
                leads = prospect_df.loc[prospect_df['EPS_BUSN_ID'] == prospect_id, :]
                base_df = base_df.loc[base_df['EPS_BUSN_ID'] != prospect_id,:]
                for index, lead in leads.iterrows():
                    new_row = row[:]

                    new_row['PROSPECT_OWNER'] = lead['PROSPECT_OWNER']
                    new_row['ID'] = lead['ID']
                    if lead['TYPE'] != 'oppty':
                        new_row['FIRST_NAME'] = lead['FIRST_NAME']
                        new_row['LAST_NAME'] = lead['LAST_NAME']
                        new_row['COMPANY']= lead['COMPANY']
                        new_row['STREET'] = lead['STREET']
                        new_row['CITY'] = lead['CITY']
                        new_row['STATE'] = lead['STATE']
                        new_row['PHONE'] = lead['PHONE']
                        new_row['EMAIL'] = lead['EMAIL']
                        new_row['REASON'] = lead['REASON']
                        new_row['PROSPECT_STATUS'] = lead['PROSPECT_STATUS']
                        if not (any(new_row['REASON'].isnull())
                            or (any(new_row['REASON'] == '--None--'))
                            or (any(new_row['REASON'] == ''))):
                            new_row['EMAILOPTOUT'] = 'TRUE'
                    base_df = base_df.append(new_row)

        merge_df = base_df.append(dupe_rows)
        merge_df = merge_df.loc[:,('FIRST_NAME', 'LAST_NAME', 'COMPANY', 'STREET', 'CITY', 'STATE', 'ZIP',
                                   'PHONE', 'EMAIL', 'EMAILOPTOUT', 'REASON', 'PROSPECT_STATUS',
                                   'EPS_BUSN_ID', 'DESCRIPTION', 'TOTAL_TEL_SPEND', 'ID', 'PROSPECT_OWNER')]

        # clear duped addresses from addr_df
        addr_streets = [addr for addr in set(addr_df['STREET'])]
        merge_streets = [street.lower() for street in set(merge_df['STREET'])]
        for addr_street in addr_streets:
            if any([addr_street.lower() in merge_street for merge_street in merge_streets]):
                addr_df = addr_df.loc[addr_df['STREET'] != addr_street, :]

        if addr_df.shape[0] > 0:
            addr_df['FIRST_NAME'] = '[Not Provided]'
            addr_df['LAST_NAME'] = '[Not Provided]'
            addr_df['COMPANY'] = ''
            addr_df['PHONE'] = ''
            addr_df['EMAIL'] = ''
            addr_df['EMAILOPTOUT'] = 'FALSE'
            addr_df['REASON'] = ''
            addr_df['PROSPECT_STATUS'] = 'NEW'
            addr_df['EPS_BUSN_ID'] = 0
            addr_df['DESCRIPTION'] = '???-'
            addr_df['TOTAL_TEL_SPEND'] = 0
            addr_df['ID'] = ''
            addr_df['PROSPECT_OWNER'] = ''

            addr_df = addr_df.loc[:,('FIRST_NAME', 'LAST_NAME', 'COMPANY', 'STREET', 'CITY', 'STATE', 'ZIP',
                                     'PHONE', 'EMAIL', 'EMAILOPTOUT', 'REASON', 'PROSPECT_STATUS',
                                     'EPS_BUSN_ID', 'DESCRIPTION', 'TOTAL_TEL_SPEND', 'ID', 'PROSPECT_OWNER')]

            if SMBflag:
                merge_df = merge_df.append(addr_df)


        # If a BAE has mutiple leads with an ENT, may create extra dupes
        # that need to be removed
        merge_df = merge_df.drop_duplicates()

        merge_df.loc[:,'EPS_BUSN_ID'] = merge_df.loc[:,'EPS_BUSN_ID'].astype(int)

        cols = base_df.columns
        merge_df = merge_df[cols]



        merge_df['DESCRIPTION'] = merge_df['DESCRIPTION']+build_name

        # Finally, try to auto-assign reps to blank leads
        zip_df = merge_df.loc[merge_df.PROSPECT_OWNER == '', 'ZIP']
        zip_codes = zip_df.unique()
        if len(zip_codes) > 0:
            if SMBflag:
                job_descr = ("('Business Acct Exec 1, SMB Direct Sales',"
                              "'Business Acct Exec 3, SMB Direct Sales',"
                              "'Mgr 1, SMB Direct Sales (Advanced Svcs)',"
                              "'Mgr 1, SMB Direct Sales (Outside Sales)')")
            else:
                job_descr = "('Acct Exec 3, Enterprise Direct Sales','Mgr 1, Enterprise Direct Sales')"
            zip_list = "('" + "','".join([str(zipcode) for zipcode in zip_codes]) + "')"
            zip_sql = (
                "SELECT DISTINCT A.Zip__c, A.User_Email__c, C.JobDescr "
                "FROM [ExternalUser].[SFDC].[Kebzip__c] A "
                "INNER JOIN [ExternalUser].[SFDC].[User] B ON A.USER__C = B.ID "
                "INNER JOIN [WISDM].[Dim].[Employee] C ON B.Comcast_Employee_ID__c = C.Pernr AND IsCurrent = 1 "
                "WHERE DIVISION__C = 'WEST' "
                "AND A.Zip__c IN {} "
                "AND C.JobDescr IN {}".format(zip_list, job_descr)
               )
            zip_df = pd.read_sql(zip_sql, cnxn)
            for zipcode in zip_codes:
                small_df = zip_df.loc[zip_df.Zip__c == zipcode,('User_Email__c','JobDescr')]
                if small_df.shape[0] == 0:
                    continue
                if SMBflag:
                    if 'Business Acct Exec 1, SMB Direct Sales' in small_df.JobDescr.tolist():
                        rep_df = small_df.loc[small_df.JobDescr == 'Business Acct Exec 1, SMB Direct Sales', ('User_Email__c','JobDescr')]
                    elif 'Business Acct Exec 3, SMB Direct Sales' in small_df.JobDescr.tolist():
                        rep_df = small_df.loc[small_df.JobDescr == 'Business Acct Exec 3, SMB Direct Sales', ('User_Email__c','JobDescr')]
                    elif 'Mgr 1, SMB Direct Sales (Outside Sales)' in small_df.JobDescr.tolist():
                        rep_df = small_df.loc[small_df.JobDescr == 'Mgr 1, SMB Direct Sales (Outside Sales)', ('User_Email__c','JobDescr')]
                    elif 'Mgr 1, SMB Direct Sales (Advanced Svcs)' in small_df.JobDescr.tolist():
                        rep_df = small_df.loc[small_df.JobDescr == 'Mgr 1, SMB Direct Sales (Advanced Svcs)', ('User_Email__c','JobDescr')]
                    else:
                        rep_df = pd.DataFrame(columns=('User_Email__c','JobDescr'))
                    if rep_df.shape[0] == 0:
                        continue
                    elif rep_df.shape[0] > 1:

                        #check to see if any reps have opptys
                        oppty_rep = []
                        for rep in rep_df.User_Email__c.tolist():
                            if rep in merge_df.PROSPECT_OWNER.tolist():
                                oppty_rep.append(rep)
                        if len(oppty_rep) >= 1:
                            rep_df = rep_df.loc[rep_df.User_Email__c == oppty_rep[0], :]
#                        elif len(oppty_rep) > 1:
                            # FIX TO find the rep with the most recent created oppty

                        i = floor(np.random.rand()*rep_df.shape[0])
                        if i == rep_df.shape[0]:
                            i = i-1
                        rep_df = rep_df.iloc[i,:]
                        merge_df.loc[(merge_df.PROSPECT_OWNER == '')
                                 & (merge_df.DESCRIPTION.str[:3] == 'SMB')
                                 & (merge_df.ZIP == zipcode), 'PROSPECT_OWNER'] = rep_df.values[0]
                    else:
                        merge_df.loc[(merge_df.PROSPECT_OWNER == '')
                                 & (merge_df.DESCRIPTION.str[:3] == 'SMB')
                                 & (merge_df.ZIP == zipcode), 'PROSPECT_OWNER'] = rep_df.values[0][0]
                else:
                    if 'Acct Exec 3, Enterprise Direct Sales' in small_df.JobDescr.tolist():
                        rep_df = small_df.loc[small_df.JobDescr == 'Acct Exec 3, Enterprise Direct Sales', ('User_Email__c','JobDescr')]
                    elif 'Mgr 1, Enterprise Direct Sales' in small_df.JobDescr.tolist():
                        rep_df = small_df.loc[small_df.JobDescr == 'Mgr 1, Enterprise Direct Sales', ('User_Email__c','JobDescr')]
                    else:
                        rep_df = pd.DataFrame()
                    if rep_df.shape[0] == 0:
                        continue
                    elif rep_df.shape[0] > 1:

                        #check to see if any reps have opptys
                        oppty_rep = []
                        for rep in rep_df.User_Email__c.tolist():
                            if rep in merge_df.PROSPECT_OWNER.tolist():
                                oppty_rep.append(rep)
                        if len(oppty_rep) >= 1:
                            rep_df = rep_df.loc[rep_df.User_Email__c == oppty_rep[0], :]
#                        elif len(oppty_rep) > 1:
                            # FIX TO find the rep with the most recent created oppty

                        i = floor(np.random.rand()*rep_df.shape[0])
                        if i == rep_df.shape[0]:
                            i = i-1
                        rep_df = rep_df.iloc[i,:]
                    merge_df.loc[(merge_df.PROSPECT_OWNER == '')
                                 & (merge_df.DESCRIPTION.str[:3] == 'ENT')
                                 & (merge_df.ZIP == zipcode), 'PROSPECT_OWNER'] = rep_df.values[0][0]

        out_df = out_df.append(merge_df)
        cnxn.close()

    if out_df.shape[0] < 1:
        return redirect('edit_req', slug=hyperbuild_req.slug)

    #Reorder and rename columns
    new_col_order = ([cols[0]]
                     + ['CAMPAIGN_ID','MARKETING_CAMPAIGN_CODE']
                     + [col for col in cols[1:]]
                     )


    #Check whether any businesses identified, if so then add ids/codes
    if out_df.shape[0] == 0:
        out_df = pd.DataFrame(index=[0],columns=new_col_order)
    else:
        for build in hyperbuild_names:
            curridx = [build == descrip[4:] for descrip in out_df['DESCRIPTION']]
            currbuild = HyperBuildName.objects.get(hyperbuild_name=build)
            if SMBflag:
                ID = currbuild.SMB_ID
                code = currbuild.SMB_code
            else:
                ID = currbuild.ENT_ID
                code = currbuild.ENT_code
            out_df.loc[curridx, 'CAMPAIGN_ID'] = ID
            out_df.loc[curridx, 'MARKETING_CAMPAIGN_CODE'] = code


    out_df = out_df[new_col_order]
    new_col_names = ['Prospect Owner', 'Campaign ID',
                     'Marketing Campaign Code', 'First Name', 'Last Name',
                     'Company', 'Street', 'City', 'State', 'Zip/Postal Code',
                     'Phone', 'Email', 'Email Opt Out',
                     'Email Opt Out Reason', 'Prospect Status',
                     'Marketing ID', 'DESCRIPTION', 'Est. Telco Spend',
                     'Salesforce.com ID']
    out_df.columns = new_col_names
    if out_df.loc[out_df['Prospect Owner'].notnull(),:].shape[0] > 0:
        out_df['Company'] = out_df['Company'].str.replace(',', ' ')
        out_df['Street'] = out_df['Street'].str.replace(',', ' ')
        out_df['Est. Telco Spend'] = '$' + out_df['Est. Telco Spend'].astype(str)
        out_df['Marketing ID'] = out_df['Marketing ID'].astype(int)

        out_df.sort_values(by=['DESCRIPTION','Company'], inplace=True)

    int_cols = ['BC (SMB)','BC (ENT+)','TARGET BUSN CNT', 'LEADS INCLD']

    if summary_df.shape[0] == 0:
        summary_df = pd.DataFrame(index=[0],columns=summary_cols)
    else:
        summary_df[int_cols] = summary_df[int_cols].astype(int)



    hyperbuild_req.build_summary = summary_df
    hyperbuild_req.prev_req = out_df
    hyperbuild_req.prev_names = hyperbuild_html
    hyperbuild_req.prev_channels = channel_html
    hyperbuild_req.save()

    queryhist = QueryHistory(user=hyperbuild_req.user,
                             region=hyperbuild_req.region.__str__(),
                             hyperbuild_names=hyperbuild_html,
                             channels=channel_html,
                             timestamp=timezone.now())
    queryhist.save()
    return redirect('req_detail', slug=hyperbuild_req.slug)

@login_required
def req_loading(request):
    '''This function displays the loading gif, then call an
       additional function to query the database'''

    # Make sure logged in user is the request owner
    hyperbuild_req = HyperBuildReq.objects.get(slug=slug)
    if hyperbuild_req.user != request.user:
        raise Http404

    # Add a flag to verify the request came from the req_detail

    return render(request, 'hyperbuild_request/req_loading.html',
                  {'hyperbuild_req':hyperbuild_req})

@login_required
def req_detail(request, summary=False):
    '''This function displays the output of a given query in
       a table. If the query hasn't changed, the table is
       generated from memory, otherwise a new SQL call had to
       be made (which takes from 2-15 minutes).'''

    # Make sure logged in user is the request owner
    hyperbuild_req = HyperBuildReq.objects.get(slug=slug)
    if hyperbuild_req.user != request.user:
        raise Http404

    # Get the names of the current hyperbuilds
    # If blank, redirect to the region page
    try:
        new_names = [build.name()
                            for build in hyperbuild_req.hyperbuild_names.all()]
    except:
        return redirect('change_region', slug=hyperbuild_req.slug)

    hyperbuild_html = " || ".join(new_names)


    # Create a display string based on channel selections
    new_channels = [channel.__str__()
                    for channel in hyperbuild_req.channels.all()]
    channel_html = ", ".join(new_channels)


    # Check whether a query has changed from a previous query (try)
    #    or is instead a completely new query (except)
    try:
        old_channels = hyperbuild_req.prev_channels.split(', ')
        old_names = hyperbuild_req.prev_names.split(', ')

        new_channel_test = [channel in old_channels for channel in new_channels]
        old_channel_test = [channel in new_channels for channel in old_channels]
        new_build_test = [build in new_names for build in old_names]
        old_build_test = [build in old_names for build in new_names]
        new_query = not np.all(new_channel_test
                          + old_channel_test
                          + new_build_test
                          + old_build_test)
    except:
        new_query = True

    if new_query:
        return redirect('update_hyperbuild_names', slug=hyperbuild_req.slug)
    elif not summary:
        table = hyperbuild_req.prev_req.to_html(index=False)
    else:
        table = hyperbuild_req.build_summary.to_html(index=False)

    return render(request, 'hyperbuild_request/req_detail.html',
                  {'hyperbuild_req':hyperbuild_req, 'table':table,
                   'channel_html':channel_html,
                   'hyperbuild_html':hyperbuild_html,
                   'summary':summary})


@login_required
def edit_req(request):
    '''This function allows the user to edit the parameters of a
       given query and submit a new SQL call (which takes from
       2-15 minutes).'''
    hyperbuild_req = HyperBuildReq.objects.get(slug=slug)

    #make sure logged in user is the request owner
    if hyperbuild_req.user != request.user:
        raise Http404

    #Verify a region is selected
    region = hyperbuild_req.region.__str__()
    if region == 'None':
        return redirect('change_region', slug=hyperbuild_req.slug)

    form_class = HyperBuildReqForm
    #if we're coming to this view from a submitted form,
    if request.method == 'POST':
        # grab the data from the submitted form
        form = form_class(data=request.POST,
                          instance=hyperbuild_req)
        print(form)
        print(form.is_valid())
        if form.is_valid():
            # save the new data
            form.save()
            return redirect('req_detail', slug=hyperbuild_req.slug)
    # otherwise just create the form
    else:
        form = form_class(instance=hyperbuild_req,
                          order='hyperbuild_name')
        form_approval = form_class(instance=hyperbuild_req,
                                   order='-approval_date')
    # and render the template

    return render(request, 'hyperbuild_request/edit_req.html',
                  {'hyperbuild_req':hyperbuild_req, 'form':form,
                   'region':region, 'form_approval':form_approval})

@login_required
def download_req(request):
    '''This function allows the user to download results.'''
    hyperbuild_req = HyperBuildReq.objects.get(slug=slug)

    #make sure logged in user is the request owner
    if hyperbuild_req.user != request.user:
        raise Http404

    # Make sure the query results exist
    try:
        out_df = hyperbuild_req.prev_req[:]
    except:
        raise Http404

    #write that dataframe to a string in memory
    sio = StringIO()
    out_df.to_csv(sio, sep=',', index = False)
    sio.seek(0)

    # Create a search string for SQL based on channel selections
    new_channels = [channel.__str__()
                    for channel in hyperbuild_req.channels.all()]
    channel_str = ""
    for channel in new_channels:
        channel_str = channel_str + channel + "_"
    channel_str = channel_str[:-1]

    hyperbuild_names = [build.name()
                            for build in hyperbuild_req.hyperbuild_names.all()]
    if len(hyperbuild_names) > 1:
        add_str = "_etal"
    else:
        add_str = ""
    hyperbuild_str = hyperbuild_names[0] + add_str
    #Create the download filename, including a timestamp
    base_name = 'HyperBuild_Marketing_{}_{}_'.format(hyperbuild_str,
                                                     channel_str)
    ts = time.strftime('%Y%m%d_%H%M')
#    filename = base_name + ts + '.xlsx'
    filename = base_name + ts + '.csv'

    # Generate the HttpResponse and send to the user
    response = StreamingHttpResponse(sio, content_type='text/plain')
    response['Content-Disposition'] = 'attachment; filename=%s' % filename
    return response

@login_required
def sql_error(request):
    # Make sure logged in user is the request owner
    hyperbuild_req = HyperBuildReq.objects.get(slug=slug)
    if hyperbuild_req.user != request.user:
        raise Http404
    return render(request, 'hyperbuild_request/sql_error.html',
                  {'hyperbuild_req':hyperbuild_req})

# SFTP code:
#import pysftp
#import sys
#
#path = './THETARGETDIRECTORY/' + sys.argv[1]    #hard-coded
#localpath = sys.argv[1]
#
#host = "THEHOST.com"                    #hard-coded
#password = "THEPASSWORD"                #hard-coded
#username = "THEUSERNAME"                #hard-coded
#
#with pysftp.Connection(host, username=username, password=password) as sftp:
#    sftp.put(localpath, path)
#
#print 'Upload done.'





#class HyperBuildAutocomplete(autocomplete.Select2QuerySetView):
#    def get_queryset(self):
#        if not self.request.user.is_authenticated():
#            return HyperBuildName.objects.none()
#
#        qs = HyperBuildName.objects.all()
#
#        if self.q:
#            qs = qs.filter(name__istartswith=self.q)
#
#        return qs

# To get all request:
#   probuild_reqs = ProBuildReq.objects.all()
#
# To get one request:
#   probuild_req = ProBuildReq.objects.get(user = request.user)
#
# To get a selection:
#   pro_build_reqs = ProBuildReq.objects.filter(name__contains="business")
